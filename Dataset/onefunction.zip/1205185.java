    public ModelResponse execute(ModelRequest req) throws ModelException {
        ModelResponse res = req.createResponse();
        LicenseInfo license = LicenseTools.getLicenseInfo();
        Output licenseComplanyName = res.createOutput("licenseCompanyName");
        if (license != null) {
            licenseComplanyName.setContent(license.getCompany());
        } else {
            licenseComplanyName.setContent("");
        }
        res.add(licenseComplanyName);
        return res;
    }
