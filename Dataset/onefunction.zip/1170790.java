    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession user = request.getSession(false);
        if (user != null) {
            Event event = (Event) user.getAttribute("event.modify.jsp");
            List elementsList = event.getMask();
            List editElementsList = new ArrayList();
            for (int i = 0; i < elementsList.size(); i++) {
                editElementsList.add((MaskElement) elementsList.get(i));
            }
            user.setAttribute("maskElements.editMask.jsp", editElementsList);
        }
        RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/admin/eventconf/masks/editMask.jsp");
        dispatcher.forward(request, response);
    }
