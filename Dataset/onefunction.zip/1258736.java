    public static <T> T execute(Task<T> task) throws Exception {
        Thread thread = Thread.currentThread();
        ClassLoader oldClassLoader = thread.getContextClassLoader();
        try {
            final ClassLoader myClassLoader = task.getClass().getClassLoader();
            if (log.isDebugEnabled()) {
                log.debug("setting classloader of thread '" + thread.getName() + "' to '" + myClassLoader + "'.");
            }
            thread.setContextClassLoader(myClassLoader);
            return task.execute();
        } finally {
            if (log.isDebugEnabled()) {
                log.debug("setting classloader of thread '" + thread.getName() + "' to '" + oldClassLoader + "'.");
            }
            thread.setContextClassLoader(oldClassLoader);
        }
    }
