    public View<?> createView(OrganSession session, Displayable element) {
        View<? extends Displayable> view = null;
        if (element instanceof Memory) {
            view = new MemoryView(session.lookup(Storage.class), (Memory) element);
        }
        return view;
    }
