    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        final ActionErrors errors = new ActionErrors();
        CostForm costForm = (CostForm) form;
        User user = (User) request.getSession().getAttribute("user");
        Cost cost = new Cost();
        cost.setAmount(costForm.getAmount());
        cost.setCostTypeId(costForm.getCostTypeId());
        cost.setDate(costForm.getDate());
        cost.setDescription(costForm.getDescription());
        cost.setVat(costForm.getVat());
        cost.setId(costForm.getId());
        cost.setUserId(user.getId());
        BoekDao boekDao = new BoekDao();
        boekDao.updateKost(cost);
        if (costForm.getSplitAmount().compareTo(new BigDecimal("0")) != 0 || costForm.getSplitVat().compareTo(new BigDecimal("0")) != 0) {
            Cost splitCost = new Cost();
            splitCost.setAmount(costForm.getSplitAmount());
            splitCost.setCostTypeId(costForm.getSplitCostTypeId());
            splitCost.setDate(costForm.getDate());
            splitCost.setDescription(costForm.getSplitDescription());
            splitCost.setVat(costForm.getSplitVat());
            splitCost.setId(0);
            splitCost.setUserId(user.getId());
            boekDao.insertKost(splitCost);
        }
        request.getSession().removeAttribute("overview");
        KostensoortDao kostensoortDao = new KostensoortDao();
        List<Kostensoort> kostenSoortLijst = kostensoortDao.getKostensoortLijst();
        request.setAttribute("kostenSoortLijst", kostenSoortLijst);
        ActionMessage message = new ActionMessage("messages.confirm");
        errors.add(ActionErrors.GLOBAL_MESSAGE, message);
        addErrors(request, errors);
        saveErrors(request, errors);
        return mapping.findForward("success");
    }
