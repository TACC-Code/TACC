    public static void main(String[] args) {
        try {
            StockQuoteConsumerAgent simpleConsumer = new StockQuoteConsumerAgent("consumer", CWSServiceManager.workspaceName, CWSServiceManager.workspaceAddress);
            simpleConsumer.start();
        } catch (Exception e) {
        }
    }
