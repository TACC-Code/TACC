    public static String getParentTypedID(ResourceType type, String id) throws Exception {
        StringBuffer buf = new StringBuffer();
        buf.append("urn");
        switch(type) {
            case Project:
                buf.append(":Project:");
                break;
            case Experiment:
                buf.append(":Experiment:");
                break;
            case WorkflowTemplate:
                buf.append(":WorkflowTemplate:");
                break;
            case WorkflowInstance:
                buf.append(":WorkflowInstance:");
                break;
            default:
                throw new Exception("Unknow resource type, type =" + type);
        }
        buf.append(id);
        return buf.toString();
    }
