    public void run() {
        while (true) {
            System.out.println("Counter: " + workingThread.getCounter());
            try {
                sleep(0);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
