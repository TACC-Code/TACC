    public void testGetValue() {
        try {
            DomainObject lDomainObject = ((TestRelDefDomainObjectHomeImpl) VSys.homeManager.getHome("org.hip.kernel.bom.impl.test.TestRelDefDomainObjectHomeImpl")).create();
            lDomainObject.set("TestID", new Integer(20));
            PropertySet lPropertySet = new PropertySetImpl(lDomainObject);
            assertNotNull(lPropertySet);
            ObjectRefProperty lObjectRef = new ObjectRefPropertyImpl(lPropertySet, "FirstName");
            Object lRet = lObjectRef.getValue();
            assertNotNull(lRet);
        } catch (org.hip.kernel.bom.SettingException exc) {
            fail(exc.getMessage());
        } catch (org.hip.kernel.bom.BOMException exc) {
            fail(exc.getMessage());
        }
    }
