    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse resp) throws Exception {
        long storyId = Long.parseLong(request.getParameter("storyid"));
        User user = null;
        UserBean userBean = (UserBean) request.getSession().getAttribute("user");
        if (userBean != null) user = userBean.convertToUser(); else {
            throw new Exception("需要登录");
        }
        String shop_type = request.getParameter("shop_type");
        boolean isNetShop = shop_type.equals("net") ? true : false;
        String shopName = isNetShop ? request.getParameter("netshop") : request.getParameter("entityshop");
        StoryService service = ServiceFactory.getStoryService();
        Shop shop = null;
        Shop temp = service.getShopByName(shopName);
        if (temp == null) {
            shop = new Shop();
            shop.setOnInternet(isNetShop);
            shop.setName(shopName);
            service.addShop(shop);
        } else {
            shop = temp;
        }
        Report report = new Report();
        report.setShopName(shopName);
        report.setStoryId(storyId);
        service.addReport(report);
        return new ModelAndView("redirect:" + request.getContextPath() + "/story/" + storyId);
    }
