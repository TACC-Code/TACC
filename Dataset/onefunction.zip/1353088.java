    protected void adjustRowHeight(final JTable table, final Component component, final int row) {
        final int cellHeight = table.getRowHeight(row);
        final int rendererHeight = component.getPreferredSize().height;
        if (cellHeight < rendererHeight - 4) {
            table.setRowHeight(row, rendererHeight);
        }
    }
