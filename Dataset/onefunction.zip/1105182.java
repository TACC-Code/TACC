    public List<DayType> getDayType() {
        if (dayType == null) {
            dayType = new ArrayList<DayType>();
        }
        return this.dayType;
    }
