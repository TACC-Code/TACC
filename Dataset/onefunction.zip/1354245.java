    public static Test suite() {
        log("Start " + VOWSampleAppTestSuite.class.getName());
        VTestSuite suite = new VTestSuite(VOWSampleAppTestSuite.class.getName());
        suite.addTestSuite(VOWTestSuite.class);
        suite.addTestSuite(VOWSampleAppMain.class);
        return suite;
    }
