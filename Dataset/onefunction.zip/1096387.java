    public Permissions_Shared(String appName, String packageName, String SharedUserID, Drawable icon) {
        this.appName = appName;
        this.packageName = packageName;
        this.SharedUserID = SharedUserID;
        this.icon = icon;
    }
