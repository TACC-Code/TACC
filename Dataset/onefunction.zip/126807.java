    public static void main(String[] args) {
        System.setSecurityManager(new RMISecurityManager());
        try {
            RemoteClockImpl clock = new RemoteClockImpl();
            Naming.rebind("MyRemoteClock", clock);
            System.out.println("MyRemoteClock bound!");
            BufferedReader rd = new BufferedReader(new InputStreamReader(System.in));
            boolean done = false;
            while (!done) {
                System.out.println("type EXIT to shutdown the server:");
                if (rd.readLine().equals("EXIT")) {
                    done = true;
                }
            }
            Naming.unbind("MyRemoteClock");
            UnicastRemoteObject.unexportObject(clock, true);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
