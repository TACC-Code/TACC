    public AboutDialog(JFrame f) {
        super(f);
        lang = Options.getLanguage();
        super.setTitle(lang.getString("AboutDialog.text"));
        setSize(250, 150);
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int x = (screenSize.width - getWidth()) / 2;
        int y = (screenSize.height - getHeight()) / 2;
        setLocation(x, y);
        setVisible(true);
        JPanel panel = new JPanel(new GridLayout(0, 1));
        add(panel);
        panel.add(new JLabel("JCG"));
        panel.add(new JLabel("Trần Đại Hiệp"));
        panel.add(new JLabel("Nguyễn Thắng Huy"));
        panel.add(new JLabel("Đỗ Văn Khang"));
        panel.add(new JLabel("Trần Xuân Thành"));
    }
