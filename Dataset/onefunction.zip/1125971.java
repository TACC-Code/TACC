    public void testEquals() {
        Product myProduct1 = new Product("Nikon 80-400mm VR f/4.5-5.6", 2000.0);
        Product myProduct2 = new Product("Nikon 80-400mm VR f/4.5-5.6", 2000.0);
        Product myProduct3 = new Product("Nikon 17-55mm VR f/2.8", 1600.0);
        assertEquals("Product equals does not work as expected", myProduct1, myProduct1);
        assertEquals("Product equals does not work as expected", myProduct1.hashCode(), myProduct1.hashCode());
        assertFalse("Product equals does not work as expected", myProduct1.equals(null));
        assertFalse("Product equals does not work as expected", myProduct1.equals(new Customer()));
        assertEquals("Product equals does not work as expected", myProduct1, myProduct2);
        assertEquals("Product equals does not work as expected", myProduct1.hashCode(), myProduct2.hashCode());
        assertFalse("Product equals does not work as expected", myProduct2.equals(myProduct3));
        assertFalse("Product equals does not work as expected", myProduct2.hashCode() == myProduct3.hashCode());
    }
