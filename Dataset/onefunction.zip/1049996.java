    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        TextView tv = new TextView(this);
        tv.setText("jiki service started");
        setContentView(tv);
        startService(new Intent(Jiki.this, JHTTPServer.class), icicle);
        JHTTPServer.init(this);
    }
