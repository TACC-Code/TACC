    public void testOutputNode() throws Exception {
        StringWriter writer = new StringWriter();
        OutputNode root = NodeBuilder.write(writer);
        OutputNode first = root.getChild("first");
        first.setAttribute("a", "A");
        first.setAttribute("b", "B");
        first.setAttribute("c", "C");
        first.setName("root");
        OutputNode second = first.getChild("second");
        second.setAttribute("id", "second");
        second.setName("child");
        OutputNode third = first.getChild("third");
        Exception cause = null;
        third.setAttribute("id", "third");
        third.setName("secondChild");
        try {
            second.setName("illegalOperation");
        } catch (Exception e) {
            cause = e;
        }
        root.commit();
        assertNotNull(cause);
        assertEquals(cause.getClass(), NodeException.class);
        String text = writer.toString();
        assertXpathExists("/root[@a='A']", text);
        assertXpathExists("/root[@b='B']", text);
        assertXpathExists("/root[@c='C']", text);
        assertXpathNotExists("/first[@a='A']", text);
        assertXpathNotExists("/first[@b='B']", text);
        assertXpathNotExists("/first[@c='C']", text);
        assertXpathExists("/root/child[@id='second']", text);
        assertXpathExists("/root/secondChild[@id='third']", text);
        assertXpathNotExists("/first/second", text);
        assertXpathNotExists("/first/second/third", text);
    }
