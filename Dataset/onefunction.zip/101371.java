    public boolean addSerie(SerienformularBean sf) {
        boolean ret = false;
        ICRUDSerie icrudSerie = new ICRUDSerieImpl();
        icrudSerie.setEntityManager(KoDraDVDEntityManager.getInstance());
        Serie s = new Serie();
        s.setSerientitel(sf.getSerientitel());
        s.setStaffeln(BigInteger.valueOf(sf.getStaffeln()));
        s.setFolgen(BigInteger.valueOf(sf.getAnzahlFolgen()));
        s.setBewertung(BigInteger.valueOf(sf.getBewertung()));
        ret = icrudSerie.insertSerie(s);
        return ret;
    }
