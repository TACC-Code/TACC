    public View process(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        Blog blog = (Blog) getModel().get(Constants.BLOG_KEY);
        String name = request.getParameter("name");
        String oldName = StringUtils.filterHTML(name);
        String type = request.getParameter("type");
        String path = request.getParameter("path");
        String newName = StringUtils.filterHTML(request.getParameter("newName"));
        String submit = request.getParameter("submit");
        FileManager fileManager = new FileManager(blog, type);
        FileMetaData directory = fileManager.getFileMetaData(path);
        try {
            if (submit.equalsIgnoreCase("rename")) {
                fileManager.renameFile(path, name, newName);
                if (type.equals(FileMetaData.THEME_FILE)) {
                    fileManager = new FileManager(blog, FileMetaData.BLOG_DATA);
                    fileManager.renameFile("/theme" + path, name, newName);
                }
                blog.info("File \"" + oldName + "\" renamed to \"" + newName + "\".");
            } else {
                if (FileManager.hasEnoughSpace(blog, fileManager.getFileMetaData(path, name).getSizeInKB())) {
                    fileManager.copyFile(path, name, newName);
                    if (type.equals(FileMetaData.THEME_FILE)) {
                        fileManager = new FileManager(blog, FileMetaData.BLOG_DATA);
                        fileManager.copyFile("/theme" + path, name, newName);
                    }
                    blog.info("File \"" + oldName + "\" copied to \"" + newName + "\".");
                } else {
                    return new NotEnoughSpaceView();
                }
            }
        } catch (IllegalFileAccessException e) {
            return new ForbiddenView();
        } catch (IOException ioe) {
            throw new ServletException(ioe);
        }
        return new RedirectView(blog.getUrl() + directory.getUrl());
    }
