    public void execute(SipSession session, SipServletRequest req) throws IOException, Rel100Exception {
        B2buaHelper helper = req.getB2buaHelper();
        SipSession peerSession = helper.getLinkedSession(req.getSession());
        List<SipServletMessage> pendings = helper.getPendingMessages(peerSession, UAMode.UAC);
        SipServletResponse res = B2buaHelperUtil.getPendingResponse(pendings, "INVITE");
        SipServletRequest ack = res.createAck();
        SipContentUtil.copy(req, ack);
        ack.send();
    }
