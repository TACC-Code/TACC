    public String toString() {
        StringBuffer sb = new StringBuffer();
        boolean firstItem = true;
        for (Object data : this) {
            if (!firstItem) {
                sb.append(", ");
            } else firstItem = false;
            sb.append(data.toString());
        }
        return sb.toString();
    }
