    public void calculateColdEmissions(Id coldEmissionEventLinkId, Id personId, double startEngineTime, double parkingDuration, double accumulatedDistance, HbefaColdEmissionTableCreator hbefaColdTable, EventsManager emissionEventsManager) {
        int distance_km = -1;
        if ((accumulatedDistance / 1000) < 1.0) {
            distance_km = 0;
        } else {
            distance_km = 1;
        }
        int parkingDuration_h = (int) (parkingDuration / 3600);
        if (parkingDuration_h >= 12) {
            parkingDuration_h = 12;
        }
        ColdPollutant coldPollutant = null;
        Double generatedEmissions = null;
        Map<ColdPollutant, Double> coldEmissions = new HashMap<ColdPollutant, Double>();
        for (Entry<ColdPollutant, Map<Integer, Map<Integer, HbefaColdEmissionFactor>>> entry : hbefaColdTable.getHbefaColdTable().entrySet()) {
            Map<Integer, Map<Integer, HbefaColdEmissionFactor>> value = entry.getValue();
            double coldEf = value.get(distance_km).get(parkingDuration_h).getColdEF();
            coldPollutant = entry.getKey();
            generatedEmissions = coldEf;
            coldEmissions.put(coldPollutant, generatedEmissions);
        }
        Event coldEmissionEvent = new ColdEmissionEventImpl(startEngineTime, coldEmissionEventLinkId, personId, coldEmissions);
        emissionEventsManager.processEvent(coldEmissionEvent);
    }
