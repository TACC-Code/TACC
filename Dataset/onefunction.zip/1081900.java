    public static String getItem(String currentStatus, String status, String statusName, String forward) {
        if (currentStatus.equals(status)) {
            return "<b>" + statusName + "</b>";
        }
        return "<a href='" + forward + "'>" + statusName + "</a>";
    }
