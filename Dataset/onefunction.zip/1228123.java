    public static void main(String args[]) {
        String str = "522.0";
        String s = "12345678";
        float f = Float.valueOf(s).floatValue();
        double d = Double.valueOf(s).doubleValue();
        double a = 1300.28;
        double b = 1200;
        java.text.DecimalFormat df = new DecimalFormat("0.#");
        System.out.println(f);
        System.out.println(d);
        System.out.println("Float������ֵ��" + String.valueOf(Float.MAX_VALUE));
        System.out.println("Float�����Сֵ��" + Float.MIN_VALUE);
        System.out.println(a - b);
        System.out.println(1 / (1 << 23));
        System.out.println(df.format(Double.valueOf(str)));
    }
