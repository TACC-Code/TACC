    public void makeReportHtmlFile(boolean dynamicOrStatic, Vector totalHtmlCode, int realHtmlPageNum, String HTMLFilePath) {
        ReportHtmlFileGenerator generator = new ReportHtmlFileGenerator();
        for (int i = 0; i < totalHtmlCode.size(); i++) {
            int pageIndex = 1;
            Vector oneHtmlPageContent = (Vector) totalHtmlCode.get(i);
            int vectorSize = oneHtmlPageContent.size();
            String pageKind = (String) oneHtmlPageContent.get(0);
            if (pageKind.equals("Static Page")) {
                oneHtmlPageContent.remove(0);
                dynamicOrStatic = false;
                int whichPage = 0;
                if (pageIndex == 1) whichPage = 0; else if ((pageIndex > 1) && (pageIndex < realHtmlPageNum)) whichPage = 2; else if (pageIndex == realHtmlPageNum) whichPage = 1;
                generator.makeHTMLFile(oneHtmlPageContent, HTMLFilePath, pageIndex, whichPage, realHtmlPageNum, dynamicOrStatic);
                pageIndex++;
            } else if (pageKind.equals("Dynamic Page")) {
                oneHtmlPageContent.remove(vectorSize - 1);
                dynamicOrStatic = true;
                for (int j = 0; j < oneHtmlPageContent.size(); j++) {
                    Vector tDetail = (Vector) oneHtmlPageContent.get(j);
                    Vector realOnePage = new Vector();
                    int page = pageIndex;
                    int whichPage = 0;
                    for (int k = 0; k < tDetail.size(); k++) {
                        String insertContents = (String) tDetail.get(k);
                        boolean result1 = insertContents.endsWith("page:Ended");
                        boolean result2 = insertContents.endsWith("The End");
                        if (result1 == true) {
                            int endIndex = insertContents.indexOf(" ");
                            pageIndex = Integer.parseInt(insertContents.substring(0, endIndex));
                            page = pageIndex;
                            if (pageIndex == 1) whichPage = 0; else whichPage = 2;
                            generator.makeHTMLFile(realOnePage, HTMLFilePath, pageIndex, whichPage, realHtmlPageNum, dynamicOrStatic);
                            realOnePage.removeAllElements();
                        } else if (result2 == true) {
                            pageIndex = ++page;
                            whichPage = 1;
                            generator.makeHTMLFile(realOnePage, HTMLFilePath, pageIndex, whichPage, realHtmlPageNum, dynamicOrStatic);
                            break;
                        } else realOnePage.addElement(insertContents);
                    }
                }
            }
        }
    }
