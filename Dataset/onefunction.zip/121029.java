    public boolean evaluate(Object result, Object[] originalParameters, Object[] newParameters) {
        try {
            int originalAmount = (Integer) originalParameters[2];
            int newAmount = (Integer) newParameters[2];
            int difference = originalAmount - newAmount;
            int currentBalance = (Integer) result;
            if ((currentBalance - difference) > 0) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
