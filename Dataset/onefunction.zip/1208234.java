    public static double getValueOfParameter(Config cfg, String name) {
        PlanCalcScoreConfigGroup scoring = cfg.planCalcScore();
        String value = scoring.getParams().get(name);
        if (name.equals(PatternSearchListenerI.STUCK)) {
            return Math.min(Math.min(scoring.getLateArrival_utils_hr(), scoring.getEarlyDeparture_utils_hr()), Math.min(scoring.getTraveling_utils_hr(), scoring.getWaiting_utils_hr()));
        } else if (value == null) {
            value = cfg.findParam(CalibrationConfig.BSE_CONFIG_MODULE_NAME, name);
            if (value == null) {
                throw new RuntimeException("The parameter\t" + name + "\tcan NOT be found");
            }
        }
        return Double.parseDouble(value);
    }
