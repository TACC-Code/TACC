    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        if (classfileBuffer == null) throw new IllegalArgumentException("null classfileBuffer");
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
        ClassReader cr = new ClassReader(classfileBuffer);
        ClassAdapter ca = new AspectClassAdapter(cw);
        cr.accept(ca, 0);
        byte[] transformedBytes = cw.toByteArray();
        if (FrameworkConfig.getInstance().debugBytecodeXform) {
            cr = new ClassReader(transformedBytes);
            cw = new ClassWriter(cr, 0);
            TraceClassVisitor tcv = new TraceClassVisitor(cw, new PrintWriter(new LogWriter()));
            cr.accept(tcv, TraceClassVisitor.getDefaultAttributes(), ClassReader.SKIP_DEBUG);
        }
        return transformedBytes;
    }
