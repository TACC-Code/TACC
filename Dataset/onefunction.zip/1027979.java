    public CacheService buildCacheService(String regionName, Properties properties) throws CacheServiceException {
        int refreshPeriod = PropertiesHelper.getInt(StringHelper.qualify(regionName, OSCACHE_REFRESH_PERIOD), OSCACHE_PROPERTIES, CacheEntry.INDEFINITE_EXPIRY);
        String cron = OSCACHE_PROPERTIES.getProperty(StringHelper.qualify(regionName, OSCACHE_CRON));
        OSCacheServiceImpl cache = new OSCacheServiceImpl(refreshPeriod, cron);
        Integer capacity = PropertiesHelper.getInteger(StringHelper.qualify(regionName, OSCACHE_CAPACITY), OSCACHE_PROPERTIES);
        if (capacity != null) cache.setCacheCapacity(capacity.intValue());
        return cache;
    }
