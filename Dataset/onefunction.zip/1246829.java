    public void testVisitor() {
        Logger myLoggerMock = createNiceMock(Logger.class);
        myLoggerMock.debug("Visiting car");
        myLoggerMock.debug("Visiting engine");
        myLoggerMock.debug("Visiting body");
        myLoggerMock.debug("Visiting front left wheel");
        myLoggerMock.debug("Visiting front right wheel");
        myLoggerMock.debug("Visiting back left wheel");
        myLoggerMock.debug("Visiting back right wheel");
        myLoggerMock.debug("Vroom!");
        myLoggerMock.debug("Starting my engine");
        myLoggerMock.debug("Moving my body");
        myLoggerMock.debug("Steering my wheel");
        myLoggerMock.debug("Steering my wheel");
        myLoggerMock.debug("Steering my wheel");
        myLoggerMock.debug("Steering my wheel");
        replay(myLoggerMock);
        PrintVisitor.setLogger(myLoggerMock);
        DoVisitor.setLogger(myLoggerMock);
        Example.main(new String[0]);
        verify(myLoggerMock);
    }
