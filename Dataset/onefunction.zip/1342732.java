    public XMIRepositoryDriver getXMIRepository(RepositoryTypes repoType, String filename, Properties props) throws IOException, XMIRepositoryException {
        try {
            Class clsHandler = Class.forName(repoType.getName());
            Object handler = ConstructorUtils.invokeExactConstructor(clsHandler, new Object[] { filename, props });
            return new XMIRepositoryHandlerImpl((RepositoryDriver) handler);
        } catch (ClassNotFoundException e) {
            throw new XMIRepositoryException(e.getCause());
        } catch (InstantiationException e) {
            throw new XMIRepositoryException(e.getCause());
        } catch (InvocationTargetException e) {
            throw new XMIRepositoryException(e.getCause());
        } catch (NoSuchMethodException e) {
            throw new XMIRepositoryException(e.getCause());
        } catch (IllegalAccessException e) {
            throw new XMIRepositoryException(e.getCause());
        }
    }
