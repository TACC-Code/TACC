    public static List<Vertex> randomVertices(double maxX, double maxY, double minDistance, int numVertices) {
        Random generator = new Random();
        Vector<Vertex> vertices = new Vector<Vertex>();
        int f = 1, t = 0;
        double rx = 0, ry = 0;
        for (int i = 0; i < numVertices; i++) {
            while (f > 0) {
                f = 0;
                rx = maxX * (generator.nextDouble());
                ry = maxY * (generator.nextDouble());
                for (int j = 0; j < vertices.size(); j++) {
                    if (((vertices.get(j)).distance(new Vertex(rx, ry))) < minDistance) {
                        f++;
                        t++;
                    }
                    if (t == 1000) {
                        return null;
                    }
                }
            }
            vertices.addElement((new Vertex(rx, ry)));
            f = 1;
        }
        return vertices;
    }
