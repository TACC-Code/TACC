    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.debug("Starte Methode execute.");
        final DictionaryForm dictionaryForm = (DictionaryForm) form;
        final String searchString = dictionaryForm.getSuchbegriff();
        if (searchString != null && !"".equals(searchString)) {
            HibernateUtil.getSessionFactory().getCurrentSession().beginTransaction();
            VokabelDAO vocableDAO = new VokabelDAOHibernateImpl();
            dictionaryForm.setResultList(vocableDAO.findVocablesByPattern(searchString));
            HibernateUtil.getSessionFactory().getCurrentSession().getTransaction().commit();
            HibernateUtil.getSessionFactory().close();
        }
        logger.debug("Beende Methode execute.");
        return mapping.findForward("success");
    }
