    public void testApp() {
        MetricType cpuMetricType = new MetricType("CPU", "%", MetricType.MetricClass.FLUENT, Integer.class);
        String cpu1MetricURL = Metric.createMetricURL("slasoi://myManagedObject.company.com/TravelService/VMs/VM1", MetricType.MetricClass.FLUENT, cpuMetricType.getName());
        MetricEx cpu1 = new MetricEx(cpu1MetricURL, cpuMetricType);
        DroolsGateway dg = new DroolsGateway();
        String rule = "package org.slasoi.llms.rules.testpackage1 \n" + "import org.slasoi.llms.common.Observation; \n" + "rule \"TestClause-1\" " + "when " + "Observation(metric.metricURL == \"" + cpu1MetricURL + "\", $value : value, eval(Integer.parseInt($value) > 80)) \n" + "then " + "System.out.println(\"TestClause-1 fired \"); " + "end";
        System.out.println(rule);
        assertTrue(dg.addPackage(RulePackage.createRulePackageFromString(rule)));
        Observation o = new Observation(cpu1, new Date(), "85");
        dg.insertObservation(o);
        System.out.println("----------------------------------------");
        assertTrue(dg.evaluate() == 1);
        assertTrue(dg.evaluate() == 0);
        dg.removePackage("org.slasoi.llms.rules.testpackage1");
    }
