    public void test$C$pool() throws InterruptedException {
        DBConnectionPool pool = new DBConnectionPool(new OpConnectionTest(), new OpAdjConditionPool(), "base-base");
        for (int i = 0; i < 1000; ++i) {
            Connection con;
            con = pool.getConnection();
            System.out.println("i=" + i + "  con=" + con + " nUseed: " + pool.nUsed + " size:" + pool.queue.size());
            synchronized (this) {
                this.wait(10);
            }
        }
    }
