    public View match(ActionContext ac) {
        String regx = MENU_MATCH;
        if (!"null".equalsIgnoreCase(regx)) {
            matchPtn = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
            if (null == matchPtn || !matchPtn.matcher(ac.getPath()).find()) {
                ac.getRequest().setAttribute("menu", menuService.findAll());
                log.debug("完成菜单设置.");
            }
        }
        return null;
    }
