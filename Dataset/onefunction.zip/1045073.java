    protected TokenStream getTokenStream(final String strOrig, final boolean stemsAllowed, final boolean stopWordsAllowed) {
        if (stemsAllowed) {
            return new SnowballAnalyzer("Italian").tokenStream(null, new StringReader(strOrig));
        } else {
            return new StandardTokenizer(new StringReader(strOrig.toLowerCase()));
        }
    }
