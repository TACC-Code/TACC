    public void paintComponent(Graphics g) {
        super.paintComponents(g);
        Graphics2D g2 = (Graphics2D) g;
        Rectangle2D rect = new Rectangle2D.Double(leftX, topY, width, height);
        g2.setPaint(Color.RED);
        g2.fill(rect);
        Ellipse2D ellipse = new Ellipse2D.Double();
        ellipse.setFrame(rect);
        g2.setPaint(Color.BLUE);
        g2.fill(ellipse);
        g2.fill(new Line2D.Double(leftX, topY, leftX + width, topY + height));
        double centerY = rect.getCenterX();
        double centerX = rect.getCenterY();
        double radius = 150;
        Ellipse2D circle = new Ellipse2D.Double();
        circle.setFrameFromCenter(centerX, centerY, centerX + radius, centerY + radius);
        g2.setPaint(Color.YELLOW);
        g2.draw(circle);
        g2.setPaint(Color.GREEN);
        g2.setFont(new Font(null, Font.BOLD, 24));
        g2.drawString("Message", 200, 300);
    }
