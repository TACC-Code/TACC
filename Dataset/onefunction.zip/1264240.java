    public static void main(String[] args) {
        int choice = 0;
        System.out.println("1. Deadlock demo ");
        System.out.println("2. Insert/Update tables ");
        System.out.println("3. Execute given queries ");
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
        try {
            choice = Integer.parseInt(br.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch(choice) {
            case 1:
                int timeoutCount = 1;
                System.out.println("Enter number of 10 seconds intervals to increase Derby's wait timeout: ");
                System.out.println("Enter -1 to wait indefinitely ");
                try {
                    timeoutCount = Integer.parseInt(br.readLine());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                DeadLocker dl = new DeadLocker();
                dl.createDeadLock(2, timeoutCount);
                break;
            case 2:
                DataModifier modifier = new DataModifier();
                modifier.modify();
                break;
            case 3:
                SelectDAO sdao = new SelectDAO();
                sdao.daoSelect();
                break;
            default:
                System.out.println("Invalid choice: " + choice);
        }
    }
