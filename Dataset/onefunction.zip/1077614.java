    public static void main(String[] args) {
        Cache cache = Cache.getCacheInstance();
        try {
            cache.putStringInCache("firstName", "Vivek");
            cache.putStringInCache("lastName", "Mehta");
            cache.putStringInCache("Age", "18");
            System.out.println(cache.getStringFromCache("firstName"));
            System.out.println(cache.getStringFromCache("lastName"));
            System.out.println(cache.getStringFromCache("Age"));
            Thread cacheTestThread = new CacheTestingThread();
            cacheTestThread.start();
        } catch (CacheException e) {
            e.printStackTrace();
        }
    }
