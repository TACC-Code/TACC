    public void testProcessTrade() {
        try {
            Object o[] = new Object[1];
            Object o1 = o[5];
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            logger.debug(sw.toString());
        }
    }
