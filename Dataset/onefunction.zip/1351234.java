    public Corner(Vertex pos, int line1, int line2, CornerPosition align1, CornerPosition align2) {
        lines = new int[2];
        alignment = new CornerPosition[2];
        this.pos = pos;
        lines[0] = line1;
        lines[1] = line2;
        alignment[0] = align1;
        alignment[1] = align2;
    }
