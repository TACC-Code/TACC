    public ActionMessages resetCount(Integer companyId) throws DatabaseException {
        QueryHelper queryHelper = new QueryHelper(ContactQueries.updateCompanyBookmarkCountQuery());
        queryHelper.addInputInt(ObjectTypes.COMPANY);
        queryHelper.addInputInt(companyId);
        return executeProcedure(queryHelper);
    }
