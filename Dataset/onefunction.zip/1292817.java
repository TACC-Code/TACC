    public Result execute(HttpServletRequest req, InfoAccess infoaccess) {
        if (isGuest(req, infoaccess)) {
            return new Failure("Sorry, but the guest user may not create articles.");
        }
        PostRequest postReq = new PostRequest();
        try {
            postReq.parse(req, null, false);
        } catch (Exception e) {
            return new Failure(e.getMessage());
        }
        String name = postReq.getFormField(TArticles.F_NAME);
        String description = postReq.getFormField(TArticles.F_DESCRIPTION);
        Dictionary dict = Dictionaries.getDictionaryFromSession(req);
        HttpSession session = req.getSession();
        Integer userId = (Integer) session.getAttribute(SessionConstants.A_USERID);
        InfoBean user = infoaccess.get(TUsers.TBL_NAME, userId, true);
        final int language = (Integer) user.getProperty(TUsers.F_LANGUAGE);
        if (name == null || name.length() == 0) {
            name = dict.undefined();
        }
        TransactionContext tc = infoaccess.getTransaction();
        tc.begin();
        InfoBean article = infoaccess.create(TArticles.TBL_NAME);
        InfoBean category = infoaccess.get(TCategories.TBL_NAME, new Integer(TCategories.V_ID_UNDEFINED), true);
        article.setProperty(TArticles.F_NAME, name);
        article.setProperty(TArticles.F_DESCRIPTION, description);
        article.setProperty(TArticles.F_DATE, new Date());
        article.setProperty(TArticles.F_NUMCHARS_TITLE, 0);
        article.setProperty(TArticles.F_NUMCHARS_LEAD, 0);
        article.setProperty(TArticles.F_NUMCHARS_TEXT, 0);
        article.setProperty(TArticles.F_LOCATION, "");
        article.setProperty(TArticles.F_REQTIME, 0);
        article.setProperty(TArticles.F_CATEGORY, category);
        infoaccess.save(article, tc);
        InfoBean task = infoaccess.create(TTasks.TBL_NAME);
        task.setProperty(TTasks.F_ARTICLE, article);
        task.setProperty(TTasks.F_PHASE, Phases.ORIGINAL);
        task.setProperty(TTasks.F_LANGUAGE, language);
        task.setProperty(TTasks.F_NUMCHARS_TITLE, 0);
        task.setProperty(TTasks.F_NUMCHARS_LEAD, 0);
        task.setProperty(TTasks.F_NUMCHARS_TEXT, 0);
        task.setProperty(TTasks.F_USER, user);
        task.setProperty(TTasks.F_EDITDATETIME, new Date());
        task.setProperty(TTasks.F_DONE, new Boolean(false));
        infoaccess.save(task, tc);
        tc.commit();
        String msg = new UpdateAutoTasks().execute((Integer) article.getId(), infoaccess);
        if (msg == null) {
            return new Success("");
        } else {
            return new Failure(msg);
        }
    }
