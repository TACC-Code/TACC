    public void breakLine(String origData, float x1, float y1, float x2, float y2, boolean debugFlag) {
        int p = 0, end = origData.length();
        char[] line = origData.toCharArray();
        String raw = origData;
        String value = "", pt_reached = "", char_width = "";
        charsCounted = 0;
        endX = 0;
        startX = 0;
        brk = 0;
        float ptReached = 0, lastPt = 0;
        while (p < end) {
            while (true) {
                if (line[p] != PdfGroupingAlgorithms.MARKER2) {
                    int startPointer = p;
                    while ((p < end) && (line[p] != PdfGroupingAlgorithms.MARKER2)) p++;
                    value = raw.substring(startPointer, p);
                } else {
                    while ((p < end) && (line[p] != PdfGroupingAlgorithms.MARKER2)) p++;
                    p++;
                    int startPointer = p;
                    while ((p < end) && (line[p] != PdfGroupingAlgorithms.MARKER2)) p++;
                    pt_reached = raw.substring(startPointer, p);
                    p++;
                    startPointer = p;
                    while ((p < end) && (line[p] != PdfGroupingAlgorithms.MARKER2)) p++;
                    char_width = raw.substring(startPointer, p);
                    p++;
                    startPointer = p;
                    while ((p < end) && (line[p] != PdfGroupingAlgorithms.MARKER2)) {
                        charsCounted++;
                        p++;
                    }
                    value = raw.substring(startPointer, p);
                    ptReached = Float.parseFloat(pt_reached);
                    lastPt = ptReached + Float.parseFloat(char_width);
                    if (lastPt < x1) {
                        startX = lastPt;
                        brk = p;
                    } else if (ptReached > x2 && endX == 0) endX = ptReached;
                    if (debugFlag) System.out.println(value + " " + ptReached + " " + char_width + " startX=" + startX + " endX=" + endX);
                    if (ptReached > x2) break;
                    value = "";
                }
                if (p >= end) break;
            }
        }
    }
