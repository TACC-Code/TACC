    public void testMessageCanBeWriteToAndReadFromByteBuffer() throws Exception {
        BlobDataMessage msg = new BlobDataMessage();
        assertTrue(BlobDataMessage.MESSAGE_TYPE == msg.getMessageType());
        msg.setKeyHash(39048);
        Version version = new IncrementVersionFactory().create("1");
        msg.setVersion(version);
        msg.setBlob(new byte[10]);
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        BlobDataMessageMarshaller marshaller = new BlobDataMessageMarshaller(new IncrementVersionFactory());
        marshaller.writeObject(msg, new DataOutputStream(buffer));
        assertEquals("Payload length is incorrect", EXPECTED_BYTES, buffer.toByteArray().length);
        BlobDataMessage newMsg = marshaller.readObject(new DataInputStream(new ByteArrayInputStream(buffer.toByteArray())));
        assertEquals("Key hash is deserialized incorrectly", msg.getKeyHash(), newMsg.getKeyHash());
        assertEquals(msg.getVersion(), newMsg.getVersion());
        assertEquals(msg.getBlob().length, newMsg.getBlob().length);
    }
