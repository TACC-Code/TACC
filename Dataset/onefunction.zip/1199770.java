    public JSONObject convert(ChangesSalary source) {
        if (source == null) {
            return null;
        }
        try {
            JSONObject jsonObject = new JSONObject();
            System.out.println("ChangesSalaryID: " + source.getId());
            jsonObject.accumulate("id", source.getId());
            jsonObject.accumulate("number", source.getNumber());
            jsonObject.accumulate("to_date", DateUtils.convertToString(source.getToDate(), SystemConfigurationUtils.getString("SYS_DATE_FORMAT", "dd/MM/yyyy")));
            jsonObject.accumulate("fr_date", DateUtils.convertToString(source.getFromDate(), SystemConfigurationUtils.getString("SYS_DATE_FORMAT", "dd/MM/yyyy")));
            jsonObject.accumulate("scale", StringUtils.getValue(source.getScale(), ""));
            jsonObject.accumulate("scal_code", source.getScaleCode());
            jsonObject.accumulate("sala_scal", source.getSalaryScale());
            jsonObject.accumulate("coeff", source.getCoefficient());
            jsonObject.accumulate("over_limit", source.getOverLimit());
            jsonObject.accumulate("coeff_over_limit", source.getCoefficientOverLimit());
            jsonObject.accumulate("reserv", source.getReservations());
            jsonObject.accumulate("attraction", source.getAttraction());
            jsonObject.accumulate("area_allowance", source.getAreaAllowance());
            jsonObject.accumulate("posi_allowance", source.getPositionAllowance());
            jsonObject.accumulate("resp_allowance", source.getResponsibilityAllowance());
            jsonObject.accumulate("pref_allowance", source.getPreferentialAllowance());
            jsonObject.accumulate("version", source.getVersion());
            return jsonObject;
        } catch (JSONException ex) {
            throw new IllegalStateException("Could not converter to changesSalary json", ex);
        } catch (Exception ex) {
            throw new IllegalStateException("Could not converter to changesSalary json", ex);
        }
    }
