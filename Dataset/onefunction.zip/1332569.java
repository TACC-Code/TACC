    protected GuacamoleTunnel doConnect(HttpServletRequest request) throws GuacamoleException {
        HttpSession httpSession = request.getSession(true);
        String id = request.getParameter("id");
        Map<String, GuacamoleConfiguration> configs = (Map<String, GuacamoleConfiguration>) httpSession.getAttribute("GUAC_CONFIGS");
        if (configs == null) throw new GuacamoleException("Cannot connect - user not logged in.");
        GuacamoleConfiguration config = configs.get(id);
        if (config == null) {
            logger.error("Error retrieving authorized configuration id={}.", id);
            throw new GuacamoleException("Unknown configuration ID.");
        }
        logger.info("Successful connection from {} to \"{}\".", request.getRemoteAddr(), id);
        String hostname = GuacamoleProperties.getProperty(GuacamoleProperties.GUACD_HOSTNAME);
        int port = GuacamoleProperties.getProperty(GuacamoleProperties.GUACD_PORT);
        GuacamoleSocket socket = new ConfiguredGuacamoleSocket(new InetGuacamoleSocket(hostname, port), config);
        GuacamoleTunnel tunnel = new GuacamoleTunnel(socket);
        GuacamoleSession session = new GuacamoleSession(httpSession);
        session.attachTunnel(tunnel);
        return tunnel;
    }
