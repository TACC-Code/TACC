    public boolean execute(Context context) throws Exception {
        final MethodCallCtx callCtx = CtxHelper.get(context, MethodCallCtx.class);
        final Connection connection = ConnectionHandlerHelper.getConnection(context);
        ConnectionHandlerHelper.putConnectionOnHold(context);
        callCtx.setLastReturn(connection);
        return CONTINUE_PROCESSING;
    }
