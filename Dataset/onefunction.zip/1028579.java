    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        double iArista;
        double iVolumen;
        System.out.println("Introduce el valor de la arista del cubo");
        iArista = reader.nextDouble();
        iVolumen = Math.pow(iArista, 3);
        System.out.println("El volumen de un cubo de arista " + Double.toString(iArista) + " es de " + Double.toString(iVolumen));
    }
