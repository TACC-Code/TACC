    public void parseData(GarminData data) {
        setSatteliteID(new Integer(SVID_FIELD.get(data)));
        setWeekNumber(WEEK_NUMBER_FIELD.get(data));
        setToa(TOA_FIELD.get(data));
        setAf0(AF0_FIELD.get(data));
        setAf1(AF1_FIELD.get(data));
        setE(E_FIELD.get(data));
        setSqrta(SQRTA_FIELD.get(data));
        setM0(M0_FIELD.get(data));
        setW(W_FIELD.get(data));
        setOmg0(OMG0_FIELD.get(data));
        setOdot(ODOT_FIELD.get(data));
        setInclination(INCLINATION_FIELD.get(data));
    }
