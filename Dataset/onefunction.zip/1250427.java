    public SubCapitalCannonWeapon() {
        super();
        ammoType = AmmoType.T_SCC;
        atClass = CLASS_CAPITAL_AC;
        flags = flags.or(F_DIRECT_FIRE).or(F_BALLISTIC);
        capital = true;
        subCapital = true;
    }
