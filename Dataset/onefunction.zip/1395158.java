    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        User u = (User) request.getSession().getAttribute(GlobalConstants.USER_KEY);
        ActionErrors errs = new ActionErrors();
        ActionMessages msgs = new ActionMessages();
        if (u == null) {
            errs.add("error.display", new ActionMessage("error.message", "Session has expired!  Please sign in again"));
            saveErrors(request, errs);
            return (mapping.findForward("goto.home"));
        }
        try {
            String file = request.getParameter("file");
            if ((file == null) || file.equals("")) {
                System.out.println("CreateNewFile: File name not specified");
                errs.add("error.display", new ActionMessage("error.message", "File name not specified"));
                saveErrors(request, errs);
                request.setAttribute("content", request.getParameter("content"));
                return (mapping.findForward("create.file"));
            } else {
                u.AddFile(file);
                msgs.add("edit.results", new ActionMessage("edit.success", "New file saved to " + file));
                GlobalConstants.GetDBInterface().UpdateUser(u);
                PrintWriter pw = Misc.GetUTF8Writer(GlobalConstants.GetDBInterface().GetOutputStream(u, file));
                pw.print(request.getParameter("content"));
                pw.close();
            }
        } catch (Exception e) {
            System.out.println("Error saving file!" + e.toString());
            e.printStackTrace();
            String emsg = e.toString();
            errs.add("error.display", new ActionMessage("error.message", "Exception while saving file! <br>" + emsg));
        }
        saveErrors(request, errs);
        saveMessages(request, msgs);
        return (mapping.findForward("goto.edit"));
    }
