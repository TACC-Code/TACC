    protected Object doInvoke(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        String methodName = proceedingJoinPoint.getSignature().getName();
        if (methodName.equals("addTemplate") || methodName.equals("addTemplateToGroup") || methodName.equals("deleteTemplate") || methodName.equals("deleteTemplates") || methodName.equals("getTemplate") || methodName.equals("getTemplateBySmallImageId") || methodName.equals("updateTemplate")) {
            TemplateInvoker templateInvoker = new TemplateInvoker(proceedingJoinPoint);
            if (methodName.equals("addTemplate") || methodName.equals("addTemplateToGroup")) {
                contentTypeService.addTemplateToContentType(templateInvoker, null);
            } else if (methodName.equals("deleteTemplate")) {
                contentTypeService.deleteTemplateOfContentType(null, templateInvoker);
            } else if (methodName.equals("deleteTemplates")) {
                contentTypeService.deleteTemplatesOfContentType(null, new TemplateInvoker[] { templateInvoker });
            } else if (methodName.equals("getTemplate") || methodName.equals("getTemplateBySmallImageId")) {
                contentTypeService.getTemplate(templateInvoker, null);
            } else if (methodName.equals("updateTemplate")) {
                contentTypeService.updateTemplateOfContentType(templateInvoker, null);
            }
            return templateInvoker.getReturnValue();
        } else if (methodName.equals("getStructureTemplates") || methodName.equals("getTemplates") || methodName.equals("getTemplatesCount") || methodName.equals("search") || methodName.equals("searchCount")) {
            SearchCriteriaInvoker searchCriteriaInvoker = new SearchCriteriaInvoker(proceedingJoinPoint);
            if (methodName.equals("getStructureTemplates") || methodName.equals("getTemplates") || methodName.equals("search")) {
                contentTypeService.searchTemplates(searchCriteriaInvoker);
            } else if (methodName.equals("getTemplatesCount") || methodName.equals("searchCount")) {
                contentTypeService.searchTemplatesCount(searchCriteriaInvoker);
            }
            return searchCriteriaInvoker.getReturnValue();
        } else {
            return proceedingJoinPoint.proceed();
        }
    }
