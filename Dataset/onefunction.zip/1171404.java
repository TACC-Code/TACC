    public static void main(String[] args) {
        try {
            DfpServiceLogger.log();
            DfpUser user = new DfpUser();
            ReportServiceInterface reportService = user.getService(DfpService.V201203.REPORT_SERVICE);
            ReportJob reportJob = new ReportJob();
            ReportQuery reportQuery = new ReportQuery();
            reportQuery.setDateRangeType(DateRangeType.LAST_WEEK);
            reportQuery.setDimensions(new Dimension[] { Dimension.DATE });
            reportQuery.setColumns(new Column[] { Column.AD_SERVER_IMPRESSIONS, Column.AD_SERVER_CLICKS, Column.ADSENSE_IMPRESSIONS, Column.ADSENSE_CLICKS, Column.TOTAL_IMPRESSIONS, Column.TOTAL_REVENUE });
            reportQuery.setAdUnitView(ReportQueryAdUnitView.HIERARCHICAL);
            reportJob.setReportQuery(reportQuery);
            reportJob = reportService.runReportJob(reportJob);
            do {
                System.out.println("Report with ID '" + reportJob.getId() + "' is still running.");
                Thread.sleep(30000);
                reportJob = reportService.getReportJob(reportJob.getId());
            } while (reportJob.getReportJobStatus() == ReportJobStatus.IN_PROGRESS);
            if (reportJob.getReportJobStatus() == ReportJobStatus.FAILED) {
                System.out.println("Report job with ID '" + reportJob.getId() + "' failed to finish successfully.");
            } else {
                System.out.println("Report job with ID '" + reportJob.getId() + "' completed successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
