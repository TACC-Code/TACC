    public void perform(HttpServlet servlet, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        DOMConfigurator.configure(AnnouncementUserAction.class.getResource("/log4j.xml"));
        String sUserId = request.getParameter("userId");
        AnnouncementEvent announcementEvent = new AnnouncementEvent();
        serviceResult = new RestServiceResult();
        dataManager = new DataManager();
        dataManager.setBundle(this.loadResourceBundle(request));
        log.info("Obteniendo la lista de anuncios del sistema");
        if (Util.validateStringNumeric(log, sUserId)) {
            List arrayUsersId = new ArrayList();
            arrayUsersId.add(sUserId);
            announcementEvent.setArrayUsersId(arrayUsersId);
            announcementEvent.setTypeEvent(Constant.ALL_ANNOUNCEMENT);
            try {
                JadeGateway.execute(announcementEvent);
                List listAnnouncement = announcementEvent.getListAnnouncement();
                if (listAnnouncement == null) {
                    listAnnouncement = new ArrayList();
                }
                Object[] arrayParam = { listAnnouncement.size() };
                serviceResult.setMessage(MessageFormat.format(dataManager.getBundle().getString("listAnnouncement.list.success"), arrayParam));
                serviceResult.setNumResult(listAnnouncement.size());
                serviceResult.setObjResult(listAnnouncement);
            } catch (Exception e) {
                e.printStackTrace();
                serviceResult.setMessage(dataManager.getBundle().getString("listAnnouncement.list.notFound"));
                serviceResult.setError(true);
            }
        } else {
            serviceResult.setMessage(dataManager.getBundle().getString("listAnnouncement.list.notFound"));
            serviceResult.setError(true);
        }
        dispatcher = servlet.getServletContext().getRequestDispatcher(LIST_ANNOUNCEMENT_JSP);
        request.setAttribute("result", serviceResult);
        dispatcher.forward(request, response);
    }
