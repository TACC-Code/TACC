    public ActionForward doExecute(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        httpServletRequest.setAttribute("message", "CheckStoreReadAction");
        httpServletRequest.setAttribute("action", "CheckStoreWriteAction");
        super.getDriverInputParameters(httpServletRequest, httpServletResponse);
        return actionMapping.findForward("read");
    }
