    void theMethod() {
        try {
        } catch (Error e) {
            throw new Error();
        }
    }
