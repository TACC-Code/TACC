    public static void clearMDC() {
        Hashtable htable = MDC.getContext();
        if (htable != null) {
            Iterator keyIterator = htable.keySet().iterator();
            while (keyIterator.hasNext()) {
                String key = (String) keyIterator.next();
                MDC.remove(key);
            }
        }
    }
