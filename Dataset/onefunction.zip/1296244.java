    public static void main(String[] args) {
        BusinessLogic business = (BusinessLogic) LoggingProxyAspect.bind(SecurityProxyAspect.bind(new BusinessLogicCoreConcern()));
        business.businessMethod1();
        System.out.println();
        business.businessMethod2();
    }
