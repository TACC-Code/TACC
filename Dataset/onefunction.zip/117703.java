    public HelpJPanel(MainController controller) {
        super(controller);
        hauteur = GraphicsParameters.mainHeight - 100;
        largeur = 943;
        scrollPane = new JScrollPane(new HelpJEditorPane());
        scrollPane.setBounds(0, 0, largeur, hauteur);
        add(scrollPane);
    }
