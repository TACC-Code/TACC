    public static String encodePassword1(String pwd) {
        if (pwd == null || pwd.length() == 0) {
            return pwd;
        }
        return pwd + "lala";
    }
