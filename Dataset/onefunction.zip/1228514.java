    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        SiteminderService smService = (SiteminderService) session.getAttribute("SiteMinderSession");
        String requestTask = request.getParameter("task");
        SmPasswordPolicy smPasswordPolicy = new SmPasswordPolicy();
        HashMap dirMap = new HashMap();
        try {
            if (requestTask.compareToIgnoreCase("new") == 0) {
                smPasswordPolicy.setName("New Password Policy");
                smPasswordPolicy.setEnabled(false);
                smPasswordPolicy.setEntireDir(true);
                smPasswordPolicy.setPasswordBehavior(0);
                dirMap = smService.smapi.userDirectoryApiObj.getUserDirectories();
            } else if (requestTask.compareToIgnoreCase("modify") == 0) {
                smService.smapi.getPolicyApi().getPasswordPolicy(request.getParameter("passwordPolicyOid"), smPasswordPolicy);
                dirMap = smService.smapi.userDirectoryApiObj.getUserDirectories();
            } else if (requestTask.compareToIgnoreCase("delete") == 0) {
                smService.smapi.getPolicyApi().deletePasswordPolicy(request.getParameter("passwordPolicyOid"));
            }
        } catch (SmApiException ex) {
            ActionMessages errors = new ActionMessages();
            ActionMessage error = new ActionMessage("error.siteminder.getPWS", "Error Setting Up Password Policy");
            errors.add(ActionMessages.GLOBAL_MESSAGE, error);
            saveErrors(request, errors);
            return (mapping.findForward("error"));
        }
        ActionForward myActionFwd = new ActionForward();
        if (requestTask.compareToIgnoreCase("delete") != 0) {
            PasswordPolicyForm passwordPolicyForm = (PasswordPolicyForm) form;
            passwordPolicyForm.setSmPasswordPolicy(smPasswordPolicy);
            passwordPolicyForm.setOid(smPasswordPolicy.getOid().toString());
            passwordPolicyForm.setEnabled(smPasswordPolicy.isEnabled());
            passwordPolicyForm.setIsEntireDir(smPasswordPolicy.isEntireDir());
            passwordPolicyForm.setDirMap(dirMap);
            passwordPolicyForm.setDirOid(smPasswordPolicy.getUserDirectoryOid().getOidString());
            passwordPolicyForm.setRequestTask(requestTask);
            int pwBehavior = smPasswordPolicy.getPasswordBehavior();
            passwordPolicyForm.setDontTrackSuccessLogins(SiteminderUtils.getDontTrackSucccessfulLogins(pwBehavior));
            passwordPolicyForm.setDontTrackFailedLogins(SiteminderUtils.getDontTrackFailedLogins(pwBehavior));
            passwordPolicyForm.setAllowFailedWrites(SiteminderUtils.getAllowFailedWrites(pwBehavior));
            passwordPolicyForm.setInactivityForcePWChange(SiteminderUtils.getInactivityForcePWChange(pwBehavior));
            passwordPolicyForm.setPwExpiredForcePWChange(SiteminderUtils.getPWExpiredForcePWChange(pwBehavior));
            myActionFwd = mapping.findForward("continue");
        } else if (requestTask.compareToIgnoreCase("delete") == 0) {
            ActionMessages messages = new ActionMessages();
            String fullMsg = MessageResources.getMessageResources("ApplicationResources").getMessage("title.pws.delete.confirmation.message") + smPasswordPolicy.getName();
            System.out.println("SetupPasswordPolicyAction --> " + fullMsg);
            ActionMessage message = new ActionMessage("title.policy.delete.confirmation.message", smPasswordPolicy.getName());
            messages.add(ActionMessages.GLOBAL_MESSAGE, message);
            saveMessages(request, messages);
            myActionFwd = mapping.findForward("system_success");
        }
        return myActionFwd;
    }
