    public IModulo factoryMethod(ModuloType moduloType) {
        switch(moduloType) {
            case PLAYER:
                return ModuloPlayerBrazo.getInstance();
            case STAGE:
                return ModuloStageBrazo.getInstance();
        }
        throw new IllegalArgumentException("moduloType " + moduloType + " is not valid.");
    }
