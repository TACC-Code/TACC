    public List<String> getCmdList() {
        final CommandStringBuilder builder = new CommandStringBuilder(LSF.BSUB_EXE);
        builder.addAllFlagCommands(LSF.getBsubFlagCommandStrings());
        builder.addAllValueCommands(LSF.getBsubValueCommandStrings(workingDir));
        builder.addAllFlagCommands(ConradConstants.getConradCmdString());
        builder.addFlagCommand("train");
        builder.addFlagCommand("models/singleSpecies.xml");
        builder.addFlagCommand(workingDir.getAbsolutePath());
        builder.addFlagCommand(TRAINING_FILE.getAbsolutePath());
        return builder.getCommandList();
    }
