    public static boolean quickCheck(String domain) {
        if (domain == null || "".equals(domain)) return false;
        if ("localhost".equalsIgnoreCase(domain) || "localhost.localdomain".equalsIgnoreCase(domain) || domain.startsWith("127.0.0.") || domain.startsWith("192.168.") || domain.startsWith("169.254.") || domain.startsWith("10.") || domain.startsWith("172.") || domain.indexOf('.') == -1) return false;
        if (domain.equals(AC.serverIP.getPublicIP())) return false;
        if (hostName != null && hostName.equalsIgnoreCase(domain)) {
            return false;
        }
        if (ConfigManager.getInstance().getConfig(ConfigManager.OWNER).getBoolean(ApplicationConstants.ALLOW_ALL_SITE)) {
            return true;
        }
        String lowerCaseDomain = domain.toLowerCase();
        for (Iterator<String> itr = permitList.iterator(); itr.hasNext(); ) {
            String permitDomain = itr.next();
            if (lowerCaseDomain.endsWith(permitDomain)) return true;
        }
        return false;
    }
