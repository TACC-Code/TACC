    public static void main(String[] args) {
        ScriptBasedCoralAgent agent = new ScriptBasedCoralAgent("rem");
        try {
            agent.construct("com/agentfactory/coral/core/Basic.coral");
            agent.execute();
            agent.execute();
        } catch (AgentCreationException e) {
            e.printStackTrace();
        }
    }
