    public BusyProjectListWidget() {
        final Label l = new Label("Loading...");
        final VerticalPanel panel = new VerticalPanel();
        final Image loadingImg = new Image();
        l.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
        panel.add(l);
        loadingImg.setUrl(loaderSmallURL);
        panel.add(loadingImg);
        panel.setSize("100%", "100%");
        panel.setCellHorizontalAlignment(loadingImg, HasHorizontalAlignment.ALIGN_CENTER);
        panel.setCellVerticalAlignment(loadingImg, HasVerticalAlignment.ALIGN_MIDDLE);
        panel.setVerticalAlignment(HasVerticalAlignment.ALIGN_MIDDLE);
        panel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
        this.initWidget(panel);
    }
