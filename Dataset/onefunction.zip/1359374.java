    public static List<Resources> readXml(InputStream inStream) throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        SAXParser sp = spf.newSAXParser();
        XMLContentHandler handler = new XMLContentHandler();
        sp.parse(inStream, handler);
        return handler.getResources();
    }
