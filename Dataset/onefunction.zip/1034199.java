    public List<Sonorizacao> buscarPorFilme(Filme filme) {
        Criteria crit = getSession().createCriteria(Sonorizacao.class);
        crit.add(Restrictions.eq("filme", filme));
        crit.setFetchMode("fornecedorSom", FetchMode.JOIN);
        crit.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        crit.addOrder(Order.asc("dataInicio"));
        return crit.list();
    }
