    public static List convertCommaDelimitedStringToList(String s) {
        List result = null;
        if (s != null) {
            result = new ArrayList();
            String[] valueArray = s.split(",");
            for (int i = 0; i < valueArray.length; i++) {
                String value = valueArray[i];
                if (value != null) {
                    value = value.trim();
                    if (!"".equals(value)) {
                        result.add(value);
                    }
                }
            }
        }
        return result;
    }
