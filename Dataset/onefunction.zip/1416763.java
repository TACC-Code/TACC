    public void test() throws InterruptedException {
        GenericApplicationContext context = new GenericApplicationContext();
        XmlBeanDefinitionReader xmlReader = new XmlBeanDefinitionReader(context);
        xmlReader.loadBeanDefinitions(new ClassPathResource("expandable/core-context.xml"));
        context.refresh();
        RootModuleContextMonitor monitor = new RootModuleContextMonitor(xmlReader, new ClassPathResource("expandable/spring-locations.txt"), new ScheduledThreadPoolExecutor(1));
        monitor.setupMonitor();
        context.getBean("coreBean");
        while (true) {
            try {
                Thread.sleep(1000);
                Object bean = context.getBean("extraBean");
                System.out.println("Found bean named 'extraBean' in context: " + bean.getClass().getName());
            } catch (NoSuchBeanDefinitionException e) {
                System.out.println("No bean named 'extraBean' found in context");
            }
        }
    }
