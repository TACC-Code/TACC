    public DeviceMessage(int id, String device, String name, int extraBytes) {
        this.device = device;
        this.id = id;
        this.name = name;
        this.extraBytes = extraBytes;
    }
