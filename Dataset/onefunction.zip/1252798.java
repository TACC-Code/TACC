    public void testSplitPath() {
        List<String> results = HttpServletRequestUtils.splitPath("/directories/jsonrpc2/findDoctors?lastName=\"blah\"");
        assertEquals(2, results.size());
        results = HttpServletRequestUtils.splitPath("/findDoctors?lastName=\"blah\"");
        assertEquals(2, results.size());
        results = HttpServletRequestUtils.splitPath("findDoctors?lastName=\"blah\"");
        assertEquals(2, results.size());
        results = HttpServletRequestUtils.splitPath("/directories/jsonrpc2/findDoctors");
        assertEquals(1, results.size());
        results = HttpServletRequestUtils.splitPath("directories/jsonrpc2/findDoctors");
        assertEquals(1, results.size());
        results = HttpServletRequestUtils.splitPath("findDoctors");
        assertEquals(1, results.size());
        results = HttpServletRequestUtils.splitPath("/findDoctors");
        assertEquals(1, results.size());
    }
