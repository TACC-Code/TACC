    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        CustomTreeCellRenderer component = (CustomTreeCellRenderer) super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
        if (value instanceof DefaultMutableTreeNode) {
            DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) value;
            if (treeNode.getUserObject() instanceof AbstractComponent) {
                AbstractComponent userComponent = (AbstractComponent) treeNode.getUserObject();
                Icon icon = userComponent.getIcon();
                if (icon != null) {
                    component.setIcon(icon);
                }
                Color color = userComponent.getForegroundColor();
                if (color != null) {
                    component.setForeground(color);
                } else {
                    component.setForeground(Color.BLACK);
                }
            }
        }
        return component;
    }
