    public static void main(String[] str) {
        User user = new User();
        user.setName("noukey1413");
        user.setPassword("weihua");
        user.setEmail("noukey1413@gmail.com");
        UserDAO dao = User.getDAO();
        if (dao.addNew(user)) {
            System.out.println(user.getId());
        } else {
            System.out.println(dao.getErrorCode());
        }
    }
