    public CLLRM15IOS() {
        super();
        techLevel = TechConstants.T_CLAN_ADVANCED;
        name = "LRM 15 (I-OS)";
        setInternalName("CLLRM15 (IOS)");
        addLookupName("Clan IOS LRM-15");
        addLookupName("Clan LRM 15 (IOS)");
        heat = 5;
        rackSize = 15;
        minimumRange = WEAPON_NA;
        tonnage = 3.0f;
        criticals = 2;
        bv = 33;
        flags = flags.or(F_ONESHOT);
        cost = 140000;
        shortAV = 9;
        medAV = 9;
        longAV = 9;
        maxRange = RANGE_LONG;
    }
