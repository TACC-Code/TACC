    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String virtualWiki = null;
        String topic = null;
        try {
            virtualWiki = (String) request.getAttribute("virtual-wiki");
            String action = request.getParameter("notify_action");
            topic = request.getParameter("topic");
            if (topic == null || topic.equals("")) throw new WikiException("Topic must be specified");
            String user = "";
            Cookie[] cookies = request.getCookies();
            if (cookies != null) if (cookies.length > 0) for (int i = 0; i < cookies.length; i++) if (cookies[i].getName().equals("username")) user = cookies[i].getValue();
            if (user == null || user.equals("")) throw new WikiException("User name not found.");
            Notify notifier = WikiBase.getInstance().getNotifyInstance(virtualWiki, topic);
            if (action == null || action.equals("Notify Me")) {
                notifier.addMember(user);
            } else {
                notifier.removeMember(user);
            }
        } catch (Exception e) {
            throw new ServletException(e.getMessage(), e);
        }
        String next = request.getContextPath() + "/" + virtualWiki + "/Wiki?" + topic;
        response.sendRedirect(response.encodeRedirectURL(next));
    }
