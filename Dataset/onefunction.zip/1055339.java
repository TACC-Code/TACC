    public void simpleTest() {
        Person dad = new Person("George", 55);
        Person a = new Person("Andy", 31);
        Person b = new Person("Bob", 29);
        dad.setChildren(Arrays.asList(a, b));
        BeanWithChildrenTreeContentProvider tc = new BeanWithChildrenTreeContentProvider(dad, "children");
        assertEquals(tc.getElements().size(), 1);
        assertEquals(tc.getElements().get(0), dad);
        assertEquals(tc.getParent(a), dad);
        assertTrue(tc.hasChildren(dad));
        assertFalse(tc.hasChildren(a));
    }
