    public Map<String, Object> getConfigList() {
        Map<String, Object> configMap = new HashMap<String, Object>();
        try {
            ConfigurationFactory factory = ConfigurationFactory.getInstance();
            Configuration config = factory.getControllerXMLConfig("", new String[] { "" });
            configMap = config.getConfigMap();
        } catch (Exception ex) {
            log.error("Front controller config exception : " + ex.getMessage());
            ex.printStackTrace();
        }
        return configMap;
    }
