    protected void setMenuItemTextAndAccelerator(MenuItem menuItem, String key, String action) {
        String text = TuxGuitar.getProperty(key);
        if (action != null) {
            KeyBinding keyBinding = TuxGuitar.instance().getkeyBindingManager().getKeyBindingForAction(action);
            if (keyBinding != null) {
                text += "\t" + keyBinding.toString();
            }
        }
        menuItem.setText(text);
    }
