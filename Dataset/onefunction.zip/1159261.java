    public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
        A a = (A) source;
        B b = (B) destination;
        if (a.getCode() == 1) {
            b.setCode("中国");
        }
        return b;
    }
