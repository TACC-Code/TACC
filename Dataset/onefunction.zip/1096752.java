    public Map<String, LayoutAlgorithm> generateClusteredLayoutAlgorithms(Map<String, Map<String, Node>> contextBasedNodeMaps) {
        Map<String, LayoutAlgorithm> layoutAlgorithms = new Hashtable<String, LayoutAlgorithm>();
        for (String contextValue : contextBasedNodeMaps.keySet()) {
            SpringLayoutAlgorithm layoutAlgorithm = new SpringLayoutAlgorithm(contextBasedNodeMaps.get(contextValue), 0.001, 10.0, 26000000.0, 10.0);
            layoutAlgorithms.put(contextValue, layoutAlgorithm);
        }
        return layoutAlgorithms;
    }
