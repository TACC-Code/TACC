    public MainMenuBar() throws IOException {
        super("MainMenuBar", Application.getResources().getString("gui.MainMenuBar.title"), CommandMenuBar.HORIZONTAL);
        this.add(fileMenu);
        this.add(editMenu);
        this.add(viewMenu);
        this.add(chartMenu);
        this.add(serviceMenu);
        this.add(helpMenu);
        this.fileMenu.add(viewSymbolMenu);
        this.fileMenu.add(viewNewsMenu);
        this.fileMenu.add(viewFactorMenu);
        this.fileMenu.addSeparator();
        this.fileMenu.add(editSymbolMenu);
        this.fileMenu.add(editNewsMenu);
        this.fileMenu.add(editFactorMenu);
        this.fileMenu.addSeparator();
        this.fileMenu.add(exitMenu);
    }
