    public static Test suite() {
        TestSuite suite = new TestSuite("Test for DES");
        suite.addTestSuite(TestCalcRoundKeys.class);
        suite.addTestSuite(TestIP.class);
        suite.addTestSuite(TestPI.class);
        suite.addTestSuite(TestPC1.class);
        suite.addTestSuite(TestPC2.class);
        suite.addTestSuite(TestE.class);
        suite.addTestSuite(TestP.class);
        suite.addTestSuite(TestSBox1.class);
        suite.addTestSuite(TestSBox2.class);
        suite.addTestSuite(TestSBox3.class);
        suite.addTestSuite(TestSBox4.class);
        suite.addTestSuite(TestSBox5.class);
        suite.addTestSuite(TestSBox6.class);
        suite.addTestSuite(TestSBox7.class);
        suite.addTestSuite(TestSBox8.class);
        suite.addTestSuite(TestDES.class);
        return suite;
    }
