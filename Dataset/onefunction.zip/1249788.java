    public void testToString() {
        assertEquals("A()", new Agent("A", null).toString());
        assertEquals("A()", new Agent("A", new ArrayList<Site>()).toString());
        assertEquals("A(a)", new Agent("A", Collections.singletonList((Site) new Site("A", "a", null, null))).toString());
        assertEquals("A(a, b)", new Agent("A", Arrays.asList(new Site[] { new Site("A", "a", null, null), new Site("A", "b", null, null) })).toString());
    }
