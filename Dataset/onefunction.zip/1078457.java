    public static Map create(int size, float loadFactor, int concurrencyLevel, boolean allowNullKeys) {
        Map map = null;
        if (concurrencyLevel <= 1) {
            map = new HashMap(size, loadFactor);
        } else {
            if (concurrentHashMapConstructor != null) {
                try {
                    map = (Map) concurrentHashMapConstructor.newInstance(new Object[] { new Integer(size), new Float(loadFactor), new Integer(concurrencyLevel) });
                } catch (Exception ex) {
                    throw new RuntimeException("this should not happen", ex);
                }
            } else {
                if (allowNullKeys) {
                    map = Collections.synchronizedMap(new HashMap(size, loadFactor));
                } else {
                    map = new Hashtable(size, loadFactor);
                }
            }
        }
        return map;
    }
