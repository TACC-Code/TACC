    public void testCompile() throws IOException {
        AnnotationCompiler compiler = new AnnotationCompiler();
        compiler.setClasspath(new String[] { "." });
        {
            String bin = System.getProperty("openfrwk.bin.dir", "bin");
            boolean isBaseDir = Boolean.getBoolean("openfrwk.base.dir");
            String baseDir = (isBaseDir) ? "" : "openfrwk-instrument/openfrwk-instrument-jdk14/";
            File f = new File(bin);
            if (!f.exists()) {
                System.out.println("not exist :: " + f);
                throw new IOException("File binary directory does not exist");
            }
            compiler.setDestDir(f.toString());
            compiler.setClasspath(new String[] { f.toString() });
            compiler.setSourceDirs(new String[] { baseDir + "src/test/java" });
            compiler.setSourceFiles(new String[] { baseDir + "src/test/java/org/nexopenframework/example/services/MyService.java" });
        }
        compiler.init();
        assertTrue(Annotations.isAnnotationPresent(Service.class, "org.nexopenframework.example.services.MyService"));
        assertTrue(Annotations.isMethodAnnotationPresent(ServiceLifecycle.class, "org.nexopenframework.example.services.MyService", "init", "()V"));
    }
