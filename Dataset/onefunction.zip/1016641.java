    public static MediaConfig getConfig() {
        Parameters params = new ParametersImpl();
        Set<Parameter> parameters = new HashSet();
        parameters.add(MediaObject.MEDIAOBJECT_ID);
        parameters.add(MediaMixer.ENABLED_EVENTS);
        parameters.add(MediaMixer.MAX_ACTIVE_INPUTS);
        parameters.add(MediaMixer.MAX_PORTS);
        Set<EventType> eventTypes = new HashSet();
        eventTypes.add(MixerEvent.ACTIVE_INPUTS_CHANGED);
        eventTypes.add(MixerEvent.MOST_ACTIVE_INPUT_CHANGED);
        Set<Action> actions = new HashSet();
        Set<Qualifier> qualifiers = new HashSet();
        Set<Trigger> triggers = new HashSet();
        Set<Value> values = new HashSet();
        SupportedFeaturesImpl features = new SupportedFeaturesImpl(parameters, actions, eventTypes, qualifiers, triggers, values);
        return new MediaConfigImpl(features, params);
    }
