    public ServerSocket createServerSocket(int port) throws IOException {
        try {
            if (serverSocketFactory == null || keystoreFileChanged) {
                File keystorePropFile = new File("jfire-server.keystore.properties").getAbsoluteFile();
                Properties props = new Properties();
                if (keystorePropFile.exists()) {
                    FileInputStream keystorePropsFileStream = null;
                    try {
                        keystorePropsFileStream = new FileInputStream(keystorePropFile);
                        props.load(keystorePropsFileStream);
                    } finally {
                        if (keystorePropsFileStream != null) keystorePropsFileStream.close();
                    }
                } else {
                    props.put("org.nightlabs.ssl.keystorePassword", System.getProperty("javax.net.ssl.trustStorePassword"));
                }
                final String selectedCertificate = props.getProperty("org.nightlabs.ssl.serverCertificateAlias");
                String keystorePassword = props.getProperty("org.nightlabs.ssl.keystorePassword");
                if (keystorePassword == null) keystorePassword = "";
                String selectedCertificatePassword = props.getProperty("org.nightlabs.ssl.serverCertificatePassword");
                if (selectedCertificatePassword == null) selectedCertificatePassword = "";
                InputStream in = new BufferedInputStream(new FileInputStream(keystoreFile));
                try {
                    serverSocketFactory = new SSLCompressionServerSocketFactory(in, keystorePassword.toCharArray(), selectedCertificate, selectedCertificatePassword.toCharArray(), Config.compressionEnabled);
                } finally {
                    in.close();
                }
                keystoreFileChanged = false;
            }
            SSLServerSocket serverSocket = (SSLServerSocket) serverSocketFactory.createServerSocket(port);
            serverSocket.setNeedClientAuth(false);
            return serverSocket;
        } catch (IOException x) {
            logger.error("createServerSocket: " + x.getMessage(), x);
            throw x;
        } catch (Throwable t) {
            logger.error("createServerSocket: " + t.getMessage(), t);
            IOException x = new IOException();
            x.initCause(t);
            throw x;
        }
    }
