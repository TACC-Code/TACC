    public static Request createACKRequest(SIPMessage invite, String dialog) throws NullPointerException, java.text.ParseException, InvalidArgumentException, SipException {
        LOGGER.info("Creation of ACK Request is started");
        MessageFactoryImpl messageFactoryImpl = new MessageFactoryImpl();
        Request request;
        SipFactory sipFactory = SipFactory.getInstance();
        HeaderFactory headerFactory = sipFactory.createHeaderFactory();
        AddressFactory addressFactory = sipFactory.createAddressFactory();
        List<ViaHeader> viaHeaders = new ArrayList<ViaHeader>();
        Random remotetag = new Random();
        if (invite != null && invite.toString().startsWith("SIP/2.0")) {
            Response response = (Response) invite;
            ViaHeader viaheader = (Via) response.getHeader(ViaHeader.NAME);
            ViaHeader viaHeader = null;
            ContactHeader contact = null;
            if (response.getStatusCode() == RESPONSE_CODE) {
                contact = (ContactHeader) response.getHeader(ContactHeader.NAME);
                contact.getAddress();
                viaHeader = MessageHandlerHelper.createViaHeader(LOOP_BACK_ADDRESS, FROM_PORT, PROTOCOL, MAGIC_COOKIES + Integer.toHexString(remotetag.nextInt()), headerFactory);
            } else {
                viaHeader = MessageHandlerHelper.createViaHeader(LOOP_BACK_ADDRESS, FROM_PORT, PROTOCOL, viaheader.getBranch(), headerFactory);
            }
            viaHeaders.add(viaHeader);
            SipURI requestURI;
            if (contact == null) {
                requestURI = MessageHandlerHelper.createSIPURI(FROM_USER_NAME, LOOP_BACK_ADDRESS, addressFactory);
            } else {
                Address a = contact.getAddress();
                String array[] = a.toString().split(" ");
                if (array.length > 1) {
                    String uri = array[1];
                    uri = uri.replace("<", "");
                    uri = uri.replace(">", "");
                    URI a1 = addressFactory.createURI(uri);
                    requestURI = (SipURI) a1;
                } else {
                    String uri = array[0];
                    uri = uri.replace("<", "");
                    uri = uri.replace(">", "");
                    URI a1 = addressFactory.createURI(uri);
                    requestURI = (SipURI) a1;
                }
            }
            URI requesturi = addressFactory.createURI(requestURI.toString());
            MaxForwardsHeader maxfwd = MessageHandlerHelper.createMaxForwardsHeader(MAXFORWARDS, headerFactory);
            long invitecseq = invite.getCSeq().getSeqNumber();
            CSeqHeader cseq = MessageHandlerHelper.createCSeqHeader(invitecseq, Request.ACK, headerFactory);
            CallIdHeader callid;
            FromHeader fromHeader;
            ToHeader toHeader;
            if (dialog != null) {
                SIPMessage sipMsg = ProcessSIPMessage.getSIPMessage(dialog, Request.ACK, SERVER_REQUEST);
                callid = sipMsg.getCallId();
                fromHeader = sipMsg.getFrom();
                toHeader = sipMsg.getTo();
            } else {
                callid = invite.getCallId();
                fromHeader = invite.getFrom();
                toHeader = invite.getTo();
            }
            request = MessageHandlerHelper.createRequest(requesturi, Request.ACK, callid, cseq, fromHeader, toHeader, viaHeaders, maxfwd, messageFactoryImpl);
            request.setMethod(Request.ACK);
        } else {
            SipURI fromAddress = MessageHandlerHelper.createSIPURI(FROM_USER_NAME, LOOP_BACK_ADDRESS, addressFactory);
            fromAddress.setPort(FROM_PORT);
            Address fromNameAddress = MessageHandlerHelper.createAddress(fromAddress, addressFactory);
            fromNameAddress.setDisplayName(FROM_DISPLAY_NAME);
            FromHeader fromHeader = MessageHandlerHelper.createFromHeader(fromNameAddress, Integer.toHexString(remotetag.nextInt()), headerFactory);
            SipURI toAddress = MessageHandlerHelper.createSIPURI(TO_USER_NAME, LOOP_BACK_ADDRESS, addressFactory);
            toAddress.setPort(TO_PORT);
            Address toNameAddress = MessageHandlerHelper.createAddress(toAddress, addressFactory);
            toNameAddress.setDisplayName(TO_DISPLAY_NAME);
            ToHeader toHeader = MessageHandlerHelper.createToHeader(toNameAddress, null, headerFactory);
            SipURI requestURI = MessageHandlerHelper.createSIPURI(TO_USER_NAME, LOOP_BACK_ADDRESS, addressFactory);
            requestURI.setPort(TO_PORT);
            ViaHeader viaHeader = MessageHandlerHelper.createViaHeader(LOOP_BACK_ADDRESS, FROM_PORT, PROTOCOL, MAGIC_COOKIES + Integer.toHexString(remotetag.nextInt()), headerFactory);
            viaHeaders.add(viaHeader);
            CSeqHeader cSeqHeader = MessageHandlerHelper.createCSeqHeader(1, Request.ACK, headerFactory);
            MaxForwardsHeader maxForwards = MessageHandlerHelper.createMaxForwardsHeader(MAXFORWARDS, headerFactory);
            CallIdHeader callid = MessageHandlerHelper.createCallIdHeader(Integer.toHexString(remotetag.nextInt()), LOOP_BACK_ADDRESS, headerFactory);
            request = MessageHandlerHelper.createRequest(requestURI, Request.ACK, callid, cSeqHeader, fromHeader, toHeader, viaHeaders, maxForwards, messageFactoryImpl);
        }
        LOGGER.info("Creation of ACK Request is ended");
        return request;
    }
