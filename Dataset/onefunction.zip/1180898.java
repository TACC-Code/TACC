    public ChannelPipeline getPipeline() throws Exception {
        ChannelPipeline pipeline = Channels.pipeline();
        pipeline.addLast("decoder", new FixFrameDecoder());
        pipeline.addLast("encoder", new FixEncoder());
        return pipeline;
    }
