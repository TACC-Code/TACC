    protected ActionForward processWizard(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response, ActionForm form) throws Exception {
        if (Wizard.getStep(request).intValue() == 4) {
            AjaxUtil.addInnerJsp(request, response, Wizard.getIdContent(request), Constants.TEST_JSP_PATH + "/wizard/content_4.jsp");
        } else {
            AjaxUtil.addInnerJsp(request, response, Wizard.getIdContent(request), Constants.TEST_JSP_PATH + "/wizard/content_3.jsp");
        }
        return null;
    }
