    public void test(TestHarness harness) {
        StringBuffer sb = new StringBuffer();
        sb.append("He");
        sb.append((CharSequence) null, 2, 4);
        sb.append("o, wor");
        sb.append((CharSequence) null, 2, 3);
        sb.append("d!");
        harness.check(sb.toString(), "Hello, world!", "Appendable PR34840 check");
    }
