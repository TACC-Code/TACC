    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setAttribute("idReadOnly", new Boolean(true));
        log.info("Entramos en EditarPermiso");
        PermisoDelegate permisoDelegate = DelegateUtil.getPermisoDelegate();
        PermisoForm permisoForm = (PermisoForm) form;
        Permiso permiso = (Permiso) permisoForm.getValues();
        if (isCancelled(request)) {
            log.info("isCancelled");
            return mapping.findForward("cancel");
        }
        if (isAlta(request) || isModificacion(request)) {
            log.info("isAlta || isModificacio");
            String[] cuentas = permisoForm.getCuentas();
            Cuenta cuenta = new Cuenta();
            cuenta.setCodigo(cuentas[0]);
            permiso.setCuenta(cuenta);
            Long codigo = permisoDelegate.grabarPermiso(permiso);
            log.info("Creat/Actualitzat " + permiso.getUsuarioSeycon());
            guardarPermiso(mapping, request, codigo);
            return mapping.findForward("success");
        }
        return mapping.findForward("reload");
    }
