    public static void main(String arsg[]) throws InterruptedException {
        try {
            Pachube p = new Pachube("89f2c12f9c73d818a7560d4847de5e2bc987cc1392bca23c5e2ba5b1c366c5a2");
            Feed f = p.getFeed(13213);
            f.updateDatastream(0, 99d);
        } catch (PachubeException e) {
            System.err.println("Error:" + e.errorMessage);
        }
    }
