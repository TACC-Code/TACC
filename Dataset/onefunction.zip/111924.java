    public void execute() {
        validate();
        getSessionInstance().remove(key);
        getProject().log("session entry removed. key: " + key, Project.MSG_DEBUG);
        storeResult(Boolean.toString(true));
    }
