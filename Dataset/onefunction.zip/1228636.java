    public static synchronized ContainerRef getOrCreateNamedContainer(Capi capi, String cname, CoordinationTypes baseCoordType) throws FatalException {
        try {
            System.out.println("Try to get Container: " + cname);
            ContainerRef cref = capi.getNamedContainer(cname);
            System.out.println("Container: " + cname + " already exists.");
            return cref;
        } catch (XVSMClientException e) {
            try {
                System.out.println("Try to create Container: " + cname);
                return capi.createNamedContainer(cname, baseCoordType);
            } catch (Exception e1) {
                throw new RuntimeException(e1);
            }
        } catch (UnknownContainerNameException e) {
            try {
                System.out.println("Try to create Container: " + cname);
                return capi.createNamedContainer(cname, baseCoordType);
            } catch (Exception e1) {
                throw new RuntimeException(e1);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
