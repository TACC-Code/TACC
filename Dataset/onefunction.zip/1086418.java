    public static XMLUtils getInstance() {
        try {
            if (!(instance instanceof XMLUtils)) {
                if (Constants.JAVA_PLATFORM.equalsIgnoreCase("ME")) {
                    instance = (XMLUtils) Class.forName("org.sepp.utils.xml.implementation.KXML2Utils").newInstance();
                } else {
                    instance = (XMLUtils) Class.forName("org.sepp.utils.xml.implementation.W3CUtils").newInstance();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return instance;
    }
