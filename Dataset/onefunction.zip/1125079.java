    public static Test suite() {
        TestSuite suite = new TestSuite("Analyzers suite");
        suite.addTest(TextAnalyzeSuite.suite());
        suite.addTest(TabletextSuite.suite());
        suite.addTestSuite(ElementFoundTest.class);
        return suite;
    }
