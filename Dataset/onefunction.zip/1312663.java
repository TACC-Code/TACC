    public static String printBean(Object pojo) {
        StringBuffer str = new StringBuffer();
        Field[] fields = pojo.getClass().getDeclaredFields();
        str.append("BeanInfo for:\n\tclass:\t\t\t");
        str.append(pojo.getClass().getName());
        str.append(":");
        for (Field f : fields) {
            str.append("\n\t");
            str.append(f.getName());
            str.append("(");
            str.append(Modifier.toString(f.getModifiers()));
            str.append(")");
            str.append(":\t\t");
            try {
                str.append(f.get(pojo));
            } catch (Exception e) {
                str.append("error");
            }
        }
        return str.toString();
    }
