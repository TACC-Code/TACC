    public void onFailure(final Throwable throwable) {
        GWT.log("Remote call has failed.", throwable);
        if (throwable instanceof NoPermissionException) {
            SC.warn("You do not have enough rights.");
        } else {
            SC.warn("Remote call has failed with message: " + throwable.getMessage());
        }
    }
