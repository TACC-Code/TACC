    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        ProcessStateForm fForm = (ProcessStateForm) form;
        UserObject uo = (UserObject) session.getAttribute("userObject");
        if ((fForm == null) || (uo.getFacade() == null)) {
            return (mapping.findForward("failure"));
        } else if ("insert".equals(fForm.getAction())) {
            ((com.mat.bo.Facade) uo.getFacade(GlobalParameter.facadeMat)).insertProcessStateVO(fForm);
        } else if ("update".equals(fForm.getAction())) {
            ((com.mat.bo.Facade) uo.getFacade(GlobalParameter.facadeMat)).updateProcessStateVO(fForm);
        } else if ("delete".equals(fForm.getAction())) {
            ((com.mat.bo.Facade) uo.getFacade(GlobalParameter.facadeMat)).deleteProcessStateVO(fForm);
        }
        return (mapping.findForward("success"));
    }
