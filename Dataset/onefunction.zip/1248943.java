    public String normalize(String path) {
        if ("".equals(path)) {
            return "/";
        }
        {
            Stack segments = new Stack();
            int p = 0;
            do {
                int q = path.indexOf("/", p + 1);
                if (q == -1) {
                    q = path.length();
                }
                String segment = path.substring(p, q);
                if (".".equals(segment) || "..".equals(segment)) {
                    q++;
                    segment = null;
                } else if ("/.".equals(segment) || "/..".equals(segment)) {
                    if (!segments.empty() && "/..".equals(segment)) {
                        segments.pop();
                    }
                    if (q < path.length()) {
                        segment = null;
                    } else {
                        segment = "/";
                    }
                }
                if (segment != null) {
                    segments.push(segment);
                }
                p = q;
            } while (p < path.length());
            String normalizedPath = "";
            while (!segments.empty()) {
                String s = (String) segments.pop();
                normalizedPath = s + normalizedPath;
            }
            return normalizedPath;
        }
    }
