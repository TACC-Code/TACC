    public static <T> T getDao(Class<T> classe, Class tipoDoDao) throws Exception {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(classe);
        enhancer.setCallback(new DaoInterceptor());
        return (T) enhancer.create(new Class[] { Class.class }, new Object[] { tipoDoDao });
    }
