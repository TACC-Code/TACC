    public static void main(String[] args) {
        String root = "/Users/johanwjoubert/MATSim/workspace/MATSimData/";
        String studyArea = "Gauteng";
        String version = "20091202131951";
        String threshold = "0300";
        String sample = "Sample01";
        double withinThreshold = 0.6;
        MyCommercialDemandGeneratorStringBuilder sb = new MyCommercialDemandGeneratorStringBuilder(root, studyArea);
        MyCommercialChainAnalyser mcca = new MyCommercialChainAnalyser(studyArea, withinThreshold, sb.getVehicleStatsFilename(version, threshold, sample));
        mcca.analyse(sb.getXmlSourceFolderName(version, threshold, sample), sb.getMatrixFileLocation(version, threshold, sample), 20, 48);
    }
