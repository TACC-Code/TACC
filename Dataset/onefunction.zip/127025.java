    public void testWrite() throws IOException {
        FileWriter fw = new FileWriter("test.csv");
        fw.write("中文,能显示么");
        fw.close();
        FileOutputStream fos = new FileOutputStream("test_utf8.csv");
        String msg = "中文,能显示么";
        fos.write(msg.getBytes("UTF-8"));
        fos.close();
        FileOutputStream fos1 = new FileOutputStream("test_gbk.csv");
        fos1.write(msg.getBytes("GBK"));
        fos1.close();
    }
