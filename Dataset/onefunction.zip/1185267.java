    public static List<Object> getModelObjects() {
        List<Object> result;
        result = new ArrayList<Object>();
        Class1 class1 = new Class1();
        Class1 class2 = new Class1();
        class2.parent = class1;
        class1.parent = class2;
        Collection<Class1> children = new ArrayList<Class1>();
        children.add(class1);
        children.add(class2);
        class1.children = children;
        class2.children = children;
        result.add(class1);
        result.add(class2);
        return result;
    }
