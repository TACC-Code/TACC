    public static Likeness compute(Dnode nodeA, Dnode nodeB) {
        Common = 0.0;
        NamedNodeMap attA = nodeA.refDomNode.getAttributes();
        NamedNodeMap attB = nodeB.refDomNode.getAttributes();
        MINIdelta = new METAdelta();
        Node tmp;
        for (int i = 0; i < attA.getLength(); i++) {
            if ((tmp = attB.getNamedItem(attA.item(i).getNodeName())) != null) {
                if (!tmp.getNodeValue().endsWith(attA.item(i).getNodeValue())) {
                    MINIdelta.addChangeValueAttOperation(nodeA, nodeB, attA.item(i).getNodeName(), tmp.getNodeValue(), attA.item(i).getNodeValue());
                    Common++;
                } else {
                    Common += 2;
                }
            } else {
                MINIdelta.addDeleteAttOperation(nodeA, nodeB, attA.item(i).getNodeName(), attA.item(i).getNodeValue());
            }
        }
        for (int i = 0; i < attB.getLength(); i++) {
            if ((tmp = attA.getNamedItem(attB.item(i).getNodeName())) == null) {
                MINIdelta.addInsertAttOperation(nodeA, nodeB, attB.item(i).getNodeName(), attB.item(i).getNodeValue());
            }
        }
        Common = (Common / (Math.min(attA.getLength(), attB.getLength()) * 2)) * 100;
        return new Likeness(Common.intValue(), MINIdelta);
    }
