    public CountryPage() {
        add(new BookmarkablePageLink("addPage", CreateCountryPage.class));
        AjaxBeanPropertyTable table = new AjaxBeanPropertyTable("table");
        table.init(new DefaultBeanPropertyTableProvider(Country.class), Country.class, 10);
        add(table);
    }
