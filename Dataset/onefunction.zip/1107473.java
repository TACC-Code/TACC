    public static void main(String[] args) {
        Log l = LogFactory.getLog();
        try {
            Hashtable e = new Hashtable();
            e.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
            e.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
            e.put(Context.PROVIDER_URL, "jnp://localhost:1099");
            Context ctx = new InitialContext(e);
            LogRemote lr = (LogRemote) ctx.lookup("LogBean/remote");
            l.info(lr);
            lr.init("1221947060196");
            lr.open();
            lr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
