    public FileNotFoundStrings() {
        add(FILE_NOT_FOUND);
        add(NO_SUCH_FILE);
        add(CANNOT_FIND_THE_FILE);
        add(FAILED_TO_OPEN_FILE);
        add(COULD_NOT_GET_FILE);
        add(DOES_NOT_EXIST);
    }
