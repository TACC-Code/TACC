    public boolean validate(final BoundObject4 boundObject4, final Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "input1", "input1empty", "input1 is empty");
        if (boundObject4.getInput1().compareTo("something") != 0) {
            errors.rejectValue("input1", "input1NotSomething", "input1 must contain something");
        }
        return (!errors.hasErrors());
    }
