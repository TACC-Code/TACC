    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        System.out.println("Testing my test test");
        PrintWriter out = res.getWriter();
        out.println("Hello, Brave new World!");
        out.close();
    }
