    public static void main(String[] args) {
        AdministrativeUnit a1 = new AdministrativeArea("Fake Organisation", "org");
        AdministrativeUnit a1b1 = new AdministrativeArea("Solar System Business Unit", "ssbu");
        AdministrativeUnit a1b1c1 = new AdministrativeArea("Mars Sales Unit", "msu");
        AdministrativeUnit o1 = new Office("Accounting Office", "ao");
        AdministrativeUnit a1b1c1d1 = new AdministrativeArea("Saturn Development Unit", "sdu");
        AdministrativeUnit o2 = new Office("Transgalactic Spedition Support", "tss");
        AdministrativeUnit o3 = new Office("Fueling Storage", "fs");
        AdministrativeUnit o4 = new ServerRoom("Saturn Development Production Servers", "sdps");
        a1b1c1d1.addUnit(o2);
        a1b1c1d1.addUnit(o3);
        a1b1c1d1.addUnit(o4);
        a1b1c1.addUnit(a1b1c1d1);
        a1b1c1.addUnit(o1);
        a1b1.addUnit(a1b1c1);
        a1.addUnit(a1b1);
        System.out.println();
        System.out.println(o4.unitNameLabel() + " is located at " + o4.getLocationInformation());
    }
