    public static IErrorMessageHandler getInstance(String p_emhName, Object p_parent) {
        IErrorMessageHandler emh = null;
        if (p_emhName.equals("PreferencePage")) {
            if (p_parent instanceof PreferencePage) {
                emh = new PreferencePageErrorHandler((PreferencePage) p_parent);
            } else {
                throw new IllegalArgumentException("For a PreferencePage-ErrorHandler the second parameter has to have the type" + PreferencePage.class.getName());
            }
        } else {
            throw new IllegalArgumentException(p_emhName + " not supported!");
        }
        return emh;
    }
