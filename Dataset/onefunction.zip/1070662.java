    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res) throws IOException {
        HttpSession session = req.getSession(false);
        if ((session == null) || (session.getAttribute("UserId") == null) || (session.getAttribute("UserId").equals(new String("")))) {
            req.setAttribute("APP_ERROR", "Your Session Got Expired. Please Re-login.");
            try {
                res.sendRedirect("/index.jsp");
            } catch (IOException e) {
            }
            return null;
        }
        DocumentDetails frmDoc = (DocumentDetails) form;
        DocumentDetails frmDocInfo;
        DataSource dbsrc = null;
        FormFile ffUpload = frmDoc.getFile_upload();
        ArrayList<DocumentDetails> alDocInfo = new ArrayList<DocumentDetails>();
        String sEmailId = String.valueOf(req.getParameter("candidate_email"));
        String sVirtualPath = new String();
        String sActualPath = new String();
        try {
            dbsrc = getDataSource(req);
            FileAttachFunction resAttF = new FileAttachFunction();
            java.util.Vector vec = resAttF.UploadFile(String.valueOf(ffUpload.getFileName()), req, ffUpload, sEmailId);
            sVirtualPath = String.valueOf(vec.get(0));
            sActualPath = String.valueOf(vec.get(1));
            frmDocInfo = new DocumentDetails();
            frmDocInfo.setEmail_id(sEmailId);
            frmDocInfo.setVitual_path(sVirtualPath);
            frmDocInfo.setActual_path(sActualPath);
            BoardingUtil.saveDocumentDetails(dbsrc, frmDocInfo, req);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        req.setAttribute("candidate_email", sEmailId);
        return map.findForward("ShowDocuments");
    }
