    public ClbClassificationVerbatim mapRow(ResultSet rs) throws SQLException {
        ClbClassificationVerbatim cls = super.mapRow(rs, new ClbClassificationVerbatim());
        cls.setK(rs.getString("k"));
        cls.setP(rs.getString("p"));
        cls.setC(rs.getString("c"));
        cls.setO(rs.getString("o"));
        cls.setF(rs.getString("f"));
        cls.setSf(rs.getString("sf"));
        cls.setG(rs.getString("g"));
        cls.setSg(rs.getString("sg"));
        cls.setS(rs.getString("s"));
        return cls;
    }
