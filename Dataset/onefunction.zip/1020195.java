    public void doMethod(HttpServletRequest req, HttpServletResponse res, MDConfig config, XhtmlBuffer xb) throws Exception {
        xb.openElement("html");
        xb.openElement("head");
        xb.openElement("title");
        xb.write("RecalculateAttributes");
        xb.closeElement("title");
        xb.closeElement("head");
        xb.openElement("body");
        xb.writeBr();
        xb.closeElement("body");
        xb.closeElement("html");
    }
