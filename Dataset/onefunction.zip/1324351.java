    public static CoordinateMapper make(String vendorString, BPMNWorkflowDocument document) {
        CoordinateMapper result = null;
        if (Utility.isStringNotEmpty(vendorString)) {
            if (vendorString.startsWith("itp-commerce.com")) {
            } else if (vendorString.startsWith("TIBCO")) {
            }
        }
        if (result == null) {
            result = new NullCoordinateMapper(document);
        }
        return result;
    }
