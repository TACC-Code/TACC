    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Referee ref = (Referee) request.getSession().getAttribute("authentication");
        GameManagementDelegate sgmd = BusinessDelegateFactory.getGameManagementDelegate();
        DropGameForm dropRefereeForm = (DropGameForm) form;
        if (dropRefereeForm != null) {
            try {
                try {
                    Long gameId = Long.decode(dropRefereeForm.getId());
                    Game modifiedGame = sgmd.removeReferee(gameId, ref);
                    dropRefereeForm.clear();
                    InfoMessageBean ibean = new InfoMessageBean();
                    ibean.addMessage(LocalizedStringAccessor.getString("DropReferee.Success") + modifiedGame.getMosslGameNumber());
                    request.setAttribute("info", ibean);
                } catch (UndeclaredThrowableException e) {
                    Throwable t = e.getCause().getCause();
                }
            } catch (StaleObjectStateException e) {
                ErrorMessageBean ebean = new ErrorMessageBean();
                ebean.addMessage(LocalizedStringAccessor.getString("DropReferee.NonexistentGameFailure"));
                request.setAttribute("errors", ebean);
                return mapping.findForward("failure");
            } catch (Exception e) {
                ErrorMessageBean ebean = new ErrorMessageBean();
                ebean.addMessage(LocalizedStringAccessor.getString("DropReferee.UnknownError"));
                request.setAttribute("errors", ebean);
                e.printStackTrace();
                return mapping.findForward("failure");
            }
        }
        return mapping.findForward("success");
    }
