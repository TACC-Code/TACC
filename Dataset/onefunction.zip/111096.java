    public static OrganismTag process(final Element root) {
        final String nodeName = root.getNodeName();
        if (false == "hostOrganism".equals(nodeName) && false == "organism".equals(nodeName)) {
            MessageHolder.getInstance().addParserMessage(new Message(root, "ERROR - We should be in hostOrganism tag."));
        }
        final String taxid = root.getAttribute("ncbiTaxId");
        final Element cellTypeElement = DOMUtil.getFirstElement(root, "cellType");
        CellTypeTag cellType = null;
        if (null != cellTypeElement) {
            cellType = CellTypeParser.process(cellTypeElement);
        }
        final Element tissueElement = DOMUtil.getFirstElement(root, "tissue");
        TissueTag tissue = null;
        if (null != tissueElement) {
            tissue = TissueParser.process(tissueElement);
        }
        OrganismTag organismTag = null;
        try {
            organismTag = new OrganismTag(taxid, cellType, tissue);
        } catch (IllegalArgumentException e) {
            MessageHolder.getInstance().addParserMessage(new Message(root, e.getMessage()));
        }
        return organismTag;
    }
