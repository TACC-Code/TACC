    public static void main(String[] args) {
        try {
            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel panel = new JPanel();
            frame.getContentPane().add(panel);
            panel.setLayout(new GridLayout());
            InputStream source = new FileInputStream(new File("resources/xul/containers/box/box.xul"));
            IPlatform platform = SwingPlatform.getDefaultPlatform();
            IDOMDocumentBindable document = platform.createDocument(panel, null, null);
            document.setLayoutDebugEnabled(true);
            platform.loadDocument(source, document);
            frame.pack();
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
