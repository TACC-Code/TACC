    public String beautify(String text) throws ParserException {
        StringReader reader = new StringReader(text);
        HtmlFormatter formatter = null;
        try {
            HtmlParser parser = new HtmlParser(reader);
            HtmlDocument document = parser.HtmlDocument();
            document.setLineSeparator(getLineSeparator());
            document.accept(new HtmlCollector());
            int scrubber_params = HtmlScrubber.TAGS_DOWNCASE | HtmlScrubber.ATTR_DOWNCASE | HtmlScrubber.TRIM_SPACES;
            if ("jsp".equals(getEditMode())) {
                scrubber_params = HtmlScrubber.TRIM_SPACES;
            }
            document.accept(new HtmlScrubber(scrubber_params));
            formatter = new HtmlFormatter();
            if (getWrapMode().equals("none")) {
                formatter.setRightMargin(Integer.MAX_VALUE);
            } else {
                formatter.setRightMargin(getWrapMargin());
            }
            formatter.setLineSeparator(getLineSeparator());
            formatter.setIndent(getIndentWidth());
            document.accept(formatter);
        } catch (Exception e) {
            throw new ParserException(e);
        } finally {
            reader.close();
        }
        return formatter != null ? formatter.toString() : text;
    }
