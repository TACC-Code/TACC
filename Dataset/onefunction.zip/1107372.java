    public static void initRepository(String username, String password) throws LoginException, RepositoryException {
        RepositorySessionFactory.openSession(username, password);
        FileManagerDAO cao = new FileManagerDAO();
        cao.registerUser(User.USER_ADMIN);
        RepositorySessionFactory.closeSession();
    }
