    public static void main(String[] args) throws IOException {
        String sampleText = "SAMPLE TEXT";
        String fileName = "Image";
        File newFile = new File("c:/users/sdixit/Downloads/" + fileName + ".jpeg");
        Font font = new Font("Tahoma", Font.PLAIN, 11);
        FontRenderContext frc = new FontRenderContext(null, true, true);
        Rectangle2D bounds = font.getStringBounds(sampleText, frc);
        int w = (int) bounds.getWidth();
        int h = (int) bounds.getHeight();
        BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, h);
        g.setColor(Color.BLACK);
        g.setFont(font);
        g.drawString(sampleText, (float) bounds.getX(), (float) -bounds.getY());
        g.dispose();
        ImageIO.write(image, "jpeg", newFile);
    }
