    public void countInteractionsForExperimentWithAc() {
        Experiment exp = getMockBuilder().createExperimentRandom(5);
        getCorePersister().saveOrUpdate(exp);
        final int count = getDaoFactory().getExperimentDao().countInteractionsForExperimentWithAc(exp.getAc());
        Assert.assertEquals(5, count);
    }
