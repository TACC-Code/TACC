    public Document load(String filename) {
        File file = new File(filename);
        if (file.exists()) {
            try {
                SAXBuilder sb = new SAXBuilder();
                InputStreamReader fr = new InputStreamReader(new FileInputStream(new File(filename)), "UTF-8");
                Document document = sb.build(fr);
                document.getRootElement().setAttribute("version", "6");
                return document;
            } catch (JDOMException e) {
                ICoreConstants.LOG.error(e);
            } catch (IOException e) {
                ICoreConstants.LOG.error(e);
            }
            return null;
        } else {
            Document document = new Document();
            Element root = new Element("data");
            root.setAttribute("version", "6");
            document.setRootElement(root);
            return document;
        }
    }
