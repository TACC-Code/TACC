    protected VelocityContext createContext() {
        VelocityContext cxt = super.createContext();
        TemplateTools tt = new TemplateTools();
        cxt.put("tpl", tt);
        return cxt;
    }
