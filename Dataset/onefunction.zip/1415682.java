    public void testCollectItemData() throws ParserConfigurationException, SAXException, IOException, XPathException {
        ItemCollector ic = new ItemCollector();
        for (int i = 24000; i < 25000; i = i + 100) {
            ic.collectItemData(i + "");
        }
    }
