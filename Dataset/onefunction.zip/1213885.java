    public void handle(PacketContext context) throws GGException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("GGNeedEmail packet received.");
            LOGGER.debug("PacketHeader: " + context.getHeader());
            LOGGER.debug("PacketLoad: " + GGUtils.prettyBytesToString(context.getPackageContent()));
        }
        final GGNeedEmail needEmail = GGNeedEmail.getInstance();
        context.getSessionAccessor().notifyGGPacketReceived(needEmail);
        final LoginFailedEvent loginFailedEvent = new LoginFailedEvent(this);
        loginFailedEvent.setReason(LoginFailedEvent.NEED_EMAIL_REASON);
        context.getSessionAccessor().notifyLoginFailed(loginFailedEvent);
    }
