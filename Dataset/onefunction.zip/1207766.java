    public UrlLabel(String elementName) {
        this.setToolTipText(ResourceController.getMessage("editor.browser.description", ResourceController.getMessage("url.parameter_description", elementName)));
        this.setIcon(EditorIcon.createBrowserIcon());
        this.addMouseListener(new BrowserListener(elementName));
        this.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
