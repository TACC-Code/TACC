    public static Test suite() {
        TestSuite suite = new TestSuite("Test for ch.iserver.ace.algorithm.jupiter");
        suite.addTestSuite(NWayScenarioTest.class);
        suite.addTestSuite(SplitOperationTest.class);
        suite.addTestSuite(JupiterTest.class);
        suite.addTestSuite(TwoWayScenarioTest.class);
        return suite;
    }
