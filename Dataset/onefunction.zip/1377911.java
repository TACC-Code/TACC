    public MatrixPosition getEndPosition(Entry[][] table) {
        final int m = table.length - 1;
        Entry bestEntry = table[m][0];
        int bestColumn = 0;
        for (int column = 1; column < table[m].length; ++column) {
            if (table[m][column].score >= bestEntry.score) {
                bestColumn = column;
                bestEntry = table[m][column];
            }
        }
        return new MatrixPosition(m, bestColumn);
    }
