    public void handle(Player _objSource, IMessageDispatcher _objDisp, Message _objMessage) {
        MsgField objMsgField;
        String szMsgFldName;
        Hotel objHotel = null;
        StreetField objStreetField = null;
        int iStreetID = -1;
        int iHotelID = -1;
        LinkedList objMsgFields = _objMessage.getFields();
        MainIDDestributor objMainIDDest = MainIDDestributor.getInstance();
        while (objMsgFields.isEmpty() == false) {
            objMsgField = (MsgField) objMsgFields.removeFirst();
            szMsgFldName = objMsgField.getFieldName();
            if (szMsgFldName.equals(FLD_FREE_ENTRANCE_FIELD_ID)) {
                iStreetID = Integer.parseInt(objMsgField.getFieldData());
            }
            if (szMsgFldName.equals(FLD_FREE_ENTRANCE_HOTEL_ID)) {
                iHotelID = Integer.parseInt(objMsgField.getFieldData());
            }
        }
        if (iHotelID == -1) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_MISSING_FIELD, FLD_FREE_ENTRANCE_HOTEL_ID);
            return;
        }
        if (iStreetID == -1) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_MISSING_FIELD, FLD_FREE_ENTRANCE_FIELD_ID);
            return;
        }
        objHotel = (Hotel) objMainIDDest.getIDObject(iHotelID, IIDTypeConstants.HOTEL, _objSource.getGameNr());
        objStreetField = (StreetField) objMainIDDest.getIDObject(iStreetID, IIDTypeConstants.STREET_FIELD, _objSource.getGameNr());
        if (objHotel == null) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_HOTEL_NOT_EXIST, HOTEL_NOT_EXIST);
            return;
        }
        if (objStreetField == null) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_STREETFIELD_NOT_EXIST, STREETFIELD_NOT_EXIST);
            return;
        }
        try {
            _objSource.buildFreeEntrance(objHotel, objStreetField);
        } catch (EntranceAreBuildInRoundException e) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_ENTRANCE_ARE_BUILT_IN_ROUND, ENTRANCE_ARE_BUILT_IN_ROUND);
            return;
        } catch (OtherEntranceExistsOnFieldException e) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_OTHER_ENTRANCE_EXIST_ON_FIELD, OTHER_ENTRANCE_EXIST_ON_FIELD);
            return;
        } catch (EntranceExistsNotOnFieldException e) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_ENTRANCE_EXIST_NOT_ON_FIELD, ENTRANCE_EXIST_NOT_ON_FIELD);
            return;
        } catch (EntranceExistsNotOnHotelException e) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_ENTRANCE_EXIST_NOT_ON_HOTEL, ENTRANCE_EXIST_NOT_ON_HOTEL);
            return;
        } catch (EntranceBuildException e) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_ENTRANCE_CANT_BE_BUILT, ENTRANCE_CANT_BE_BUILT);
            return;
        } catch (HotelNotAvailableException e) {
            reject(_objDisp, _objMessage, DATA_REJECT_REASON_HOTEL_NOT_EXIST, HOTEL_NOT_EXIST);
            return;
        } catch (ActionNotAllowedException e) {
            reject(_objDisp, _objMessage, DATA_REJECT_ACTION_NOT_ALLOWED, e.getMessage());
            return;
        }
    }
