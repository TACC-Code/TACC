    public void test_6() {
        System.out.println("==test_6===");
        if (RuntimeAdditionalTest0.os.equals("Unk")) {
            fail("WARNING (test_6): unknown operating system.");
        }
        try {
            String cmnd = RuntimeAdditionalTest0.javaStarter;
            Process pi3 = Runtime.getRuntime().exec(cmnd);
            pi3.destroy();
            while (true) {
                try {
                    pi3.exitValue();
                    break;
                } catch (IllegalThreadStateException e) {
                    continue;
                }
            }
        } catch (Exception eeee) {
            eeee.printStackTrace();
            fail("ERROR (test_6): unexpected exception.");
        }
    }
