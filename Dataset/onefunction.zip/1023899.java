    public static LinkedList analyze(LinkedList ids, LinkedList datum, LinkedList bezirke, LinkedList content, LinkedList links, LinkedList header) {
        Connection cn;
        Collection tags = null;
        Collection negtags = null;
        try {
            cn = new DBObject().get_connection();
            if (cn == null) {
                log.info("Fehler aufgetreten");
            }
            tags = TagsDB.findAll(cn);
            negtags = NegTagsDB.findAll(cn);
            cn.close();
        } catch (SQLException e) {
            if (log.isInfoEnabled()) log.info("Hier ist ein Fehler in der Datenbank aufgetreten: " + e.toString());
        }
        LinkedList straftaten = new LinkedList();
        String[] verbrechen = { "Mord", "Straftat gegen sexuelle Freiheit", "Raub", "K�rperverletzung", "Straftat gegen pers�nliche Freiheit", "Diebstahl", "Betrug", "F�lschungsdelikte", "Brandstiftung", "Sachbbesch�digung", "Umweltkriminalit�t", "Rauschgiftkriminalit�t", "Straftat gegen Jugendschutzbestimmungen", "Computerkriminalit�t", "-" };
        int size = content.size();
        for (int i = 0; i < size; i++) {
            Iterator it = tags.iterator();
            Iterator nit = negtags.iterator();
            int countArray[] = new int[14];
            int maxId = 14;
            int maxNumber = 0;
            while (it.hasNext()) {
                TagsDTO erg = (TagsDTO) it.next();
                Pattern pTags = Pattern.compile(erg.getTag());
                Matcher mTags = pTags.matcher(((String) content.get(i)).toLowerCase() + ((String) header.get(i)).toLowerCase());
                if (mTags.find()) {
                    countArray[erg.getId() - 1]++;
                }
                if (maxNumber < countArray[erg.getId() - 1]) {
                    maxNumber = countArray[erg.getId() - 1];
                    if (maxNumber != 0) maxId = erg.getId() - 1;
                }
                if (log.isInfoEnabled()) log.info(erg.getTag());
            }
            while (nit.hasNext()) {
                NegTagsDTO erg = (NegTagsDTO) nit.next();
                Pattern pNegTags = Pattern.compile(erg.getTag());
                Matcher mNegTags = pNegTags.matcher(((String) content.get(i)).toLowerCase() + ((String) header.get(i)).toLowerCase());
                if (mNegTags.find()) {
                    maxId = 14;
                }
            }
            straftaten.add(new StraftatenDTO(Integer.valueOf((String) ids.get(i)).intValue(), verbrechen[maxId], (String) header.get(i), (String) content.get(i), (String) links.get(i), (String) datum.get(i), new StrassenDTO(1, "-", new BezirkeDTO(1, "-", (String) bezirke.get(i)), 0, 0)));
            if (log.isInfoEnabled()) log.info("ID:" + "\t\t" + ids.get(i) + "\n" + "Datum: " + "\t\t" + datum.get(i) + "\n" + "Bezirk: " + "\t" + bezirke.get(i) + "\n" + "Verbrechen: " + "\t" + verbrechen[maxId] + "\n" + "Link: " + "\t" + links.get(i) + "\n" + "Content: " + "\t" + content.get(i) + "\n\n");
        }
        return straftaten;
    }
