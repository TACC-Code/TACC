    public String perform(HttpServletRequest request, HttpServletResponse response) {
        request.setAttribute("ACTION", "Create");
        request.setAttribute("UserID", 0);
        request.setAttribute("LOGINNAME", "");
        request.setAttribute("FIRSTNAME", "");
        request.setAttribute("LASTNAME", "");
        request.setAttribute("PASSWORD", "");
        request.setAttribute("CPASSWORD", "");
        request.setAttribute("EMAIL", "");
        request.setAttribute("Reg1", "selected");
        request.setAttribute("Reg2", "");
        request.setAttribute("Reg3", "");
        request.setAttribute("Reg4", "");
        request.setAttribute("Rol1", "");
        request.setAttribute("Rol2", "");
        request.setAttribute("Rol3", "");
        request.setAttribute("Rol4", "checked");
        return PAGE_USER;
    }
