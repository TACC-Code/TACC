    public String format(final int millis) {
        String result = "0";
        if (millis > 0) {
            Date date = new Date(millis);
            Format format = null;
            if (millis < 60000) {
                format = new SimpleDateFormat("ss:SSS");
            } else {
                format = new SimpleDateFormat("mm:ss:SSS");
            }
            result = format.format(date);
        }
        return result;
    }
