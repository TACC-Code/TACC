    public static void main(String[] args) {
        try {
            Display display = new Display();
            CSSEngine engine = new CSSSWTEngineImpl(display);
            engine.parseStyleSheet(new StringReader("@namespace swt \"org.eclipse.swt.widgets\"; " + "swt|* {color:red}"));
            Shell shell = new Shell(display, SWT.SHELL_TRIM);
            FillLayout layout = new FillLayout();
            shell.setLayout(layout);
            Composite panel1 = new Composite(shell, SWT.NONE);
            panel1.setLayout(new FillLayout());
            Label label1 = new Label(panel1, SWT.NONE);
            label1.setText("Label 0 [color:red;]");
            Text text1 = new Text(panel1, SWT.NONE);
            text1.setText("bla bla bla...");
            engine.applyStyles(shell, true);
            shell.pack();
            shell.open();
            while (!shell.isDisposed()) {
                if (!display.readAndDispatch()) display.sleep();
            }
            display.dispose();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
