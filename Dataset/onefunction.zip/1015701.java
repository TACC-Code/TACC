    public static void export(Collection<GPSTrace> traces, ArrayList<Style> styles, File file) {
        StringBuffer sb = new StringBuffer().append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n").append("<kml xmlns=\"http://www.opengis.net/kml/2.2\" >\n").append("<Document>\n").append("\t<open>1</open>\n").append("\t<Folder>\n").append("\t\t<name>Chmuk KML export</name>\n").append("\t\t<open>1</open>\n");
        for (Style style : styles) {
            if (!style.isToDraw()) continue;
            sb.append("\t\t<Folder>\n").append("\t\t\t<name>" + style.getCheckBoxText() + "</name>\n").append(style.toKML(traces, 3)).append("\t\t</Folder>\n");
        }
        sb.append("\t</Folder>\n").append("</Document>\n").append("</kml>\n");
        FileWriter out = null;
        try {
            out = new FileWriter(file);
            out.write(sb.toString());
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
