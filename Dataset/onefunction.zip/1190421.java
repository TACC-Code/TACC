    public static void setup() throws IOException {
        File workingDir = new File("target/jumppos");
        if (workingDir.exists()) {
            FileUtils.deleteDirectory(workingDir);
        }
    }
