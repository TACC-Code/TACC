    public void parseData(GarminData data) {
        setIdent(IDENT_FIELD.get(data));
        setPosition(POSITION_FIELD.get(data));
        setComment(COMMENT_FIELD.get(data));
        setDistance(new Float(DISTANCE_FIELD.get(data)));
        setSymbol(GarminSymbols.get(SYMBOL_FIELD.get(data)));
        setDisplay(GarminDisplay.getD103(DISPLAY_FIELD.get(data)));
    }
