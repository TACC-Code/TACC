    public OdeMM(Ode Model, DblMatrix Tstart, DblMatrix Tstop, DblMatrix Yinit) {
        super(Model, Tstart, Tstop, Yinit);
        AdaptiveInterval FI = new AdaptiveInterval(this.Model, this.Tstart, this.Tstop, this.Yinit, this.Options);
        FI.setReporter(this.Reporter);
        Mmid RK = new Mmid(this.Model, this.Tstart, this.Tstop, this.Yinit, this.Options);
        RK.setSubSteps(new Integer(10));
        RK.setReporter(this.Reporter);
        this.Reporter.addToSolutionTrace(Tstart, Yinit);
        FI.setStepIntegrator(RK);
        this.setIntervalIntegrator(FI);
    }
