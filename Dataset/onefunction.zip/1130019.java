    public Object execute(ExecutionEvent event) throws ExecutionException {
        IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
        try {
            page.showView(PlaylistOverview.ID);
        } catch (PartInitException e) {
            Log.getInstance(ShowPlaylistOverviewHandler.class).warn("Unable to open PlaylistOverview.");
        }
        return null;
    }
