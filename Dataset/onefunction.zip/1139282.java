    public void testGeneatedWhereExpression() {
        String[] arrayStr = { "OBJECTID", "name" };
        String where = MapRequestUtil.geneatedWhereExpression(arrayStr);
        assertNotNull(where);
        System.out.println(where);
    }
