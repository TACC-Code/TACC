    public static Test suite() {
        TestSuite suite = new TestSuite("Test for mscheme.values");
        suite.addTestSuite(TestInputPort.class);
        suite.addTestSuite(OutputPortTest.class);
        suite.addTestSuite(ValueTraitsTest.class);
        suite.addTestSuite(TestList.class);
        return suite;
    }
