    public ActionForward execute(ActionMapping map, ActionForm frm, HttpServletRequest req, HttpServletResponse res) throws IOException {
        HttpSession session = req.getSession(false);
        String sResultStr = "";
        if ((session == null) || (session.getAttribute("UserId") == null) || (session.getAttribute("UserId").equals(new String("")))) {
            sResultStr = "LOGOUT";
        }
        db = getDataSource(req);
        String sUpdatedBy = String.valueOf(session.getAttribute("UserId"));
        String sCommand = req.getParameter("command");
        String sJobId = req.getParameter("jobId");
        String sCandiateEmail = req.getParameter("consultantEmail");
        String sQuery = req.getParameter("query");
        String sDocType = "";
        String sCallLogRemark = "";
        if (sCommand == null) {
        } else if (sCommand.equals(new String("accept"))) {
            sDocType = "Active";
            sCallLogRemark = "Candidate Accepted The Off Boarding.";
        } else {
            sDocType = "QUERIED";
            sCallLogRemark = "Candidate Raised Following Queries: " + sQuery;
        }
        Connection myCon = null;
        int iResult = 0;
        String sErrorStr = "";
        try {
            myCon = db.getConnection();
            PreparedStatement insertStmt = myCon.prepareStatement("update rooster_onboard_status set onboardstatus=?,con_questions=? where clrJobId=? and email_id=?;");
            insertStmt.setString(1, sDocType);
            insertStmt.setString(2, sQuery);
            insertStmt.setString(3, sJobId);
            insertStmt.setString(4, sCandiateEmail);
            iResult = insertStmt.executeUpdate();
        } catch (Exception e) {
            System.err.println(e);
            sErrorStr = e.getMessage();
        } finally {
            try {
                if (myCon != null) {
                    myCon.close();
                }
            } catch (SQLException e) {
            }
        }
        try {
            myCon = db.getConnection();
            String sCallDate = CurrentDate.getDateWithTime();
            PreparedStatement insertStmt = myCon.prepareStatement("insert into velrec_call_log(clrJobId,first_name,last_name,state,city,zip_code,email_id,phone_no,basic_skill,recruiter_id,cand_reference,tax_term,rate,work_auth,req_comments,status,reminder,call_date)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
            insertStmt.setString(1, sJobId);
            insertStmt.setString(2, "");
            insertStmt.setString(3, "");
            insertStmt.setString(4, "");
            insertStmt.setString(5, "");
            insertStmt.setString(6, "");
            insertStmt.setString(7, sCandiateEmail);
            insertStmt.setString(8, "");
            insertStmt.setString(9, "");
            insertStmt.setString(10, "Candidate");
            insertStmt.setString(11, "");
            insertStmt.setString(12, "");
            insertStmt.setString(13, "");
            insertStmt.setString(14, "");
            insertStmt.setString(15, sCallLogRemark);
            insertStmt.setString(16, "Candidate's Response");
            insertStmt.setString(17, "");
            insertStmt.setString(18, sCallDate);
            insertStmt.executeUpdate();
        } catch (Exception e) {
            System.err.println(e);
            sErrorStr = e.getMessage();
        } finally {
            try {
                if (myCon != null) {
                    myCon.close();
                }
            } catch (SQLException e) {
            }
        }
        if (sDocType.equals(new String("Active"))) {
            try {
                myCon = db.getConnection();
                PreparedStatement updateStmt = myCon.prepareStatement("update rooster_candidate_info set onboard_status=? where email_id=?;");
                updateStmt.setString(1, "Active");
                updateStmt.setString(2, sCandiateEmail);
                updateStmt.executeUpdate();
            } catch (Exception sqle) {
                logger.debug(sqle);
            } finally {
                try {
                    myCon.close();
                } catch (SQLException sql) {
                    logger.debug(sql);
                }
            }
        }
        if (iResult > 0) {
            sResultStr = "SecondLoginHome.do";
        } else {
            sResultStr = "ERROR : " + sErrorStr;
        }
        try {
            res.setContentType("text/html");
            PrintWriter out = res.getWriter();
            out.write(sResultStr);
            out.flush();
            out.close();
        } catch (Exception e) {
            System.err.println(e);
        }
        return null;
    }
