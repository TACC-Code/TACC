    public String serve(HttpServletRequest request, HttpServletResponse response) throws FatalException {
        try {
            MatosoMessages msgs = super.getMatosoMessagesInRequest(request);
            Tournament tournament = super.getTournament(request);
            List<String[]> playersData = PlayerService.getRawDataFromRequest(request, msgs, tournament.isTeamActivate());
            if (MatosoMessages.isNotEmpty(msgs)) return ServletCst.REDIRECT_TO_PLAYER_IMPORT_FORM;
            TournamentService.addPlayers(tournament, playersData);
        } catch (ImportException e) {
            throw new FatalException("Can't import player file.", e);
        }
        return ServletCst.REDIRECT_TO_TABLE_FILL_SERVLET;
    }
