    public static void main(String[] args) {
        FabricaDeDAOs fabricaMySQL = FabricaDeDAOs.getFabricaDeDAOs(mx.ipn.Constantes.FABRICA_DAOS_MYSQL);
        short resultado;
        System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<BITACORAASISTENCIA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        try {
            BitacoraAsistenciaDAO bitacoraAsistenciaDAO = fabricaMySQL.getBitacoraAsistenciaDAO();
            BitacoraAsistenciaTO bitacoraAsistenciaTO = new BitacoraAsistenciaTO();
            bitacoraAsistenciaTO.setFecha(FechaHoraTO.getFecha("2008/04/04"));
            bitacoraAsistenciaTO.setDescripcion("No recuerdo");
            bitacoraAsistenciaTO.setIdEmpleado(1);
            bitacoraAsistenciaTO.setIdMotivo(1);
            bitacoraAsistenciaTO.setIdUsuario(1);
            if (bitacoraAsistenciaDAO.insertBitacoraAsistencia(bitacoraAsistenciaTO)) {
                bitacoraAsistenciaDAO.insertBitacoraAsistencia(bitacoraAsistenciaTO);
                System.out.println("+++++++++++++++++++ Insertado * correctamente");
            } else System.out.println("Falla en la insercion");
            bitacoraAsistenciaTO.setIdOperacion(1);
            bitacoraAsistenciaTO.setIdEmpleado(1);
            bitacoraAsistenciaTO.setIdMotivo(1);
            bitacoraAsistenciaTO.setIdUsuario(1);
            resultado = bitacoraAsistenciaDAO.updateBitacoraAsistencia(bitacoraAsistenciaTO);
            if (resultado == 1) System.out.println("Actualizado correctamente"); else if (resultado == 0) System.out.println("Falla en la actualizacion"); else if (resultado == -1) System.out.println("Ocurrio una excepcion");
            System.out.println("------------------------- BUSQUEDA POR ID");
            bitacoraAsistenciaTO = bitacoraAsistenciaDAO.findBitacoraAsistenciaById(1);
            if (bitacoraAsistenciaTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORAASISTENCIA");
                ImprimirTO.Imprime(bitacoraAsistenciaTO);
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("**++++++++++++++++++++++ SELECTBITACORAASISTENCIA +**");
            java.util.Collection<BitacoraAsistenciaTO> listBitacoraAsistenciaTO = bitacoraAsistenciaDAO.selectBitacoraAsistencia();
            if (listBitacoraAsistenciaTO != null) {
                for (int i = 0; i < listBitacoraAsistenciaTO.size(); i++) {
                    bitacoraAsistenciaTO = ((ArrayList<BitacoraAsistenciaTO>) listBitacoraAsistenciaTO).get(i);
                    System.out.println("BITACORAASISTENCIA");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO);
                }
            } else {
                System.out.println("No hubo resultados en la seleccion");
            }
            System.out.println("**++++++++++++++++++++++ SELECTBITACORAASISTENCIA BY RANGO FECHA+**");
            listBitacoraAsistenciaTO = bitacoraAsistenciaDAO.selectByRangoFecha(FechaHoraTO.getFecha("2003/04/04"), FechaHoraTO.getFecha("2008/04/04"));
            if (listBitacoraAsistenciaTO != null) {
                for (int i = 0; i < listBitacoraAsistenciaTO.size(); i++) {
                    bitacoraAsistenciaTO = ((ArrayList<BitacoraAsistenciaTO>) listBitacoraAsistenciaTO).get(i);
                    System.out.println("BITACORAASISTENCIA");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO);
                }
            } else {
                System.out.println("No hubo resultados en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA EMPLEADO");
            bitacoraAsistenciaTO = bitacoraAsistenciaDAO.selectByRangoFechaEmpleado(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraAsistenciaTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORAASISTENCIA");
                for (int x = 0; x < bitacoraAsistenciaTO.getListIdoperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraAsistenciaTO.getListIdoperacion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraAsistenciaTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraAsistenciaTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListMotivoTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListUsuarioTO().length; x++) {
                    System.out.println("EMPLEADO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListUsuarioTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA MOTIVO");
            bitacoraAsistenciaTO = bitacoraAsistenciaDAO.selectByRangoFechaMotivo(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraAsistenciaTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORAASISTENCIA");
                for (int x = 0; x < bitacoraAsistenciaTO.getListIdoperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraAsistenciaTO.getListIdoperacion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraAsistenciaTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraAsistenciaTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListUsuarioTO().length; x++) {
                    System.out.println("EMPLEADO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListMotivoTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA USURIO");
            bitacoraAsistenciaTO = bitacoraAsistenciaDAO.selectByRangoFechaUsuario(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraAsistenciaTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORAASISTENCIA");
                for (int x = 0; x < bitacoraAsistenciaTO.getListIdoperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraAsistenciaTO.getListIdoperacion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraAsistenciaTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraAsistenciaTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListEmpleadoTO().length; x++) {
                    System.out.println("EMPLEADO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListEmpleadoTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListMotivoTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListUsuarioTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA MOTIVO EMPLEADO");
            bitacoraAsistenciaTO = bitacoraAsistenciaDAO.selectByRangoFechaMotivoEmpleado(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1, 1);
            if (bitacoraAsistenciaTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORAASISTENCIA");
                for (int x = 0; x < bitacoraAsistenciaTO.getListIdoperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraAsistenciaTO.getListIdoperacion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraAsistenciaTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraAsistenciaTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListEmpleadoTO().length; x++) {
                    System.out.println("EMPLEADO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListEmpleadoTO()[x]);
                }
                for (int x = 0; x < bitacoraAsistenciaTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraAsistenciaTO.getListMotivoTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
        } catch (Exception e) {
            System.out.println("Ocurrio una excepcion");
        }
        System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<BITACORACASTIGOCHOFER>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        try {
            BitacoraCastigoChoferDAO bitacoraCastigoChoferDAO = fabricaMySQL.getBitacoraCastigoChoferDAO();
            BitacoraCastigoChoferTO bitacoraCastigoChoferTO = new BitacoraCastigoChoferTO();
            bitacoraCastigoChoferTO.setFecha(FechaHoraTO.getFecha("2008/04/04"));
            bitacoraCastigoChoferTO.setHora(FechaHoraTO.getHora("01:01:01"));
            bitacoraCastigoChoferTO.setDescripcion("No recuerdo");
            bitacoraCastigoChoferTO.setIdChofer(1);
            bitacoraCastigoChoferTO.setIdMotivo(1);
            bitacoraCastigoChoferTO.setIdUsuario(1);
            if (bitacoraCastigoChoferDAO.insertBitacoraCastigoChofer(bitacoraCastigoChoferTO)) {
                bitacoraCastigoChoferDAO.insertBitacoraCastigoChofer(bitacoraCastigoChoferTO);
                System.out.println("+++++++++++++++++++ Insertado * correctamente");
            } else System.out.println("Falla en la insercion");
            bitacoraCastigoChoferTO.setIdOperacion(1);
            bitacoraCastigoChoferTO.setIdChofer(1);
            bitacoraCastigoChoferTO.setIdMotivo(3);
            bitacoraCastigoChoferTO.setIdUsuario(1);
            resultado = bitacoraCastigoChoferDAO.updateBitacoraCastigoChofer(bitacoraCastigoChoferTO);
            if (resultado == 1) System.out.println("Actualizado correctamente"); else if (resultado == 0) System.out.println("Falla en la actualizacion"); else if (resultado == -1) System.out.println("Ocurrio una excepcion");
            System.out.println("------------------------- BUSQUEDA POR ID");
            bitacoraCastigoChoferTO = bitacoraCastigoChoferDAO.findBitacoraCastigoChoferById(1);
            if (bitacoraCastigoChoferTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOCHOFER");
                ImprimirTO.Imprime(bitacoraCastigoChoferTO);
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("**++++++++++++++++++++++ SELECTBITACORACASTIGOCHOFER +**");
            java.util.Collection<BitacoraCastigoChoferTO> listBitacoraCastigoChoferTO = bitacoraCastigoChoferDAO.selectBitacoraCastigoChofer();
            if (listBitacoraCastigoChoferTO != null) {
                for (int i = 0; i < listBitacoraCastigoChoferTO.size(); i++) {
                    bitacoraCastigoChoferTO = ((ArrayList<BitacoraCastigoChoferTO>) listBitacoraCastigoChoferTO).get(i);
                    System.out.println("BITACORACASTIGOCHOFER");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO);
                }
            } else {
                System.out.println("No hubo resultados en la seleccion");
            }
            System.out.println("**++++++++++++++++++++++ SELECTBITACORACASTIGOCHOFER BY RANGO FECHA HORA+**");
            listBitacoraCastigoChoferTO = bitacoraCastigoChoferDAO.selectByRangoFechaHora(FechaHoraTO.getFecha("2003/04/04"), FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getHora("00:00:00"), FechaHoraTO.getHora("23:00:00"));
            if (listBitacoraCastigoChoferTO != null) {
                for (int i = 0; i < listBitacoraCastigoChoferTO.size(); i++) {
                    bitacoraCastigoChoferTO = ((ArrayList<BitacoraCastigoChoferTO>) listBitacoraCastigoChoferTO).get(i);
                    System.out.println("BITACORACASTIGOCHOFER");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO);
                }
            } else {
                System.out.println("No hubo resultados en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA CHOFER");
            bitacoraCastigoChoferTO = bitacoraCastigoChoferDAO.selectByRangoFechaChofer(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraCastigoChoferTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOCHOFER");
                for (int x = 0; x < bitacoraCastigoChoferTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoChoferTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoChoferTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListHora().length; x++) {
                    System.out.println("HORA");
                    System.out.println(bitacoraCastigoChoferTO.getListHora()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoChoferTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListMotivoTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListChoferTO().length; x++) {
                    System.out.println("CHOFER");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListChoferTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA MOTIVO");
            bitacoraCastigoChoferTO = bitacoraCastigoChoferDAO.selectByRangoFechaMotivo(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraCastigoChoferTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOCHOFER");
                for (int x = 0; x < bitacoraCastigoChoferTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoChoferTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoChoferTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoChoferTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListChoferTO().length; x++) {
                    System.out.println("CHOFER");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListChoferTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListMotivoTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA USURIO");
            bitacoraCastigoChoferTO = bitacoraCastigoChoferDAO.selectByRangoFechaUsuario(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraCastigoChoferTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOCHOFER");
                for (int x = 0; x < bitacoraCastigoChoferTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoChoferTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoChoferTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoChoferTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListChoferTO().length; x++) {
                    System.out.println("CHOFER");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListChoferTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListMotivoTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListUsuarioTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA MOTIVO CHOFER");
            bitacoraCastigoChoferTO = bitacoraCastigoChoferDAO.selectByRangoFechaMotivoChofer(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1, 1);
            if (bitacoraCastigoChoferTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOCHOFER");
                for (int x = 0; x < bitacoraCastigoChoferTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoChoferTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoChoferTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoChoferTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListChoferTO().length; x++) {
                    System.out.println("CHOFER");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListChoferTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoChoferTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoChoferTO.getListMotivoTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
        } catch (Exception e) {
            System.out.println("Ocurrio una excepcion");
        }
        System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<BITACORACASTIGOUNIDAD>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        try {
            BitacoraCastigoUnidadDAO bitacoraCastigoUnidadDAO = fabricaMySQL.getBitacoraCastigoUnidadDAO();
            BitacoraCastigoUnidadTO bitacoraCastigoUnidadTO = new BitacoraCastigoUnidadTO();
            bitacoraCastigoUnidadTO.setFecha(FechaHoraTO.getFecha("2008/04/04"));
            bitacoraCastigoUnidadTO.setHora(FechaHoraTO.getHora("01:01:01"));
            bitacoraCastigoUnidadTO.setDescripcion("No recuerdo");
            bitacoraCastigoUnidadTO.setIdUnidad(1);
            bitacoraCastigoUnidadTO.setIdMotivo(1);
            bitacoraCastigoUnidadTO.setIdUsuario(1);
            if (bitacoraCastigoUnidadDAO.insertBitacoraCastigoUnidad(bitacoraCastigoUnidadTO)) {
                bitacoraCastigoUnidadDAO.insertBitacoraCastigoUnidad(bitacoraCastigoUnidadTO);
                System.out.println("+++++++++++++++++++ Insertado * correctamente");
            } else System.out.println("Falla en la insercion");
            bitacoraCastigoUnidadTO.setIdOperacion(1);
            bitacoraCastigoUnidadTO.setIdUnidad(1);
            bitacoraCastigoUnidadTO.setIdMotivo(3);
            bitacoraCastigoUnidadTO.setIdUsuario(1);
            resultado = bitacoraCastigoUnidadDAO.updateBitacoraCastigoUnidad(bitacoraCastigoUnidadTO);
            if (resultado == 1) System.out.println("Actualizado correctamente"); else if (resultado == 0) System.out.println("Falla en la actualizacion"); else if (resultado == -1) System.out.println("Ocurrio una excepcion");
            System.out.println("------------------------- BUSQUEDA POR ID");
            bitacoraCastigoUnidadTO = bitacoraCastigoUnidadDAO.findBitacoraCastigoUnidadById(1);
            if (bitacoraCastigoUnidadTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOUNIDAD");
                ImprimirTO.Imprime(bitacoraCastigoUnidadTO);
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("**++++++++++++++++++++++ SELECTBITACORACASTIGOUNIDAD +**");
            java.util.Collection<BitacoraCastigoUnidadTO> listBitacoraCastigoUnidadTO = bitacoraCastigoUnidadDAO.selectBitacoraCastigoUnidad();
            if (listBitacoraCastigoUnidadTO != null) {
                for (int i = 0; i < listBitacoraCastigoUnidadTO.size(); i++) {
                    bitacoraCastigoUnidadTO = ((ArrayList<BitacoraCastigoUnidadTO>) listBitacoraCastigoUnidadTO).get(i);
                    System.out.println("BITACORACASTIGOUNIDAD");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO);
                }
            } else {
                System.out.println("No hubo resultados en la seleccion");
            }
            System.out.println("**++++++++++++++++++++++ SELECTBITACORACASTIGOUNIDAD BY RANGO FECHA HORA+**");
            listBitacoraCastigoUnidadTO = bitacoraCastigoUnidadDAO.selectByRangoFechaHora(FechaHoraTO.getFecha("2003/04/04"), FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getHora("00:00:00"), FechaHoraTO.getHora("23:00:00"));
            if (listBitacoraCastigoUnidadTO != null) {
                for (int i = 0; i < listBitacoraCastigoUnidadTO.size(); i++) {
                    bitacoraCastigoUnidadTO = ((ArrayList<BitacoraCastigoUnidadTO>) listBitacoraCastigoUnidadTO).get(i);
                    System.out.println("BITACORACASTIGOUNIDAD");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO);
                }
            } else {
                System.out.println("No hubo resultados en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA UNIDAD");
            bitacoraCastigoUnidadTO = bitacoraCastigoUnidadDAO.selectByRangoFechaUnidad(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraCastigoUnidadTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOUNIDAD");
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoUnidadTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoUnidadTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListHora().length; x++) {
                    System.out.println("HORA");
                    System.out.println(bitacoraCastigoUnidadTO.getListHora()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoUnidadTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListMotivoTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUnidadTO().length; x++) {
                    System.out.println("UNIDAD");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUnidadTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA MOTIVO");
            bitacoraCastigoUnidadTO = bitacoraCastigoUnidadDAO.selectByRangoFechaMotivo(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraCastigoUnidadTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOUNIDAD");
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoUnidadTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoUnidadTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoUnidadTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUnidadTO().length; x++) {
                    System.out.println("UNIDAD");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUnidadTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListMotivoTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA USURIO");
            bitacoraCastigoUnidadTO = bitacoraCastigoUnidadDAO.selectByRangoFechaUsuario(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1);
            if (bitacoraCastigoUnidadTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOUNIDAD");
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoUnidadTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoUnidadTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoUnidadTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUnidadTO().length; x++) {
                    System.out.println("UNNIDAD");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUnidadTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListMotivoTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUsuarioTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
            System.out.println("------------------- BUSQUEDA POR RANGO FECHA MOTIVO UNIDAD");
            bitacoraCastigoUnidadTO = bitacoraCastigoUnidadDAO.selectByRangoFechaMotivoUnidad(FechaHoraTO.getFecha("2008/04/04"), FechaHoraTO.getFecha("2008/04/04"), 1, 1);
            if (bitacoraCastigoUnidadTO != null) {
                System.out.println("Busqueda exitosa");
                System.out.println("BITACORACASTIGOUNIDAD");
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListIdOperacion().length; x++) {
                    System.out.println("IDOPERACION");
                    System.out.println(bitacoraCastigoUnidadTO.getListIdOperacion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListFecha().length; x++) {
                    System.out.println("FECHA");
                    System.out.println(bitacoraCastigoUnidadTO.getListFecha()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListDescripcion().length; x++) {
                    System.out.println("DESCRIPCION");
                    System.out.println(bitacoraCastigoUnidadTO.getListDescripcion()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUsuarioTO().length; x++) {
                    System.out.println("USUARIO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUsuarioTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListUnidadTO().length; x++) {
                    System.out.println("UNIDAD");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListUnidadTO()[x]);
                }
                for (int x = 0; x < bitacoraCastigoUnidadTO.getListMotivoTO().length; x++) {
                    System.out.println("MOTIVO");
                    ImprimirTO.Imprime(bitacoraCastigoUnidadTO.getListMotivoTO()[x]);
                }
            } else {
                System.out.println("Falla en la seleccion");
            }
        } catch (Exception e) {
            System.out.println("Ocurrio una excepcion");
        }
    }
