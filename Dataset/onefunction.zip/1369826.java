    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Usage : java -jar ISBNExtractor-1.0.jar [FILES]");
            System.err.println("Extract ISBN(s) from pdf FILE(s).");
            System.exit(1);
        }
        FileISBNExtractor fileISBNExtractor = FileISBNExtractorFactory.getFileISBNExtractor(new File("config.properties"));
        for (String arg : args) {
            File file = new File(arg);
            System.out.println(file);
            ISBNCandidates isbnCandidates;
            try {
                isbnCandidates = fileISBNExtractor.getIsbnCandidates(file);
                if (isbnCandidates.size() == 0) {
                    System.out.println("No isbn found");
                } else {
                    System.out.println("Best isbn found : " + isbnCandidates.getHighestScoreISBN().getIsbn());
                }
            } catch (IOException e) {
                System.out.println("Could not get isbn :" + e.getMessage());
            }
            System.out.println();
        }
    }
