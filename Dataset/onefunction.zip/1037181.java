        public int compare(Object a, Object b) {
            Dbxref ad = (Dbxref) a;
            Dbxref bd = (Dbxref) b;
            int compVal = ad.getDatabase().compareToIgnoreCase(bd.getDatabase());
            if (compVal != 0) return compVal;
            compVal = ad.getDatabaseID().compareToIgnoreCase(bd.getDatabaseID());
            if (compVal != 0) return compVal;
            if (ad.getDesc() == null) {
                if (bd.getDesc() == null) return 0; else return -1;
            } else if (bd.getDesc() == null) return 1; else return ad.getDesc().compareToIgnoreCase(bd.getDesc());
        }
