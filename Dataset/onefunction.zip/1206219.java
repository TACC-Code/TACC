    public void testParseResponse() throws Exception {
        byte[] b = "oauth_token=hh5s93j4hdidpola&oauth_token_secret=hdhd0244k9j7ao03".getBytes(Constants.ENCODING);
        ByteArrayInputStream in = new ByteArrayInputStream(b);
        Token token = new Token();
        Transport.parse(in, token);
        assertEquals("hh5s93j4hdidpola", token.getKey());
        assertEquals("hdhd0244k9j7ao03", token.getSecret());
    }
