    public boolean isAttribute(Class<?> clazz, List<String> classesNames, Field field) {
        RelationshipSpecification relationshipSpecification = new RelationshipSpecification();
        boolean result = !relationshipSpecification.isRelationship(clazz, classesNames, field) && !field.getName().contains("$");
        if (JsignerConfiguration.hideSerialVersion()) {
            result = result && !field.getName().equals("serialVersionUID");
        }
        return result;
    }
