    public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException {
        PeerConfig config = new PeerConfig();
        config.setPeerID(IDFactory.newRandomID());
        String address = InetAddress.getLocalHost().getHostAddress();
        List<EndPoint> list = new ArrayList<EndPoint>(Arrays.asList(new TcpEndPoint(address, 7373)));
        config.addEndPoints(list);
        PeerNode p = new ProxyPeer(config);
        String lista = new JsonPeerSerializer().serialize(Arrays.asList(p, p));
        System.out.println(lista);
        new JsonPeerSerializer().unserializeCollection(lista);
    }
