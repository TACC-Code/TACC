    protected IDeidentificationStrategy getDeidentificationStrategy() throws DicomException {
        logger.debug("Entering getDeidentificationStrategy().");
        IDeidentificationStrategy strategy = DeidentificationStrategyFactory.getInstance().createDeidentificationStrategy(IDeidentificationStrategyFactory.STRATEGY_OPTION_PSEUDONYMISATION_REVERSIBLE_DES);
        if (logger.isDebugEnabled()) {
            logger.debug("Exiting getDeidentificationStrategy(); RV = " + (strategy != null ? "[" + strategy + "]" : null) + ".");
        }
        return strategy;
    }
