    public static void main(String[] args) {
        ApplicationContext context = null;
        try {
            PropertyConfigurator.configure("log4j.properties");
            context = new ClassPathXmlApplicationContext("jdm-config.xml");
            ConnectionFactory connFactory = (ConnectionFactory) context.getBean("dme-factory");
            Connection conn = connFactory.getConnection();
            long begin = System.currentTimeMillis();
            PhysicalDataSetFactory dataFactory = (PhysicalDataSetFactory) conn.getFactory(PhysicalDataSet.class.getName());
            String uri = "arff://data/soybean.arff";
            PhysicalDataSet data = dataFactory.create(uri, true);
            String dataName = "assoc";
            conn.saveObject(dataName, data, true);
            RecodeSettingsFactory rsfactory = (RecodeSettingsFactory) conn.getFactory(RecodeSettings.class.getName());
            RecodeSettings rs = rsfactory.create();
            for (Object obj : data.getAttributeNames(AttributeDataType.stringType)) {
                rs.recodeStringWith(obj.toString(), null, null, false, RecodeSettings.ATTR_NAME + "[" + RecodeSettings.ATTR_VALUE + "]", null);
            }
            String transSettingsSeqName = "assocTrans1";
            TransformationSettingsSequenceFactory seqfactory = (TransformationSettingsSequenceFactory) conn.getFactory(TransformationSettingsSequence.class.getName());
            TransformationSettingsSequence seq = seqfactory.create(new TransformationSettings[] { rs });
            conn.saveObject(transSettingsSeqName, seq, true);
            AssociationSettingsFactory settingsFactory = (AssociationSettingsFactory) conn.getFactory(AssociationSettings.class.getName());
            AssociationSettings settings = settingsFactory.create();
            settings.setMinSupport(70);
            settings.setMaxRuleLength(5);
            String settingsName = "assocSettings1";
            conn.saveObject(settingsName, settings, true);
            BuildTaskFactory taskFactory = (BuildTaskFactory) conn.getFactory(BuildTask.class.getName());
            String modelName = "assocModel1";
            BuildTaskImpl task = (BuildTaskImpl) taskFactory.create(dataName, settingsName, modelName);
            task.setTransformationSettingsSequenceName(transSettingsSeqName);
            String taskName = "task1";
            conn.saveObject(taskName, task, true);
            ExecutionHandle exec = conn.execute(taskName);
            ExecutionStatus status = exec.waitForCompletion(Integer.MAX_VALUE);
            RulesFilterFactory filterFactory = (RulesFilterFactory) conn.getFactory(RulesFilter.class.getName());
            RulesFilter filter = filterFactory.create();
            filter.setThreshold(RuleProperty.lift, ComparisonOperator.greaterOrEqual, 1);
            filter.setOrderingCondition(new RuleProperty[] { RuleProperty.lift }, new SortOrder[] { SortOrder.descending });
            AssociationModel model = (AssociationModel) conn.retrieveObject(modelName, NamedObject.model);
            for (Object obj : model.getItemsets()) {
                System.out.println(obj.toString());
            }
            for (Object obj : model.getRules(filter)) {
                System.out.println(obj.toString());
            }
            long end = System.currentTimeMillis();
            System.out.println(status.getState().name() + "," + status.getDescription());
            System.out.println("time used:" + (end - begin));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            ((DataMiningEngine) context.getBean("qiq_dme")).shutdown();
        }
    }
