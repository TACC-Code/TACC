    protected Object doInvoke(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        String methodName = proceedingJoinPoint.getSignature().getName();
        if (methodName.equals("checkContentSearches") || methodName.equals("deleteArticleContentSearch") || methodName.equals("deleteArticleContentSearches") || methodName.equals("deleteLayoutContentSearches") || methodName.equals("deleteOwnerContentSearches") || methodName.equals("getArticleContentSearches") || methodName.equals("updateContentSearch")) {
            ContentSearchInvoker contentSearchInvoker = new ContentSearchInvoker(proceedingJoinPoint);
            if (methodName.equals("checkContentSearches")) {
                contentSearchService.createBinaryContent(contentSearchInvoker);
            } else if (methodName.equals("deleteArticleContentSearch")) {
                contentSearchService.deleteBinaryContent(contentSearchInvoker, null);
            } else if (methodName.equals("deleteArticleContentSearches") || methodName.equals("deleteLayoutContentSearches") || methodName.equals("deleteOwnerContentSearches")) {
                contentSearchService.deleteBinaryContents(contentSearchInvoker);
            } else if (methodName.equals("getArticleContentSearches")) {
                contentSearchService.getBinaryContents(contentSearchInvoker);
            } else if (methodName.equals("updateContentSearch")) {
                contentSearchService.updateBinaryContent(contentSearchInvoker);
            }
            return contentSearchInvoker.getReturnValue();
        } else {
            return proceedingJoinPoint.proceed();
        }
    }
