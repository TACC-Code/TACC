    public static Test suite() {
        TestSuite suite = new TestSuite("Package: test.com.ivis.xprocess.framework.vcs");
        suite.addTestSuite(TestMove.class);
        suite.addTestSuite(TestForwarder.class);
        return suite;
    }
