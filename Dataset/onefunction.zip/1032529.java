    public static void init() {
        tileMap = tmpTileMap;
        walls = tmpWalls;
        tileNames = tmpTileNames;
        tiles = new Image[tileNames.length];
        for (int i = 0; i < tileNames.length; i++) tiles[i] = util.IO.loadImage("Tiles/" + tileNames[i]);
    }
