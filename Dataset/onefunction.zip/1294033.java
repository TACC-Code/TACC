    public void onCompleteCallRequest(CompleteCallRequest request) {
        SimpleCall call = campaignInstance.getCurrentCall();
        CampaignEvent event = call.onCompleteCallRequest(request);
        publish(event);
        performStateTransition(EnumState.PAUSED_STATE);
    }
