    public void dumpForAppAndUsername(final String driverClass, final String jdbcUrl, final String dbUsername, final String dbPassword, final String configTablename, final String configKeyColumnname, final String configTypeColumnname, final String configValueColumnname, final String configUsernameColumnname, final String configAppname, final String configusername) throws ClassNotFoundException, BuilderException {
        final ConnectionProvider conProvider = new DriverManagerConnectionProvider.Builder(driverClass, jdbcUrl, dbUsername, dbPassword).build();
        final ConfigurationTable table = new ConfigurationTable.Builder().setTableName(configTablename).setKeyColumnName(configKeyColumnname).setTypeColumnName(configTypeColumnname).setValueColumnName(configValueColumnname).setBundleColumnName(configUsernameColumnname).build();
        final ConfigurationBuilder builder = new MgmConfigTableConfigurationBuilder(conProvider, table, configusername);
        final Configuration config = builder.buildConfiguration(configAppname);
        final Properties props = config.toProperties();
        System.out.println("num-properties: " + props.size());
        props.list(System.out);
    }
