    public void render(TextureLayer textureLayer) {
        GL11.glLoadIdentity();
        ARBShaderObjects.glUseProgramObjectARB(0);
        textureLayer.getTexture().bind();
        GL11.glBegin(GL11.GL_QUADS);
        {
            int w = Main.displayMode.getWidth();
            int h = Main.displayMode.getHeight();
            GL11.glColor4f(1, 1, 1, textureLayer.getAlpha());
            GL11.glTexCoord2d(0, textureLayer.getTexture().getHeightPercent());
            GL11.glVertex2i(0, 0);
            GL11.glTexCoord2d(textureLayer.getTexture().getWidthPercent(), textureLayer.getTexture().getHeightPercent());
            GL11.glVertex2i(w, 0);
            GL11.glTexCoord2d(textureLayer.getTexture().getWidthPercent(), 0);
            GL11.glVertex2i(w, h);
            GL11.glTexCoord2d(0, 0);
            GL11.glVertex2i(0, h);
        }
        GL11.glEnd();
    }
