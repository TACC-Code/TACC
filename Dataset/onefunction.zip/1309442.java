    public static void main(String args[]) {
        try {
            boolean foundNimbus = false;
            LookAndFeelInfo[] landf = UIManager.getInstalledLookAndFeels();
            for (int i = 0; i < landf.length; i++) {
                if ("Nimbus".equalsIgnoreCase(landf[i].getName())) {
                    UIManager.setLookAndFeel(landf[i].getClassName());
                    foundNimbus = true;
                    break;
                }
            }
            if (!foundNimbus) UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println("No lookAndFeel " + e);
        }
        new IntegralWindow();
    }
