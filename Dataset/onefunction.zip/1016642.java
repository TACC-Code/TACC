    public static Test suite() {
        TestSuite suite = new TestSuite("Test for org.vikamine.subgroup.zoomtable and *.zoomtable.*");
        suite.addTestSuite(CommonDataTest.class);
        suite.addTestSuite(CommonZoomTablesControllerTest.class);
        suite.addTestSuite(ValueSelectionModelTest.class);
        suite.addTestSuite(FilteringNodeTest.class);
        suite.addTestSuite(AttributeNodeTest.class);
        suite.addTestSuite(CommonZoomTreeModelTest.class);
        suite.addTestSuite(AttributeValuesComputerTest.class);
        suite.addTestSuite(DistinctionFinderTest.class);
        return suite;
    }
