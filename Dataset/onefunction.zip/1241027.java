    protected Criteria createCriteria(SearchFilter<TruthsayerNomination> filter) {
        Criteria criteria = getSession().createCriteria(TruthsayerNomination.class);
        if (filter instanceof TruthsayerNominationFilter) {
            TruthsayerNominationFilter cf = (TruthsayerNominationFilter) filter;
            if (cf.getNominee() != null) {
                criteria.add(Restrictions.eq("user", cf.getNominee()));
            }
            if (cf.getStartBefore() != null) {
                criteria.add(Restrictions.lt("voteStart", cf.getStartBefore()));
            } else if (cf.isStartNotSet()) {
                criteria.add(Restrictions.isNull("voteStart"));
            } else if (cf.isStartSet()) {
                criteria.add(Restrictions.isNotNull("voteStart"));
            }
        }
        return criteria;
    }
