    public static boolean isFeedCombined(int feedflg) {
        Boolean o = COMBINED_MAP.get(feedflg);
        if (o == null) {
            return false;
        }
        return o;
    }
