    public static void main(String[] args) throws Exception {
        boolean gotIt = false;
        Bootstrap.init();
        Gosh g = Gosh.factory.makePassThruShell();
        StringWriter sw = new StringWriter();
        try {
            g.run("run c:\\docume~1\\edward~1\\mydocu~1\\gorilla\\dev\\" + "src\\tags\\gxe\\gxe\\scripts\\modules\\dextest\\dextest.zuml");
            g.run("msg We have loaded numero uno!");
            g.run("msg ABOUT TO RESET");
            System.out.println("about to reset............");
            Universe.factory.defaultModelWorld().reset();
            System.out.println("reset completed............");
            g.run("msg RESET COMPLETED");
            g.run("msg ready to load numero due........");
            g.run("run c:\\docume~1\\edward~1\\mydocu~1\\gorilla\\dev\\" + "src\\tags\\gxe\\gxe\\scripts\\modules\\dextest\\dextest.zuml");
            g.run("msg done........");
        } catch (AccessException e) {
            System.out.println(e.getMessage());
            System.out.println(AccessException.elaborate(e));
            e.printStackTrace();
        }
    }
