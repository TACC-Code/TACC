    public static Test suite() throws Exception {
        PathableClassLoader parent = new PathableClassLoader(null);
        parent.useExplicitLoader("junit.", Test.class.getClassLoader());
        parent.addLogicalLib("commons-logging-api");
        PathableClassLoader child = new PathableClassLoader(parent);
        child.addLogicalLib("log4j12");
        child.addLogicalLib("commons-logging");
        child.addLogicalLib("testclasses");
        Class testClass = child.loadClass("org.apache.commons.logging.log4j.log4j12.Log4j12StandardTests");
        return new PathableTestSuite(testClass, child);
    }
