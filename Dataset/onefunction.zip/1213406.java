    public static void load() {
        try {
            Util.printSection("네트워크");
            String network = "./config/network";
            Properties[] props = PropertiesUtils.loadAllFromDirectory(network);
            ConfigurableProcessor.process(Config.class, props);
            log.info("로딩: " + network + "/network.properties");
            log.info("로딩: " + network + "/database.properties");
        } catch (Exception e) {
            log.fatal("Can't load loginserver configuration", e);
            throw new Error("Can't load loginserver configuration", e);
        }
    }
