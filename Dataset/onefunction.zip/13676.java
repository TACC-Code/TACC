    public InfantryPistolSonicStunnerWeapon() {
        super();
        techLevel = TechConstants.T_ALLOWED_ALL;
        name = "Sonic Stunner";
        setInternalName(name);
        addLookupName("InfantrySonicStunnerpistol");
        ammoType = AmmoType.T_NA;
        cost = 100;
        bv = 0.06;
        flags = flags.or(F_NO_FIRES).or(F_INF_NONPENETRATING).or(F_DIRECT_FIRE).or(F_ENERGY);
        infantryDamage = 0.07;
        infantryRange = 0;
    }
