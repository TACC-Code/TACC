    public Object execute(ExecutionEvent event) throws ExecutionException {
        try {
            Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
            QuizResultsView view = (QuizResultsView) PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().showView("org.rcpquizengine.views.results");
            StringBuilder output = new StringBuilder();
            output.append(HTMLPrettyPrinter.HTMLHeader());
            for (Answer answer : view.getAnswers()) {
                QuestionHTMLPrettyPrinter qhtml = new QuestionHTMLPrettyPrinter(answer.getQuestion());
                AnswerHTMLPrettyPrinter ahtml = new AnswerHTMLPrettyPrinter(answer);
                output.append(qhtml.prettyPrint());
                output.append(ahtml.prettyPrint());
                output.append(HTMLPrettyPrinter.HTMLhorizontalLine());
            }
            output.append(HTMLPrettyPrinter.HTMLFooter());
            FileDialog dlg = new FileDialog(shell, SWT.SAVE);
            String filename = dlg.open();
            if (filename != null) {
                PrintWriter writer = new PrintWriter(filename);
                writer.write(output.toString());
                writer.flush();
                writer.close();
            }
        } catch (PartInitException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
