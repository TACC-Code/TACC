    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        FacadeHelpDesk facade = FacadeHelpDesk.getInstance();
        int idChamado = Integer.parseInt(request.getParameter(Constantes.ID_CHAMADO));
        try {
            Usuario usuario = MySession.getInstance().getUsuario();
            String idUnidade = request.getParameter(Constantes.UNIDADE);
            facade.interEncaminharChamado(idChamado, idUnidade);
            Chamado chamado = facade.getChamado(idChamado);
            request.setAttribute(Constantes.CHAMADO, chamado);
            ChamadoAtendido chamadoAtendido = facade.getChamadoAtendido(idChamado);
            request.setAttribute(Constantes.ID_CHAMADO, idChamado);
            request.setAttribute(Constantes.CHAMADO_ATENDIDO, chamadoAtendido);
            List<Transacao> transacoes = facade.getTransacaoParaTecnico(idChamado);
            request.setAttribute(Constantes.TRANSACOES, transacoes);
            boolean isDono = usuario.getIdUsuario().equals(chamado.getResponsavel());
            Unidade unidade = facade.getUnidadeDoTecnico(usuario.getIdUsuario());
            boolean ehDahUnidade = facade.chamadoEhAtendido(idChamado, unidade.getIdUsuario());
            request.setAttribute(Constantes.EH_DAH_UNIDADE, ehDahUnidade);
            request.setAttribute(Constantes.IS_DONO, isDono);
            String gerencia = facade.getGerencia(unidade.getIdUsuario());
            request.setAttribute(Constantes.GERENCIA, gerencia);
            boolean isGerente = facade.isGerente(unidade.getIdUsuario(), usuario.getIdUsuario());
            request.setAttribute(Constantes.IS_GERENTE, isGerente);
            return map.findForward(Constantes.VER_CHAMADO_TECNICO);
        } catch (SessaoFinalizadaException e) {
            return map.findForward(Constantes.INDEX);
        } catch (HelpDeskException e) {
            return LoginAction.redirecionarErro(map, request, e.getMessage());
        }
    }
