    public static void main(String[] args) throws SQLException {
        cn = new DBObject().get_connection();
        int count = 0;
        int numberOfBooks;
        int numberOfTags;
        int numberOfConnections;
        int uID;
        String userName;
        boolean moled;
        Collection<UserDTO> allUsers = new LinkedList<UserDTO>();
        allUsers = UserDB.findAllUserForUpdate(cn);
        Iterator it = allUsers.iterator();
        while (it.hasNext()) {
            UserDTO user = (UserDTO) it.next();
            numberOfBooks = user.getNumberOfBookmarks();
            numberOfTags = user.getNumberOfTags();
            numberOfConnections = user.getNumberOfConnections();
            uID = user.getUID();
            userName = user.getUserName();
            moled = user.isMoled();
            if (numberOfBooks == 0) {
                System.out.println("NumberOfBooks von " + userName + " wird ermittelt");
                numberOfBooks = UserDB.getNumberOfBooksUserDB(cn, userName);
                boolean ok = UserDB.updateUserNumberOfBooks(cn, uID, numberOfBooks);
                if (ok) {
                    count++;
                    System.out.println(count + " Anzahl der Bookmarks wurde ge�ndert auf: " + numberOfBooks);
                } else System.out.println("Es gab einen Fehler beim Update von User: " + userName);
            }
            if (numberOfConnections == 999999) {
                System.out.println("NumberOfConnections von " + userName + " wird ermittelt");
                numberOfConnections = UserDB.getNumberOfConnections(cn, uID);
                boolean ok = UserDB.updateUserNumberOfConnections(cn, uID, numberOfConnections);
                if (ok) {
                    count++;
                    System.out.println(count + " Anzahl der Connections wurde ge�ndert auf: " + numberOfConnections);
                } else System.out.println("Es gab einen Fehler beim Update von User: " + userName);
            }
            if (numberOfTags == 0) {
                System.out.println("NumberOfTags von " + userName + " wird ermittelt");
                numberOfTags = UserDB.getNumberOfTagsUserDB(cn, userName);
                boolean ok = UserDB.updateUserNumberOfTags(cn, uID, numberOfTags);
                if (ok) {
                    count++;
                    System.out.println(count + " Anzahl der Tags wurde ge�ndert auf: " + numberOfTags);
                } else System.out.println("Es gab einen Fehler beim Update von User: " + userName);
            }
        }
        System.out.println("\nFERIG!!!\nAnzahl der ge�nderten User: " + count);
        cn.close();
    }
