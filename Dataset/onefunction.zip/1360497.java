    public static Test suite() {
        TestSuite suite = new TestSuite();
        suite.addTestSuite(VacancyApplicationEMailTest.class);
        suite.addTestSuite(AgencyManagerImplTest.class);
        suite.addTestSuite(AgentManagerImplTest.class);
        suite.addTestSuite(CVManagerImplTest.class);
        suite.addTestSuite(StaticDataManagerImplTest.class);
        suite.addTestSuite(VacancyManagerImplTest.class);
        suite.addTestSuite(JobserveCSVVacancySourceTest.class);
        suite.addTestSuite(PurgeJobTest.class);
        suite.addTestSuite(VacancySourceDataTest.class);
        return suite;
    }
