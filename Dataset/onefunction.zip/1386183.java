    public plugin() {
        JMenu menu, submenu;
        JMenuItem item;
        menu = Cytoscape.getDesktop().getCyMenus().getOperationsMenu();
        submenu = new JMenu("Cytoprophet");
        item = new JMenuItem("Start");
        item.addActionListener(new addToControlPanel());
        submenu.add(item);
        menu.add(submenu);
    }
