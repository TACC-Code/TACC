    public void testRunGenerator() throws JAXBException, ComponentLookupException, GeneratorException {
        JAXBContext jaxbContext = JAXBContext.newInstance(ProtocolType.class.getPackage().getName());
        Unmarshaller u = jaxbContext.createUnmarshaller();
        JAXBElement<ProtocolType> el = (JAXBElement<ProtocolType>) u.unmarshal(getClass().getResourceAsStream("/loxim2.xml"));
        ProtocolType pt = el.getValue();
        LanguageGenerator lg = (LanguageGenerator) getContainer().lookup(LanguageGenerator.ROLE, "java");
        lg.generate(pt, new File("./target/surefire/result"), null);
    }
