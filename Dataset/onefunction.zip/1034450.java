    public static void unzip(String zipFileName, String outputDir, GeneratorThread thread) throws IOException {
        ZipFile zip = new ZipFile(zipFileName);
        int size = zip.size();
        if (size > 0) {
            Enumeration entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = (ZipEntry) entries.nextElement();
                if (entry.getMethod() == ZipEntry.DEFLATED) thread.addMessageToBuffer(" Inflating: " + entry.getName()); else thread.addMessageToBuffer(" Extracting: " + entry.getName());
                File File = new File(outputDir, entry.getName());
                File.getParentFile().mkdirs();
                if (!entry.isDirectory()) {
                    InputStream in = null;
                    OutputStream out = null;
                    try {
                        in = new BufferedInputStream(zip.getInputStream(entry));
                        out = new BufferedOutputStream(new FileOutputStream(File));
                        byte[] buffer = new byte[512];
                        for (int n = 0; (n = in.read(buffer)) > -1; ) {
                            out.write(buffer, 0, n);
                        }
                        out.flush();
                    } finally {
                        if (out != null) {
                            try {
                                out.close();
                            } catch (IOException e) {
                            }
                        }
                    }
                }
            }
        }
        zip.close();
    }
