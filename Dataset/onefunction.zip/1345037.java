    public static boolean isTrue(saf.data.Logic logic, State state) {
        if (logic instanceof saf.data.Condition) {
            return Condition.isTrue((saf.data.Condition) logic, state);
        } else if (logic instanceof saf.data.LogicAnd) {
            return LogicAnd.isTrue((saf.data.LogicAnd) logic, state);
        } else {
            return LogicOr.isTrue((saf.data.LogicOr) logic, state);
        }
    }
