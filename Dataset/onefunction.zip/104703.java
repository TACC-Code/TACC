    public void testAccessWebView() {
        WebView webView = new WebView(mContext);
        WebViewTransport transport = webView.new WebViewTransport();
        assertNull(transport.getWebView());
        transport.setWebView(webView);
        assertSame(webView, transport.getWebView());
    }
