    public List<JAXBElement<String>> getNamesAndUrisAndEmails() {
        if (namesAndUrisAndEmails == null) {
            namesAndUrisAndEmails = new ArrayList<JAXBElement<String>>();
        }
        return this.namesAndUrisAndEmails;
    }
