    public static void main(String[] args) throws IOException {
        FileInputStream fis = null;
        PipedOutputStream outStream = new PipedOutputStream();
        PipedInputStream inStream = new PipedInputStream(outStream);
        XMLDivisor xmldivisor = new XMLDivisor(inStream, "ENVELOPE");
        try {
            Thread t1 = new Thread(xmldivisor);
            t1.setDaemon(false);
            t1.start();
            for (int i = 0; i < args.length; i++) {
                File f = new File(args[i]);
                System.err.println(f.getAbsolutePath() + "   " + f.isFile());
                fis = new FileInputStream(f);
                int c = 0;
                while ((c = fis.read()) >= 0) {
                    outStream.write(c);
                }
                fis.close();
            }
            outStream.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        String xml = "";
        while ((xml = xmldivisor.getXML()) != null) {
            System.out.println(">>>>" + xml + "<<<<<");
        }
    }
