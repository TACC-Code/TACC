    public void printBody() throws IOException, SQLException {
        StringBuffer headerRow = new StringBuffer("<tr>");
        String title = "Results";
        headerRow.append("<th colspan=\"2\">" + title + "</th>");
        headerRow.append("</tr>");
        out.println(headerRow.toString());
        int row_count = 0;
        float fileSize = 0;
        boolean even = false;
        String formattedString;
        String trHeaderStr = "<tr class=\"selected\">";
        while ((rs.next()) && ((lineLimitSize == -1) || (row_count < lineLimitSize)) && ((mbLimitSize == -1) || (fileSize < mbLimitSize))) {
            if (even) {
                trHeaderStr = "<tr class=\"selected\"><td><table border=\"0\" cellpadding=\"3\">";
            } else {
                trHeaderStr = "<tr><td><table border=\"0\" cellpadding=\"3\">";
            }
            even = !even;
            out.print(trHeaderStr);
            for (int i = 0; i < niceNames.length; i++) {
                out.print("<tr><td>" + niceNames[i] + "</td>");
                if (classNames[i].equals("Timestamp")) {
                    formattedString = getAndFormat(rs.getTimestamp(i + 1), formats[i]);
                } else {
                    if (classNames[i].equals("BigDecimal")) {
                        formattedString = getAndFormat(rs.getBigDecimal(i + 1), formats[i]);
                    } else {
                        formattedString = rs.getString(i + 1);
                    }
                }
                out.print("<td>" + formattedString + "</td>");
                try {
                    fileSize += formattedString.length() + 9;
                } catch (NullPointerException npe) {
                    fileSize += 13;
                }
                out.println("</tr>");
            }
            out.println("</table></td></tr>");
            row_count++;
            fileSize += 10;
            if (row_count / 1000.0 == (int) (row_count / 1000.0)) {
                out.println("</table><table border=\"1\" cellpadding=\"3\">" + headerRow.toString());
            }
        }
        recordsReturned = row_count;
        bytesReturned = fileSize;
    }
