    public List<T> filter(Collection<RetailTransactionLineItem> lineItems, Class<T> filterClass) {
        List<T> list = new ArrayList<T>();
        if (lineItems != null) {
            for (RetailTransactionLineItem lineItem : lineItems) {
                if (lineItem != null && filterClass.isInstance(lineItem) && shouldInclude(filterClass.cast(lineItem))) {
                    list.add(filterClass.cast(lineItem));
                }
            }
        }
        return list;
    }
