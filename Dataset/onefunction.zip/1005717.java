    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String target = "";
        String strOrgTypeID = null;
        String strOrgID = null;
        try {
            String strIsolate = request.getParameter("isolate");
            if (!strIsolate.equals("null")) {
                request.setAttribute("isolate", strIsolate);
            } else {
                strOrgTypeID = Translate.translate(request.getParameter("orgTypeID"), Constant.PARAM_GET);
                strOrgID = Translate.translate(request.getParameter("orgID"), Constant.PARAM_GET);
                request.setAttribute("orgTypeID", strOrgTypeID);
                request.setAttribute("orgID", strOrgID);
            }
            target = "success";
        } catch (Exception e) {
        }
        return (mapping.findForward(target));
    }
