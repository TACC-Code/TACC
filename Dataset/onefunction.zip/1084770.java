    public static void main(String[] args) {
        String fileName1 = null;
        boolean header = false;
        boolean filesLoaded = false;
        System.out.println("Docs: http://wiki.stat.ucla.edu/socr/index.php/SOCR_EduMaterials_AnalysesCommandLine");
        try {
            fileName1 = args[0];
            filesLoaded = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (args.length >= 2) {
            if (args[1].equals("-h")) header = true;
        }
        if (!filesLoaded) {
            return;
        }
        String[] varHeaders = null;
        ArrayList<ArrayList<String>> lists = new ArrayList<ArrayList<String>>();
        String line = null;
        StringTokenizer st = null;
        int sampleSize = 0;
        int columnCount = 0;
        try {
            BufferedReader bReader = new BufferedReader(new FileReader(fileName1));
            if (header) {
                line = bReader.readLine();
                st = new StringTokenizer(line, ",; \t");
                columnCount = st.countTokens();
                varHeaders = new String[columnCount];
                for (int i = 0; i < columnCount; i++) varHeaders[i] = st.nextToken().trim();
            }
            while ((line = bReader.readLine()) != null) {
                st = new StringTokenizer(line, ",; \t");
                columnCount = st.countTokens();
                ArrayList<String> list = new ArrayList<String>();
                try {
                    while (st.hasMoreTokens()) {
                        String input = st.nextToken().trim();
                        if (!input.equalsIgnoreCase(MISSING_MARK)) {
                            list.add(input);
                        }
                    }
                    sampleSize++;
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
                lists.add(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Sample size = " + sampleSize);
        Data data = new Data();
        double[] xData = new double[sampleSize];
        for (int i = 0; i < columnCount; i++) {
            xData = new double[sampleSize];
            for (int j = 0; j < sampleSize; j++) {
                try {
                    xData[j] = (Double.valueOf((String) (lists.get(j)).get(i))).doubleValue();
                } catch (NumberFormatException e) {
                    System.out.println("Line " + (i + 1) + " is not in correct numerical format.");
                    return;
                }
            }
            if (i == 0) data.appendY("Y", xData, DataType.QUANTITATIVE);
            if (i == 1) data.appendX("X", xData, DataType.QUANTITATIVE);
        }
        KolmogorovSmirnoffResult result = null;
        try {
            result = (KolmogorovSmirnoffResult) data.getAnalysis(AnalysisType.KOLMOGOROV_SMIRNOFF);
        } catch (Exception e) {
            e.printStackTrace();
        }
        double dStat = -1;
        double[] diff = null;
        double[] absDiff = null;
        double mean1 = 0, mean2 = 0, sd1 = 0, sd2 = 0, median1 = 0, median2 = 0;
        double q1x1 = 0, q3x1 = 0, q1x2 = 0, q3x2 = 0;
        double[] ci95X1 = null, ci95X2 = null;
        String lowerOutlier1 = null, lowerOutlier2 = null, upperOutlier1 = null, upperOutlier2 = null;
        double[] sortedX1 = null, sortedX2 = null, y1 = null, y2 = null;
        double[] logX1 = null, logX2 = null;
        DecimalFormat dFormat = new DecimalFormat("#.00000");
        result.setDecimalFormat(dFormat);
        try {
            sortedX1 = result.getVariable1X();
        } catch (Exception e) {
        }
        try {
            sortedX2 = result.getVariable2X();
        } catch (Exception e) {
        }
        try {
            y1 = result.getVariable1Y();
        } catch (Exception e) {
        }
        try {
            y2 = result.getVariable2Y();
        } catch (Exception e) {
        }
        try {
            logX1 = result.getVariable1LogX();
        } catch (Exception e) {
        }
        try {
            logX2 = result.getVariable2LogX();
        } catch (Exception e) {
        }
        try {
            diff = result.getDiff();
        } catch (Exception e) {
        }
        try {
            absDiff = result.getAbsDiff();
        } catch (Exception e) {
        }
        try {
            dStat = result.getDStat();
        } catch (Exception e) {
        }
        try {
            mean1 = result.getMean1();
        } catch (Exception e) {
        }
        try {
            mean2 = result.getMean2();
        } catch (Exception e) {
        }
        try {
            sd1 = result.getSD1();
        } catch (Exception e) {
        }
        try {
            sd2 = result.getSD2();
        } catch (Exception e) {
        }
        try {
            median1 = result.getMedian1();
        } catch (Exception e) {
        }
        try {
            median2 = result.getMedian2();
        } catch (Exception e) {
        }
        try {
            q1x1 = result.getFirstQuartile1();
        } catch (Exception e) {
        }
        try {
            q1x2 = result.getFirstQuartile2();
        } catch (Exception e) {
        }
        try {
            q3x1 = result.getThirdQuartile1();
        } catch (Exception e) {
        }
        try {
            q3x2 = result.getThirdQuartile2();
        } catch (Exception e) {
        }
        try {
            ci95X1 = result.getCI95X1();
        } catch (Exception e) {
        }
        try {
            ci95X2 = result.getCI95X2();
        } catch (Exception e) {
        }
        try {
            lowerOutlier1 = result.getBoxLowerOutlier1();
        } catch (Exception e) {
        }
        try {
            lowerOutlier2 = result.getBoxLowerOutlier2();
        } catch (Exception e) {
        }
        try {
            upperOutlier1 = result.getBoxUpperOutlier1();
        } catch (Exception e) {
        }
        try {
            upperOutlier2 = result.getBoxUpperOutlier2();
        } catch (Exception e) {
        }
        String zFormula = null;
        double z = 0, prob = 0;
        try {
            zFormula = result.getZFormula();
        } catch (Exception e) {
        }
        try {
            z = result.getZStat();
        } catch (Exception e) {
        }
        try {
            prob = result.getProb();
        } catch (Exception e) {
        }
        System.out.println("\n\tVariable 1 = " + varHeaders[0]);
        System.out.println("\n\tVariable 2 = " + varHeaders[1]);
        System.out.println("\n\n\tKolmogorov-Smirnoff Test Result:\n");
        System.out.println("\n\tVariable 1 = " + varHeaders[0]);
        System.out.println("\n\tSample Size = " + sampleSize);
        System.out.println("\n\tSample Mean = " + result.getFormattedDouble(mean1));
        System.out.println("\n\tSample SD = " + result.getFormattedDouble(sd1));
        System.out.println("\n\t95% CI of the mean = (" + result.getFormattedDouble(ci95X1[0]) + ", " + result.getFormattedDouble(ci95X1[1]) + ")");
        System.out.println("\n\tFirst Quartile = " + result.getFormattedDouble(q1x1));
        System.out.println("\n\tMedian = " + result.getFormattedDouble(median1));
        System.out.println("\n\tThird Quartile = " + result.getFormattedDouble(q1x1));
        System.out.println("\n\tBox plot outliers below Q1 - 1.5IQR: " + lowerOutlier1);
        System.out.println("\n\tBox plot outliers above Q3 - 1.5IQR: " + upperOutlier1);
        System.out.println("\n\n\tVariable 2 = " + varHeaders[1]);
        System.out.println("\n\tSample Size = " + sampleSize);
        System.out.println("\n\tSample Mean = " + result.getFormattedDouble(mean2));
        System.out.println("\n\tSample SD = " + result.getFormattedDouble(sd2));
        System.out.println("\n\t95% CI of the mean = (" + result.getFormattedDouble(ci95X2[0]) + ", " + result.getFormattedDouble(ci95X2[1]) + ")");
        System.out.println("\n\tFirst Quartile = " + result.getFormattedDouble(q1x2));
        System.out.println("\n\tMedian = " + result.getFormattedDouble(median2));
        System.out.println("\n\tThird Quartile = " + result.getFormattedDouble(q1x2));
        System.out.println("\n\tBox plot outliers below Q1 - 1.5IQR: " + lowerOutlier2);
        System.out.println("\n\tBox plot outliers above Q3 - 1.5IQR: " + upperOutlier2);
        if (dStat != -1) {
            System.out.println("\n\n\tKolmogorov-Smirnoff Test:");
            System.out.println("\n\tD-Statistics = " + result.getFormattedDouble(dStat));
            System.out.println("\n\t" + zFormula + "\tz = " + result.getFormattedDouble(z));
            System.out.println("\n\tCDF(" + result.getFormattedDouble(dStat) + ") = " + result.getFormattedDouble(prob));
            System.out.println("\n\t1 - CDF(" + result.getFormattedDouble(dStat) + ") = " + result.getFormattedDouble((1 - prob)));
        }
    }
