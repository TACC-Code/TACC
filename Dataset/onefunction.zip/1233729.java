    public boolean visit(CompilationUnit unit) {
        NodeLookup nodes = getNodeLookup(unit);
        for (MethodDeclaration node : nodes.getNodes(MethodDeclaration.class)) {
            IMethodBinding method = node.resolveBinding();
            if (null == method) {
                continue;
            }
            IMethodBinding compat = RuleUtils.findCompatibleMethod(method, method.getDeclaringClass(), true);
            if (null != compat) {
                addProblem(node.getName(), RuleUtils.getDisplaySignature(method), RuleUtils.getDisplaySignature(compat));
            }
        }
        return false;
    }
