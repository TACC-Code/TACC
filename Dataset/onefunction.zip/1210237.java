    public ActionForward executeAction(AvatalActionMapping mapping, DynaValidatorForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        log.debug("executeAction() in ViewCourseAction called");
        CourseContentManagementDelegate courseContentDelegate = new CourseContentManagementDelegate();
        Integer courseId = (Integer) request.getAttribute("courseId");
        UserVo loggedUser = (UserVo) getSession(request).getAttribute(HttpSessionConstants.USER);
        List courseContents = courseContentDelegate.getEditCourseContents(loggedUser, courseId);
        CourseContentListViewAssembler courseContentListViewAssembler = new CourseContentListViewAssembler();
        courseContentListViewAssembler.addCourseContents((ArrayList) courseContents, loggedUser.getLocale());
        getSession(request).removeAttribute(CourseContentListView.VIEW_NAME);
        getSession(request).setAttribute(CourseContentListView.VIEW_NAME, courseContentListViewAssembler.getCourseContentListView());
        return mapping.findForward(Constants.SUCCESS_KEY);
    }
