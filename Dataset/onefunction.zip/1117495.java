    protected void handle(Command command, Session session) {
        verifyLoggedIn(session);
        sendReply(session, ReplyCodes.TRANSFER_DATA_INITIAL_OK);
        String path = getRealPath(session, command.getParameter(0));
        if (getFileSystem().exists(path)) {
            this.replyCodeForFileSystemException = ReplyCodes.READ_FILE_ERROR;
            verifyReadPermission(session, path);
        }
        this.replyCodeForFileSystemException = ReplyCodes.SYSTEM_ERROR;
        List fileEntries = getFileSystem().listFiles(path);
        Iterator iter = fileEntries.iterator();
        List lines = new ArrayList();
        while (iter.hasNext()) {
            FileSystemEntry entry = (FileSystemEntry) iter.next();
            lines.add(getFileSystem().formatDirectoryListing(entry));
        }
        String result = StringUtil.join(lines, endOfLine());
        session.openDataConnection();
        LOG.info("Sending [" + result + "]");
        session.sendData(result.getBytes(), result.length());
        session.closeDataConnection();
        sendReply(session, ReplyCodes.TRANSFER_DATA_FINAL_OK);
    }
