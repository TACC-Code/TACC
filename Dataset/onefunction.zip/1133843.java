    static int rate(Node node, int[] situation, int nextPlayer) {
        int player = nextPlayer;
        if (!node.isMaxNode()) player = GetFour.getOpponent(player);
        if (GetFour.discsInARow(situation, player, 4, false)) return 9;
        if (GetFour.discsInARow(situation, GetFour.getOpponent(player), 4, false)) return -10;
        byte score = 0;
        if (GetFour.discsInARow(situation, player, 3, false)) score += 4; else if (GetFour.discsInARow(situation, GetFour.getOpponent(player), 3, false)) score += -5; else if (GetFour.discsInARow(situation, player, 2, false)) score += 1; else if (GetFour.discsInARow(situation, GetFour.getOpponent(player), 2, false)) score += -2;
        return (int) score;
    }
