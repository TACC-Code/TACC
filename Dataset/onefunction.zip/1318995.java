    public List execute(ComClient comClient) throws Exception {
        ArrayList list = new ArrayList();
        Vector dirs = SharesManager.getInstance().getSharedDirs();
        int n = dirs.size();
        for (int i = 0; i < n; i++) {
            SharedDir dir = (SharedDir) dirs.elementAt(i);
            list.add(dir.toString());
        }
        return list;
    }
