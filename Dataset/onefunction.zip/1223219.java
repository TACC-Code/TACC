    public void onPostGeneration(GenerationManager manager) throws CoreException {
        List<ExportedEntry> entries = ExportManager.getClasspath(WebShadow.NATURE);
        IFolder iDestination = manager.getGeneratedProject().getFolder(LIBRARY_PATH);
        for (ExportedEntry e : entries) {
            try {
                IFile iFile = iDestination.getFile(e.getFileName());
                if (!iFile.exists()) iFile.create(e.openStream(), true, null);
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
        manager.getGeneratedProject().refreshLocal(IResource.DEPTH_INFINITE, null);
    }
