    public void putInstanceUsage(String instanceId, Date date, Time time, double usage) {
        DatabaseConnector dbConnector = new DatabaseConnector();
        try {
            CustomerInstance customerInstance = new CustomerInstance();
            CustomerUsage customerUsage = new CustomerUsage();
            String customerId = null;
            dbConnector.setupConnection();
            PreparedStatement update = dbConnector.con.prepareStatement("insert into instance_usage values('" + instanceId + "','" + date.toString() + "','" + time.toString() + "'," + usage + ")");
            int status = update.executeUpdate();
            customerId = customerInstance.getCustomerId(instanceId);
            customerUsage.addUsage(customerId, date, time, usage);
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            dbConnector.closeConnection();
        }
    }
