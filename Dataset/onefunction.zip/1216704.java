    public List<DiscoveryDescriptorEnt> getReturn() {
        if (_return == null) {
            _return = new ArrayList<DiscoveryDescriptorEnt>();
        }
        return this._return;
    }
