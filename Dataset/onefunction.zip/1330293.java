    public int doStartTag() throws JspException {
        HttpServletRequest request = (HttpServletRequest) pageContext.getRequest();
        AttributePrincipal principal = (AttributePrincipal) request.getUserPrincipal();
        String userId = null;
        if (principal != null) {
            userId = principal.getName();
        } else {
            userId = AuthenticationCookieUtils.getUserName(request);
        }
        try {
            if (userId != null) {
                pageContext.getOut().print("<div id='loginId'>Logged in as " + userId + "</div>");
            }
        } catch (Exception e) {
            logger.error("LoggedInUserIdTag: " + e.getMessage(), e);
            throw new JspTagException("LoggedInUserIdTag: " + e.getMessage());
        }
        return super.doStartTag();
    }
