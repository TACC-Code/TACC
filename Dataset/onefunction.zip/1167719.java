    public static void main(String[] args) {
        new Widget(new javax.swing.JButton("HELLO"), 10, 10).toWhiteFile("image/test/images/widget-1.png");
        new Widget(new javax.swing.JCheckBox("Say 'HELLO'?"), 10, 10).toWhiteFile("image/test/images/widget-2.png");
        JPanel p = new JPanel(new java.awt.GridLayout(2, 1));
        p.add(new JRadioButton("HELLO"));
        p.add(new JRadioButton("GOODBYE"));
        JFrame f = new JFrame("SAMPLE");
        f.setSize(200, 200);
        f.getContentPane().add(p);
        f.setVisible(true);
    }
