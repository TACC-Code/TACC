    public IStatus validate(IValidationContext ctx) {
        EObject target = ctx.getTarget();
        if (target instanceof Predicate) {
            Predicate predicate = (Predicate) target;
            if (StringTool.isEmpty(predicate.getName())) {
                return ctx.createFailureStatus(target.eClass().getName());
            }
        }
        return ctx.createSuccessStatus();
    }
