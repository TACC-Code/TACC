    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        double latitude = Utils.getDouble(req, "lat", 48.8);
        double longitude = Utils.getDouble(req, "lon", 2.3);
        int max = Utils.getInt(req, "max", 100);
        String all = req.getParameter("all");
        String dateUpdate = req.getParameter("dateUpdate");
        String minRating = req.getParameter("minRating");
        Writer out = resp.getWriter();
        resp.setContentType(Constants.CONTENT_TYPE_XML);
        resp.setCharacterEncoding("UTF-8");
        out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        out.write("<tags>");
        List<Tag> list;
        String mode;
        if ((all != null) && (all.equals("true"))) {
            list = TagService.getAllTags();
            mode = "all";
        } else if (dateUpdate != null) {
            list = TagService.getLastTags(Long.parseLong(dateUpdate));
            mode = "latest : from " + dateUpdate;
        } else if (minRating != null) {
            list = TagService.getBestTags(Integer.parseInt(minRating));
            mode = "best : min rating count = " + minRating;
        } else {
            list = TagService.getNearestTags(latitude, longitude, max);
            mode = "nearest : lat = " + latitude + " lon = " + longitude + " max = " + max;
        }
        out.write("<count>");
        out.write("" + list.size());
        out.write("</count>");
        out.write("<mode>");
        out.write(mode);
        out.write("</mode>");
        for (Tag tag : list) {
            out.write("<tag>");
            out.write("<id>");
            out.write("" + tag.getId());
            out.write("</id>");
            out.write("<lat>");
            out.write(Double.toString(tag.getLat()));
            out.write("</lat>");
            out.write("<lon>");
            out.write(Double.toString(tag.getLon()));
            out.write("</lon>");
            out.write("<name>");
            out.write(StringEscapeUtils.escapeXml(tag.getName()));
            out.write("</name>");
            if (tag.getKeyImage() != null) {
                out.write("<image-id>");
                out.write("" + tag.getKeyImage().getId());
                out.write("</image-id>");
            }
            if (tag.getKeyThumbnail() != null) {
                out.write("<thumbnail-id>");
                out.write("" + tag.getKeyThumbnail().getId());
                out.write("</thumbnail-id>");
            }
            out.write("<date>");
            out.write(tag.getFormatedDate(req.getLocale()));
            out.write("</date>");
            out.write("<date-value>");
            out.write("" + tag.getDate());
            out.write("</date-value>");
            out.write("<date-update>");
            out.write("" + tag.getDateUpdate());
            out.write("</date-update>");
            out.write("<rating>");
            out.write(tag.getRating());
            out.write("</rating>");
            out.write("<rating-value>");
            out.write("" + (int) ((float) tag.getRatingSum() * 100 / (float) tag.getRatingCount()));
            out.write("</rating-value>");
            out.write("<rating-count>");
            out.write("" + tag.getRatingCount());
            out.write("</rating-count>");
            out.write("</tag>");
        }
        out.write("</tags>");
        out.close();
    }
