    public Object query(Object o, Date ts) throws Exception {
        Root root = (Root) o;
        if (root.classrooms.size() > 0) {
            List<String> list = new ArrayList<String>();
            for (Classroom item : root.classrooms) {
                list.add(item.channel);
            }
            return list;
        } else {
            return null;
        }
    }
