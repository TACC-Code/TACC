    public void testFeedGenerator() throws RSSException {
        RSSItem item = new RSSItem();
        item.setTitle(("Test item 5"));
        item.setLink(("Http://www.test.be"));
        item.setDescription(("test desc 2"));
        RSSChannel channel = new RSSChannel();
        channel.setDescription("2 D�VELOPPEUR .NET bij Euremis in Waals-Brabant");
        channel.setLink(("test link 8"));
        channel.setTitle(("test title 5"));
        channel.setCopyright(("JCS INT."));
        channel.setManagingEditor(("JCS INT."));
        channel.setWebMaster(("JCS INT."));
        RSSImage image = new RSSImage();
        image.setTitle("Test Image");
        image.setLink("http://www.junit.org");
        image.setUrl("http://www.google.be/images/hp0.gif");
        channel.setRSSImage(image);
        RssFeedGenerator generator = new RssFeedGenerator();
        generator.setChannel(channel);
        generator.addItem(item);
        generator.addItem(item);
        LOG.info("Debug: Generator properties are set");
        LOG.info("test");
        LOG.error("test");
        Writer writer = null;
        try {
            File file = new File("build/test2.rss");
            LOG.info("Debug: Writing to: " + file.getAbsolutePath());
            writer = new OutputStreamWriter(new FileOutputStream(file), Charset.forName("UTF-8"));
            generator.parseToRSS(writer);
            LOG.info("Debug: Written:" + writer.toString());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        RSSHandler handler = new RSSHandler();
        LOG.info("Debug: Trying parse");
        RSSParser.parseXmlFile("build/test2.rss", handler, false);
        LOG.info("Debug: Parse done");
        LOG.info("Debug: Getting channel");
        RSSChannel channelback = handler.getRSSChannel();
        assertEquals(channelback.getCopyright(), channel.getCopyright());
        assertEquals(channelback.getDescription(), channel.getDescription());
        LOG.debug(channelback.getLink());
        List items = channelback.getItems();
        RSSItem itemback = (RSSItem) items.get(0);
        assertNotNull(itemback);
        assertEquals(item.getLink(), itemback.getLink());
    }
