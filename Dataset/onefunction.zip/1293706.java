    public List<String> getTestClassNames(String className, String classPath) throws ClassNotFoundException {
        final ClassLoader oldLoader = Thread.currentThread().getContextClassLoader();
        try {
            MutatingClassLoader jumbler = new MutatingClassLoader(className, new Mutater(-1), classPath);
            Thread.currentThread().setContextClassLoader(jumbler);
            Class<?> clazz = jumbler.loadClass(className);
            TestClass testClass = clazz.getAnnotation(TestClass.class);
            List<String> testClassNames = new ArrayList<String>();
            if (testClass != null) {
                String[] testClasses = testClass.value();
                for (String testClassName : testClasses) {
                    testClassNames.add(testClassName);
                }
            }
            return testClassNames;
        } finally {
            Thread.currentThread().setContextClassLoader(oldLoader);
        }
    }
