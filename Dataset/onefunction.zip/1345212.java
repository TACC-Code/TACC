    public static void main(String[] args) {
        try {
            DfpServiceLogger.log();
            DfpUser user = new DfpUser();
            PublisherQueryLanguageServiceInterface pqlService = user.getService(DfpService.V201108.PUBLISHER_QUERY_LANGUAGE_SERVICE);
            StatementBuilder statementBuilder = new StatementBuilder("SELECT * FROM Bandwidth_Group");
            ResultSet resultSet = pqlService.select(statementBuilder.toStatement());
            System.out.println(PqlUtils.resultSetToString(resultSet));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
