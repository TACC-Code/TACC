    public RegistrationStatus checkRegister(RegistrationInfo registerInfo) {
        try {
            String login = registerInfo.getLogin();
            String password = registerInfo.getPassword();
            String passwordconfirm = registerInfo.getPasswordconfirm();
            String email = registerInfo.getEmail();
            if (!login.equals("") && !password.equals("") && !passwordconfirm.equals("") && !email.equals("")) {
                if (password.equals(passwordconfirm)) {
                    if (email.contains("@") && email.contains(".")) {
                        Class.forName("com.mysql.jdbc.Driver").newInstance();
                        String url = "jdbc:mysql://localhost:3306";
                        String db_user = "root";
                        String db_password = null;
                        Connection connection = DriverManager.getConnection(url, db_user, db_password);
                        System.out.println("Connected !");
                        String query1 = "SELECT * FROM a296665_audictiv.MEMBER WHERE CLOGIN='" + login + "'";
                        Statement stmt1 = connection.createStatement();
                        ResultSet result1 = stmt1.executeQuery(query1);
                        if (!result1.next()) {
                            String query2 = "INSERT INTO a296665_audictiv.MEMBER" + "(" + "CID, " + "CLOGIN, " + "CPASSWORD, " + "CEMAIL, " + "CSUBSCRIPTIONDATE" + ") " + "VALUES " + "(" + "NULL,  '" + login + "', " + "MD5('" + password + "'), '" + email + "', " + "CURDATE()" + ")";
                            System.out.println(query2);
                            Statement stmt2 = connection.createStatement();
                            stmt2.executeUpdate(query2);
                            return RegistrationStatus.REGISTRATION_SUCCESSFUL;
                        } else return RegistrationStatus.USER_EXISTS;
                    } else return RegistrationStatus.INVALID_EMAIL;
                } else return RegistrationStatus.WRONG_PASSWORD;
            } else return RegistrationStatus.EMPTY_FIELDS;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return RegistrationStatus.REGISTRATION_FAILED;
    }
