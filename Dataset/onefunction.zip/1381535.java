    public void process(JCas aJCas) {
        String docText = aJCas.getDocumentText();
        Matcher ontologyMatcher = ontologyPattern.matcher(docText);
        while (ontologyMatcher.find()) {
            MedlineField annotation = new MedlineField(aJCas);
            annotation.setBegin(ontologyMatcher.start());
            annotation.setEnd(ontologyMatcher.end());
            annotation.setName(ontologyMatcher.group(1));
            annotation.setText(ontologyMatcher.group(2));
            annotation.addToIndexes();
        }
        Matcher matcher = uiPattern.matcher(docText);
        while (matcher.find()) {
            MedlineField annotation = new MedlineField(aJCas);
            annotation.setBegin(matcher.start());
            annotation.setEnd(matcher.end());
            annotation.setName(matcher.group(1));
            annotation.setText(matcher.group(2));
            annotation.addToIndexes();
        }
        Matcher matcher2 = abPattern.matcher(docText);
        while (matcher2.find()) {
            MedlineField annotation = new MedlineField(aJCas);
            annotation.setBegin(matcher2.start());
            annotation.setEnd(matcher2.end());
            annotation.setName(matcher2.group(1));
            annotation.setText(matcher2.group(2));
            annotation.addToIndexes();
        }
        Matcher matcher3 = tiPattern.matcher(docText);
        while (matcher3.find()) {
            MedlineField annotation = new MedlineField(aJCas);
            annotation.setBegin(matcher3.start());
            annotation.setEnd(matcher3.end());
            annotation.setName(matcher3.group(1));
            annotation.setText(matcher3.group(2));
            annotation.addToIndexes();
        }
        Matcher matcher4 = mhPattern.matcher(docText);
        while (matcher4.find()) {
            MedlineField annotation = new MedlineField(aJCas);
            annotation.setBegin(matcher4.start());
            annotation.setEnd(matcher4.end());
            annotation.setName(matcher4.group(1));
            annotation.setText(matcher4.group(2));
            annotation.addToIndexes();
        }
    }
