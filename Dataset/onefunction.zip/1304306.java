    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        LoginCheck registered = new LoginCheck();
        if (registered.check(request) == 0) return mapping.findForward("failed");
        AgentForm agentForm = (AgentForm) form;
        try {
            byte[] fileData = agentForm.getFile().getFileData();
            InputStream stream = new ByteArrayInputStream(fileData);
            SAXReader reader = new SAXReader();
            Document xmlAgent = reader.read(stream);
            stream.close();
            Element root = xmlAgent.getRootElement();
            String strNumber = root.element("number").getStringValue();
            Integer number = Integer.valueOf(strNumber);
            agentForm.setNumber(number);
            String strAlpha = root.element("alpha").getStringValue();
            Float alpha = Float.valueOf(strAlpha);
            agentForm.setAlpha(alpha);
            String strMrc = root.element("mrc").getStringValue();
            Float mrc = Float.valueOf(strMrc);
            agentForm.setMrc(mrc);
            String strCapital = root.element("capital").getStringValue();
            Float capital = Float.valueOf(strCapital);
            agentForm.setCapital(capital);
        } catch (FileNotFoundException notFound) {
            return mapping.findForward("loadAgents");
        } catch (IOException io) {
            return mapping.findForward("loadAgents");
        } catch (DocumentException docException) {
            return mapping.findForward("loadAgents");
        } catch (NullPointerException nullPointer) {
            return mapping.findForward("loadAgents");
        }
        return mapping.findForward("createAgents");
    }
