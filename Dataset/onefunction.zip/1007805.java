    public Theme[] selectCentralTwitts(List<Integer> twittIdsOfPeak, SelectRanges rangeSelector, String query, int themesAtMost, int maxNumberofTwittsInTheme) throws TexterraException, IOException, ParseException {
        final Twitt central = FastStreamingHistohram.getCentralTwitt(twittIdsOfPeak, rangeSelector, null, query);
        if (null == central) {
            return new Theme[0];
        } else {
            Theme result[] = new Theme[1];
            final int size = (maxNumberofTwittsInTheme > 0) ? Math.min(maxNumberofTwittsInTheme, twittIdsOfPeak.size()) : twittIdsOfPeak.size();
            Twitt members[] = new Twitt[size];
            for (int i = size - 1; i >= 0; --i) {
                members[i] = rangeSelector.getTwittById(twittIdsOfPeak.get(i));
            }
            result[0] = new Theme(central, members, twittIdsOfPeak.size());
            return result;
        }
    }
