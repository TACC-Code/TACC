    public Repository get() throws RepositoryException {
        Repository repository = new SailRepository(new MemoryStore());
        repository.initialize();
        final String context = "http://cll.niimm.ksu.ru/mocassinfortest";
        RepositoryConnection connection = repository.getConnection();
        try {
            InputStream inputStream = BootstrappedInMemoryRepositoryProvider.class.getClassLoader().getResourceAsStream("bootstrapdata.rdf");
            try {
                connection.add(inputStream, context, RDFFormat.RDFXML, repository.getValueFactory().createURI(context));
            } finally {
                inputStream.close();
            }
        } catch (Exception ex) {
            logger.error("Failed to load the bootstrap data", ex);
            throw new RuntimeException(ex);
        } finally {
            connection.close();
        }
        logger.debug("The bootstrap data have been loaded successfully.");
        return repository;
    }
