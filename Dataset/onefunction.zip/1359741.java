    public RuleAlcohols() {
        super();
        try {
            super.initSingleSMARTS(super.smartsPatterns, "1", "[#6][OX2H]");
            super.setExplanation("Checks for hydroxyl functional group. " + "Alcohols are associated with easy biodegradability.");
            id = "27";
            title = "Alcohols";
            examples[0] = "CC1OC1CC";
            examples[1] = "CCCCO";
            editable = false;
        } catch (SMARTSException x) {
            logger.error(x);
        }
    }
