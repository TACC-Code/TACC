    public void testReferenceData() throws Exception {
        MapAppendingReferenceDataProvider provider = new MapAppendingReferenceDataProvider();
        HashMap<Object, Object> map = new HashMap<Object, Object>();
        map.put(test1, test1);
        map.put(test2, test2);
        map.put(clazz, test3);
        provider.setReferenceData(map);
        HashMap referenceData = new HashMap();
        provider.provideReferences(null, null, referenceData, null);
        assertEquals(test1, referenceData.get(test1));
        assertEquals(test2, referenceData.get(test2));
        assertEquals(test3, referenceData.get(clazz));
    }
