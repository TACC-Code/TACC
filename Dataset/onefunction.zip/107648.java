    public Boolean accept(String path) {
        assert path != null;
        if (path.length() == 0 || path.equals("/")) {
            return true;
        }
        int lastSlash = path.lastIndexOf('/');
        int lastDot = path.lastIndexOf('.');
        return lastSlash > lastDot;
    }
