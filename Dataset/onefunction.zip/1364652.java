    public ColumnsPanel(PropertiesWindow p) throws ALMException {
        setSize(new Dimension(400, 200));
        properties = p;
        alm = new ALMLayout();
        setLayout(alm);
        XTab x1 = alm.addXTab();
        Area columnSelectionLabelArea = alm.addArea(alm.getLeft(), alm.getTop(), x1, alm.getBottom(), properties.columnSelectionLabel);
        Area columnBoxArea = alm.addArea(x1, alm.getTop(), alm.getRight(), alm.getBottom(), properties.columnBox);
        alm.addConstraint(2.0, x1, -1.0, alm.getRight(), OperatorType.EQ, 0.0);
    }
