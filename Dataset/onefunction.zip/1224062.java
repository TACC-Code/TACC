    public static void write(HttpServletResponse res, CacheResponseData data) throws IOException {
        Map headers = data.getHeaders();
        Iterator itr = headers.keySet().iterator();
        while (itr.hasNext()) {
            String headerKey = (String) itr.next();
            List headerValues = (List) headers.get(headerKey);
            for (int i = 0; i < headerValues.size(); i++) {
                Header header = (Header) headerValues.get(i);
                int type = header.getType();
                if (type == Header.DATE_TYPE) {
                    res.addDateHeader(headerKey, header.getDateValue());
                } else if (type == Header.INTEGER_TYPE) {
                    res.addIntHeader(headerKey, header.getIntValue());
                } else if (type == Header.STRING_TYPE) {
                    res.addHeader(headerKey, header.getStringValue());
                }
            }
        }
        res.setContentType(data.getContentType());
        ServletResponseUtil.write(res, data.getData());
    }
