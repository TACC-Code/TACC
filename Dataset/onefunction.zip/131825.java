    public static void drawBorder(byte[] data, byte[] pixels) {
        color = (byte) (data[0] & 0x0F);
        Arrays.fill(pixels, 0, 12 * WIDTH, color);
        Arrays.fill(pixels, 204 * WIDTH, (204 * WIDTH) + (12 * WIDTH), color);
        for (int i = 12; i < 204; i++) {
            Arrays.fill(pixels, i * WIDTH, (i * WIDTH) + 6, color);
            Arrays.fill(pixels, i * WIDTH + 294, ((i * WIDTH) + 294) + 6, color);
        }
    }
