    public GfrChooserFile(File fleCurrentDir, String strChooserTitle, String strTypeFile, String strExtension) {
        super();
        super.setCurrentDirectory(fleCurrentDir);
        super.setDialogTitle(strChooserTitle);
        super.setFileSelectionMode(JFileChooser.FILES_ONLY);
        super.setFileFilter(new FileNameExtensionFilter(strTypeFile + " (." + strExtension + ")", strExtension));
        try {
            String strPathAbsLastDir = PrpMgrPrivatePropertiesUser.s_getPathAbsLastParentFolder();
            if (strPathAbsLastDir != null) {
                this.setCurrentDirectory(new File(strPathAbsLastDir));
            }
        } catch (Exception exc) {
            exc.printStackTrace();
            String str = exc.getMessage();
            GfrChooserFile._LOGGER_.severe(str);
            GfrOptionPaneAbs.s_showDialogError(null, str);
            System.exit(1);
        }
    }
