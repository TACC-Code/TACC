    public ValueScanner(TokenManager tokenManager) {
        IToken defaultToken = tokenManager.getToken(Log4jPlugin.PREF_DEFAULT_COLOR);
        IToken formatToken = tokenManager.getToken(Log4jPlugin.PREF_FORMAT_COLOR);
        IToken keywordToken = tokenManager.getToken(Log4jPlugin.PREF_KEYWORD_COLOR);
        IRule braceRule = new SingleLineRule("{", "}", formatToken, (char) 0, true);
        WordRule keywordRule = new WordRule(new WordDetector());
        for (int i = 0; i < keywords.length; i++) {
            keywordRule.addWord(keywords[i], keywordToken);
        }
        IRule formatRule = new FormatRule(formatToken);
        IRule whitespaceRule = new WhitespaceRule(new WhitespaceDetector());
        setDefaultReturnToken(defaultToken);
        setRules(new IRule[] { braceRule, formatRule, keywordRule, whitespaceRule });
    }
