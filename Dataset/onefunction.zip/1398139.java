    public static TypeReference makeTypeReference(ClassLoaderReference loader, String type) throws IllegalArgumentException {
        if (type == null) {
            throw new IllegalArgumentException("null type");
        }
        TypeReference p = primitiveMap.get(type);
        if (p != null) {
            return p;
        }
        ImmutableByteArray b = ImmutableByteArray.make(type);
        TypeName T = null;
        if (b.get(b.length() - 1) == ';') {
            T = TypeName.findOrCreate(b, 0, b.length() - 1);
        } else {
            T = TypeName.findOrCreate(b);
        }
        return TypeReference.findOrCreate(loader, T);
    }
