    public static PsiElement createElement(ASTNode node) {
        IElementType elem = node.getElementType();
        if (elem instanceof CQLElementType.PsiCreator) {
            return ((CQLElementType.PsiCreator) elem).createPsi(node);
        }
        if (elem.equals(STATEMENT)) return new CQLStatementImpl(node);
        if (elem.equals(INPUT_STREAM)) return new CQLInputStreamDefinitionImpl(node);
        if (elem.equals(INTERMEDIATE_STREAM)) return new CQLIntermediateStreamDefinitionImpl(node);
        if (elem.equals(OUTPUT_STREAM)) return new CQLOutputStreamDefinitionImpl(node);
        if (elem.equals(IDENTIFIER)) return new CQLIdentifierImpl(node);
        if (LITERAL.contains(elem)) return new CQLLiteralImpl(node);
        if (elem.equals(FIELD_ACCESS_EXPRESSION)) return new CQLFieldAccessImpl(node);
        if (elem.equals(LOGICAL_OR_EXPRESSION)) return new CQLLogicalOrExpressionImpl(node);
        if (elem.equals(LOGICAL_AND_EXPRESSION)) return new CQLLogicalAndExpressionImpl(node);
        if (elem.equals(EQUALITY_EXPRESSION)) return new CQLEqualityExpressionImpl(node);
        if (elem.equals(RELATIONAL_EXPRESSION)) return new CQLRelationalExpressionImpl(node);
        if (elem.equals(BINARY_ARITHMETIC_EXPRESSION)) return new CQLBinaryArithmeticExpressionImpl(node);
        if (elem.equals(UNARY_ARITHMETIC_EXPRESSION)) return new CQLUnaryArithmeticExpressionImpl(node);
        if (elem.equals(UNARY_LOGICAL_EXPRESSION)) return new CQLUnaryLogicalExpressionImpl(node);
        if (elem.equals(PARENTHESIZED_EXPRESSION)) return new CQLParenthesizedExpressionImpl(node);
        if (elem.equals(WHERE_KEYWORD)) return new CQLWhereConditionImpl(node);
        if (elem.equals(LABELED_EXPRESSION)) return new CQLLabeledExpressionImpl(node);
        if (elem.equals(SELECT_KEYWORD)) return new CQLSelectImpl(node);
        if (elem.equals(RANGE_VAR)) return new CQLRangeVarImpl(node);
        if (elem.equals(PROJECTION_ATTRIBUTE)) return new CQLLabeledExpressionImpl(node);
        return new ASTWrapperPsiElement(node);
    }
