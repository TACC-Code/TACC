    public int setPlayerActionQueueLimit(long loginId, int instanceId, int limit) throws GwtErrorCodeException {
        SetPlayerActionQueueLimit command = new SetPlayerActionQueueLimit(loginId, instanceId, limit);
        ICommandExecutorService service = getDependency(ICommandExecutorService.class);
        IExecutableCommandResponse<Integer> response = service.execute(command);
        if (response.hasErrors()) {
            throw new GwtErrorCodeException(response);
        }
        return response.getReturnValue();
    }
