    public void process(WebBeanContext webBeanContext, String targetExpresssion) throws WebBeanException {
        WebBean webBean = webBeanContext.getWebBean();
        ServletContext context = webBeanContext.getApplication();
        HttpServletRequest request = webBeanContext.getRequest();
        HttpServletResponse response = webBeanContext.getResponse();
        String targetUri = new StringBuffer().append(webBean.getName()).append(targetExpresssion).append(".jsp").toString();
        if (WebUtils.isGet(request)) {
            forward(context, request, response, targetUri);
        } else {
            sendRedirect(response, targetUri);
        }
    }
