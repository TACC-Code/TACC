    public List<Element> start(WorkerContext ctx, Tag tag) {
        float height = 0;
        float width = 0;
        Rectangle r = null;
        String viewbox = "";
        Map<String, String> attributes = tag.getAttributes();
        if (attributes != null) {
            try {
                height = Float.parseFloat(attributes.get("height"));
            } catch (Exception exp) {
            }
            try {
                width = Float.parseFloat(attributes.get("width"));
            } catch (Exception exp) {
            }
            try {
                viewbox = attributes.get("viewBox");
                r = new Rectangle(0, 0);
                StringTokenizer st = new StringTokenizer(viewbox);
                if (st.hasMoreTokens()) r.setRight(Float.parseFloat(st.nextToken()));
                if (st.hasMoreTokens()) r.setBottom(-Float.parseFloat(st.nextToken()));
                if (st.hasMoreTokens()) r.setLeft(r.getRight() + Float.parseFloat(st.nextToken()));
                if (st.hasMoreTokens()) r.setTop(r.getBottom() + Float.parseFloat(st.nextToken()));
                r.normalize();
            } catch (Exception exp) {
            }
        }
        if (r == null) {
            r = new Rectangle(width, height);
        } else if (width == 0 && height == 0) {
            width = r.getWidth();
            height = r.getHeight();
        }
        List<Element> elems = new ArrayList<Element>();
        elems.add(new Svg(height, width, r, tag.getCSS()));
        return elems;
    }
