    public void execute() throws MojoExecutionException, MojoFailureException {
        getLog().info("Installing artifact to local repository");
        if (outputDirectory == null) {
            try {
                outputDirectory = new File(project.getBuild().getDirectory());
                outputDirectory.mkdirs();
            } catch (Exception e) {
                throw new MojoExecutionException("Failed to create outputDirectory", e);
            }
        }
        try {
            installer.install(getFile(), getArtifact(), localRepository);
        } catch (ArtifactInstallationException e) {
            throw new MojoExecutionException("Unable to install artifact.", e);
        }
    }
