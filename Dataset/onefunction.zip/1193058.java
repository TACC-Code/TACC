    public static HTMLOptionSet getOptionSet(String locale, String selectedVoteName) {
        List<SelectableItem> itemList = new ArrayList<SelectableItem>();
        if (selectedVoteName == null) {
            selectedVoteName = "";
        }
        OCEService service = ServiceLocator.getOCEService();
        List<VoteDefinition> votesDefinition = service.getVoteDefinitionProvider().getVoteDefinitions();
        if (votesDefinition != null) {
            Iterator<VoteDefinition> iterator = votesDefinition.iterator();
            while (iterator.hasNext()) {
                VoteDefinition nextVoteDefinition = (VoteDefinition) iterator.next();
                String value = String.valueOf(nextVoteDefinition.getVoteValue());
                String displayName = nextVoteDefinition.getDisplayName(locale);
                SelectableItem nextItem = new SelectableItem(value, displayName);
                itemList.add(nextItem);
            }
        }
        HTMLOptionSet optionSet = new HTMLOptionSet();
        optionSet.setItemList(itemList);
        optionSet.setSelectedItemValue(selectedVoteName);
        return optionSet;
    }
