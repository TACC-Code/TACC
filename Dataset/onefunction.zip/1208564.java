    public static void main(String[] args) {
        List<Human> hum = new ArrayList<Human>();
        hum.add(new Teacher("Denis", "Marushko", "man", 10));
        hum.add(new Curator("Vana", "Sovenok", "man", 50, null, 10));
        hum.add(new Students("Stas", "Glushen", "man", 5, "p1"));
        hum.add(new Director("Dima", "Goriacko", "man", 100, 60));
        hum.add(new Starosta("Andry", "Tihomirov", "man", 60, 30));
        for (int i = 0; i < hum.size(); i++) {
            Human h = hum.get(i);
            System.out.println(h.getName() + " " + h.getSurName() + " " + h.getSex() + " " + h.getDiscription());
        }
    }
