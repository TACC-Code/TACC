    public void doRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        TBaseDatabase db = getDataBase("BestelDB");
        TBaseRecordset rs = db.Query("SELECT naam, sum(number) as totaal FROM cart, artikel where cart.articlenumber = artikel.artikelnummer group by naam order by totaal desc limit 0 , 10;");
        parsePart("begin");
        while (rs.Fetch()) {
            Hashtable<String, String> fields = new Hashtable<String, String>();
            fields.put("omschrijving", rs.getValue("naam").toString());
            setFields(fields);
            parsePart("item");
        }
        parsePart("end");
    }
