    public void close() throws IOException {
        super.close();
        byte[] data = super.toByteArray();
        HttpSession httpSession = HttpSessionTemporaryDataStorage.getHttpSession();
        DocumentRepository documentRepository = new DocumentRepository(httpSession);
        documentRepository.setSignedDocument(data);
        documentRepository.setSignatureStatus(SignatureStatus.OK);
    }
