    public void testNumericValuesWithUnits() {
        XmlCollectionAttribute a = new XmlCollectionAttribute(null, null, "test", "4.6");
        Assert.assertEquals("4.6", a.getNumericValue());
        Assert.assertEquals("4.6", a.getStringValue());
        a = new XmlCollectionAttribute(null, null, "test", "4.6%");
        Assert.assertEquals("4.6", a.getNumericValue());
        Assert.assertEquals("4.6%", a.getStringValue());
        a = new XmlCollectionAttribute(null, null, "test", "4.6Bps");
        Assert.assertEquals("4.6", a.getNumericValue());
        Assert.assertEquals("4.6Bps", a.getStringValue());
        a = new XmlCollectionAttribute(null, null, "test", "4.6 bps");
        Assert.assertEquals("4.6", a.getNumericValue());
        Assert.assertEquals("4.6 bps", a.getStringValue());
        a = new XmlCollectionAttribute(null, null, "test", "-42");
        Assert.assertEquals("-42.0", a.getNumericValue());
        Assert.assertEquals("-42", a.getStringValue());
        a = new XmlCollectionAttribute(null, null, "test", "-32 celcius");
        Assert.assertEquals("-32.0", a.getNumericValue());
        Assert.assertEquals("-32 celcius", a.getStringValue());
        a = new XmlCollectionAttribute(null, null, "test", "4.2E2");
        Assert.assertEquals("420.0", a.getNumericValue());
        Assert.assertEquals("4.2E2", a.getStringValue());
        a = new XmlCollectionAttribute(null, null, "test", "-4e-2");
        Assert.assertEquals("-0.04", a.getNumericValue());
        Assert.assertEquals("-4e-2", a.getStringValue());
    }
