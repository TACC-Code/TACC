    public static void main(String[] args) {
        Vars.fileSeparator = System.getProperty("file.separator");
        Indexer indexer;
        Vars.server_thread_status = true;
        try {
            Lector_Ini.class.newInstance().configure();
            FTPThread FTPThreadLocal = new FTPThread();
            FTPThreadLocal.start();
            indexer = (Indexer) (Class.forName(Vars.IndexerToUse)).newInstance();
            indexer.startIndex();
            Timer InfoThreadTimer = new Timer();
            InfoThreadTimer.schedule(new InfoThread(), 0, 1000);
            JobDetail job = newJob(com.google.code.ftspc.lector.CheckDateForPath.class).withIdentity("jobForCheckDateForPath", "Lector").build();
            Trigger trigger = newTrigger().withIdentity("triggerForCheckDateForPath", "Lector").withSchedule(simpleSchedule().withIntervalInHours(1).repeatForever()).startNow().build();
            Vars.sched.scheduleJob(job, trigger);
        } catch (Exception ex) {
            ex.printStackTrace();
            Vars.logger.fatal("Error: ", ex);
            ex.printStackTrace();
        }
    }
