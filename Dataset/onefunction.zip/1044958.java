    public static void main(String[] args) throws IllegalArgumentException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, ApplicationException, RemoteException, MalformedURIException {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring-axis-context.xml");
        SmsNotificationPort smsNotificationPort = (SmsNotificationPort) ctx.getBean("parlaySmsNotificationPortClient_v1_0");
        ParlaySmsNotificationClient_v1_0 notificationClient = new ParlaySmsNotificationClient_v1_0(smsNotificationPort, null, null, "http://localhost:8080/CGateway/services/SmsNotificationPort");
        for (int i = 0; i < 1; i++) {
            notificationClient.notifySmsReception("VIP_401011", "401011BA", ParlayXConverter.string2EndUserIdentifier("385915614507"), "test " + i);
        }
    }
