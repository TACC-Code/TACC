    public static void main(String[] args) {
        try {
            Publication epub = new Publication();
            epub.addDCMetadata("title", "My First EPUB");
            epub.addDCMetadata("creator", System.getProperty("user.name"));
            epub.addDCMetadata("language", "en");
            NCXResource toc = epub.getTOC();
            TOCEntry rootTOCEntry = toc.getRootTOCEntry();
            OPSResource main = epub.createOPSResource("OPS/main.html");
            epub.addToSpine(main);
            OPSDocument mainDoc = main.getDocument();
            TOCEntry mainTOCEntry = toc.createTOCEntry("Intro", mainDoc.getRootXRef());
            rootTOCEntry.add(mainTOCEntry);
            Element body = mainDoc.getBody();
            Element h1 = mainDoc.createElement("h1");
            h1.add("My First EPUB");
            body.add(h1);
            Element paragraph = mainDoc.createElement("p");
            paragraph.add("Hello, world!");
            body.add(paragraph);
            OCFContainerWriter writer = new OCFContainerWriter(new FileOutputStream("hello.epub"));
            epub.serialize(writer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
