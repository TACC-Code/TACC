    public void testSelectMixed() {
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT ");
        sql.append(Fields.NAME);
        sql.append(", ");
        sql.append(Fields.LASTNAME);
        sql.append(", ");
        sql.append(Fields.BIRTHDAY);
        sql.append(", ");
        sql.append(Fields.HEIGHT);
        sql.append("FROM ");
        sql.append(Fields.TABLE);
        sql.append(" WHERE ");
        sql.append(Fields.NAME);
        sql.append(" = '");
        sql.append("Andrea");
        sql.append("' AND (");
        sql.append(new And().add(new SQLConditions.Lt(new SQLField(Fields.BIRTHDAY), new Date())).add(new SQLConditions.Gt(new SQLField(Fields.HEIGHT), new Double(1.0))).toSQL());
        sql.append(") ");
        sql.append(new SQLClauses.OrderBy(new SQLField(Fields.LASTNAME), SQLClauses.OrderBy.ASCENDING).toSQL());
    }
