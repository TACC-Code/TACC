    public void handle(PacketContext context) throws GGException {
        if (logger.isDebugEnabled()) {
            logger.debug("NotifyPacketReply received.");
            logger.debug("PacketHeader: " + context.getHeader());
            logger.debug("PacketBody: " + GGUtils.prettyBytesToString(context.getPackageContent()));
        }
        GGNotifyReply notifyReply = new GGNotifyReply(context.getPackageContent());
        context.getSessionAccessor().notifyGGPacketReceived(notifyReply);
        Map usersStatuses = notifyReply.getUsersStatus();
        for (Iterator it = usersStatuses.keySet().iterator(); it.hasNext(); ) {
            IUser user = (IUser) it.next();
            IRemoteStatus status = (IRemoteStatus) usersStatuses.get(user);
            context.getSessionAccessor().notifyUserChangedStatus(user, status);
        }
    }
