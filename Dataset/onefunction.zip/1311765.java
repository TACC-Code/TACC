    public void processValidators(FacesContext context) {
        S2Container container = SingletonS2ContainerFactory.getContainer();
        JsfValidationHelper validationHelper = (JsfValidationHelper) container.getComponent(JsfValidationHelper.class);
        validationHelper.applyValidators(context);
        super.processValidators(context);
    }
