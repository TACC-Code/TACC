    public void allPosibilities() {
        String fileName = "testFile.xy";
        String path1 = "/path/";
        String path2 = "/path";
        String outerPath3 = "D:\\path";
        String outerPath4 = "D:\\path\\";
        String resultInner = path1 + fileName;
        String resultOuter = outerPath4 + fileName;
        Assert.assertEquals(resultInner, new PathFormatter().getValidPath(path1, fileName));
        Assert.assertEquals(resultInner, new PathFormatter().getValidPath(path2, fileName));
        Assert.assertEquals(resultOuter, new PathFormatter().getValidPath(outerPath3, fileName));
        Assert.assertEquals(resultOuter, new PathFormatter().getValidPath(outerPath4, fileName));
    }
