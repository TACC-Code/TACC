    public void windowStateChanged(WindowEvent e) {
        if (e.getNewState() == 0) {
            ((MainWindowCode) e.getSource()).jpnGraphics.repaint();
            ((MainWindowCode) e.getSource()).ReloadGraphics();
        }
    }
