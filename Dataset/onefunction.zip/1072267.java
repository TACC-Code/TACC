    public static Border fromString(String s) throws SerialException {
        String values[] = s.split(" ");
        Extent extent = ExtentPeer.fromString(values[0]);
        int style = Border.STYLE_NONE;
        if (!STYLE_TEXT_TO_CONSTANT.containsKey(values[1])) {
            throw new IllegalArgumentException("Invalid border style: " + values[1]);
        } else {
            style = STYLE_TEXT_TO_CONSTANT.get(values[1]);
        }
        Color color = ColorPeer.fromString(values[2]);
        return new Border(extent, color, style);
    }
