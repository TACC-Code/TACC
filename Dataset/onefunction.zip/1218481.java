    public static int newConstructorForSerialization__Ljava_lang_Class_2Ljava_lang_reflect_Constructor_2__Ljava_lang_reflect_Constructor_2(MJIEnv env, int objRef, int clsRef, int ctorRef) {
        int sCtorRef = env.newObject("gov.nasa.jpf.SerializationConstructor");
        env.setReferenceField(sCtorRef, "mdc", clsRef);
        env.setReferenceField(sCtorRef, "firstNonSerializableCtor", ctorRef);
        return sCtorRef;
    }
