    public AbstractMultiDatasetResourceModel() {
        super();
        setClassAuthor("AKKA Technologies");
        setClassOwner("CNES");
        setClassVersion("0.1");
        setName("AbstractMultiDatasetResourceModel");
        setDescription("Abstract Resource model for Multidataset service");
        ResourceParameter dictionary = new ResourceParameter("dictionary", "The id of the dictionary", ResourceParameterType.PARAMETER_INTERN);
        dictionary.setValueType("xs:string");
        ResourceParameter collection = new ResourceParameter("collection", "The id of the collection to use", ResourceParameterType.PARAMETER_USER_INPUT);
        collection.setValueType("xs:string");
        this.addParam(dictionary);
        this.addParam(collection);
        this.setApplicationClassName(ProjectApplication.class.getName());
    }
