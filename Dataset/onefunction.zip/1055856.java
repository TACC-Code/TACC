    public String execute() {
        if (getContact().getName() == null || "".equalsIgnoreCase(getContact().getName())) {
            addActionError("<font color='red'>Please input Contact name</font>");
        }
        if (hasErrors()) {
            setBusinesss(manager.findAllSorted(BusinessPartner.class, "name"));
            return INPUT;
        }
        if (getBusiness().getId() != null && !"".equalsIgnoreCase(getBusiness().getId())) {
            setBusiness((BusinessPartner) manager.getById(BusinessPartner.class, getBusiness().getId()));
        } else {
            setBusiness(null);
        }
        LogInformation log;
        if (getContact().getId() == null || "".equalsIgnoreCase(getContact().getId())) {
            log = new LogInformation();
            log.setCreateBy(sessionCredentials.getCurrentUser().getId());
            log.setCreateDate(new Timestamp(System.currentTimeMillis()));
            getContact().setId(null);
        } else {
            Contact temp = getContact();
            setContact((Contact) manager.getById(Contact.class, getContact().getId()));
            log = getContact().getLogInformation();
            try {
                PropertyUtils.copyProperties(getContact(), temp);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
        log.setLastUpdateBy(sessionCredentials.getCurrentUser().getId());
        log.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
        log.setActiveFlag(1);
        getContact().setLogInformation(log);
        getContact().setBusiness(getBusiness());
        manager.save(getContact());
        return SUCCESS;
    }
