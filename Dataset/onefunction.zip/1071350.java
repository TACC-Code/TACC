    public void canRead() {
        MobilityConfig mobilityConfig = jeiConfig.getMobilityConfig();
        mobilityConfig.getDesGroups().get(2).getDes();
        DesGroup desGroup = mobilityConfig.getDesGroups().get(2);
        assertEquals(20, desGroup.getLimit());
        assertEquals(16, desGroup.getDes().size());
    }
