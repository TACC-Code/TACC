    public ActionForward executeAction(AvatalActionMapping mapping, DynaValidatorForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String name = (String) form.get(FormConstants.GROUP_NAME);
        Integer state = (Integer) form.get(FormConstants.GROUP_STATE);
        if (state != null) {
            if (state.intValue() == 3) {
                state = null;
            }
        }
        addForNextPage(request, HttpSessionConstants.LAST_SEARCH_GROUP_NAME, name);
        addForNextPage(request, HttpSessionConstants.LAST_SEARCH_GROUP_STATE, state);
        GroupManagementDelegate delegate = new GroupManagementDelegate();
        GroupListViewAssembler viewAssembler = new GroupListViewAssembler();
        UserVo loggedUser = (UserVo) getSession(request).getAttribute(HttpSessionConstants.USER);
        List groups = delegate.getGroupsForAssign(loggedUser, name, state);
        viewAssembler.addGroups(groups, loggedUser.getLocale());
        GroupListView groupListView = viewAssembler.getGroupListView();
        addForNextPage(request, HttpSessionConstants.GROUP_GROUP_CONTAINER, groupListView);
        moveToNextPage(request, HttpSessionConstants.GROUP_AS_OBJECT);
        return mapping.findForward(Constants.SUCCESS_KEY);
    }
