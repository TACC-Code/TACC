    public String execute() {
        if (getSiteDescriptorAccess().getId() != null && !"".equalsIgnoreCase(getSiteDescriptorAccess().getId())) {
            setSiteDescriptorAccess((SiteDescriptorACLAccess) manager.getById(SiteDescriptorACLAccess.class, getSiteDescriptorAccess().getId()));
            manager.remove(getSiteDescriptorAccess());
        }
        return SUCCESS;
    }
