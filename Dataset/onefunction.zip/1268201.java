    public static OPT_Instruction makeMoveInstruction(OPT_RegisterOperand lhs, OPT_RegisterOperand rhs) {
        if (rhs.register.isInteger() || rhs.register.isLong() || rhs.register.isAddress()) {
            if (VM.VerifyAssertions) VM._assert(lhs.register.isInteger() || lhs.register.isLong() || lhs.register.isAddress());
            return MIR_Move.create(IA32_MOV, lhs, rhs);
        } else if (rhs.register.isFloatingPoint()) {
            if (VM.VerifyAssertions) VM._assert(lhs.register.isFloatingPoint());
            return MIR_Move.create(IA32_FMOV, lhs, rhs);
        } else {
            OPT_OptimizingCompilerException.TODO("OPT_PhysicalRegisterTools.makeMoveInstruction");
            return null;
        }
    }
