    public static ClassInfo getClassInfo(Class clazz) {
        if (classInfoCache.containsKey(clazz)) {
            return classInfoCache.get(clazz);
        } else {
            ClassInfo classInfo = new ClassInfo(clazz);
            classInfoCache.put(clazz, classInfo);
            return classInfo;
        }
    }
