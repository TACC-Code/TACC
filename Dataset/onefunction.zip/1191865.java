    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (request.isUserInRole(Authentication.DASHBOARD_ROLE)) {
            return new ModelAndView("redirect:/dashboard.jsp");
        } else {
            return new ModelAndView("redirect:/index.jsp");
        }
    }
