    public void process(PDFOperator operator, List arguments) throws IOException {
        PageDrawer drawer = (PageDrawer) context;
        PDPage page = drawer.getPage();
        Dimension pageSize = drawer.getPageSize();
        Graphics2D graphics = drawer.getGraphics();
        COSName objectName = (COSName) arguments.get(0);
        Map xobjects = drawer.getResources().getXObjects();
        PDXObject xobject = (PDXObject) xobjects.get(objectName.getName());
        if (xobject instanceof PDXObjectImage) {
            PDXObjectImage image = (PDXObjectImage) xobject;
            try {
                BufferedImage awtImage = image.getRGBImage();
                Matrix ctm = drawer.getGraphicsState().getCurrentTransformationMatrix();
                int width = awtImage.getWidth();
                int height = awtImage.getHeight();
                double rotationInRadians = (page.findRotation() * Math.PI) / 180;
                AffineTransform rotation = new AffineTransform();
                rotation.setToRotation(rotationInRadians);
                AffineTransform rotationInverse = rotation.createInverse();
                Matrix rotationInverseMatrix = new Matrix();
                rotationInverseMatrix.setFromAffineTransform(rotationInverse);
                Matrix rotationMatrix = new Matrix();
                rotationMatrix.setFromAffineTransform(rotation);
                Matrix unrotatedCTM = ctm.multiply(rotationInverseMatrix);
                Matrix scalingParams = unrotatedCTM.extractScaling();
                Matrix scalingMatrix = Matrix.getScaleInstance(1f / width, 1f / height);
                scalingParams = scalingParams.multiply(scalingMatrix);
                Matrix translationParams = unrotatedCTM.extractTranslating();
                Matrix translationMatrix = null;
                int pageRotation = page.findRotation();
                if (pageRotation == 0) {
                    translationParams.setValue(2, 1, -translationParams.getValue(2, 1));
                    translationMatrix = Matrix.getTranslatingInstance(0, (float) pageSize.getHeight() - height * scalingParams.getYScale());
                } else if (pageRotation == 90) {
                    translationMatrix = Matrix.getTranslatingInstance(0, (float) pageSize.getHeight());
                } else {
                }
                translationParams = translationParams.multiply(translationMatrix);
                AffineTransform at = new AffineTransform(scalingParams.getValue(0, 0), 0, 0, scalingParams.getValue(1, 1), translationParams.getValue(2, 0), translationParams.getValue(2, 1));
                graphics.drawImage(awtImage, at, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (xobject instanceof PDXObjectForm) {
            PDXObjectForm form = (PDXObjectForm) xobject;
            COSStream invoke = (COSStream) form.getCOSObject();
            PDResources pdResources = form.getResources();
            if (pdResources == null) {
                pdResources = page.findResources();
            }
            getContext().processSubStream(page, pdResources, invoke);
        } else {
        }
    }
