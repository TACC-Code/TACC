    protected void dispatchEvent(AWTEvent event) {
        try {
            super.dispatchEvent(event);
        } catch (RuntimeException e) {
            NotificationManager.addError(e);
        } catch (Error e) {
            NotificationManager.addError(Messages.getString("PluginServices.Error grave de la aplicaci�n.  \n Es conveniente que salgas de la aplicaci�n"), e);
        }
    }
