    public IAdaptable createElement(IMemento memento) {
        String url = memento.getString(TAG_URL);
        IBrowserEditorInput input = new BrowserEditorInput(url);
        Boolean persistBrowserURL = memento.getBoolean(TAG_PERSIST_BROWSER_URL);
        if (persistBrowserURL != null) {
            input.setPersistBrowserURL(persistBrowserURL);
        }
        return input;
    }
