    public static Map<String, String> load(final ResourceBundle resourceBundle) {
        final Map<String, String> resources = new HashMap<String, String>();
        if (resourceBundle != null) {
            final Enumeration<String> keys = resourceBundle.getKeys();
            String key = null;
            while (keys.hasMoreElements()) {
                key = keys.nextElement();
                final String value = resourceBundle.getString(key);
                resources.put(key, value);
            }
        }
        return resources;
    }
