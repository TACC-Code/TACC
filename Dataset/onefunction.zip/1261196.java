    protected Criteria createCriteria(SearchFilter<PenaltyPoint> filter) {
        Criteria criteria = getSession().createCriteria(PenaltyPoint.class);
        if (filter instanceof PenaltyPointFilter) {
            PenaltyPointFilter cf = (PenaltyPointFilter) filter;
            if (cf.getDateAfter() != null) {
                criteria.add(Restrictions.gt("given", cf.getDateAfter()));
            }
            if (cf.getUser() != null) {
                criteria.add(Restrictions.eq("user", cf.getUser()));
            }
        }
        return criteria;
    }
