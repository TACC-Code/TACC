    public SQLExpression getExpression(SQLExpression expr, List args) {
        if (args == null || args.size() != 2) {
            throw new NucleusUserException("Cannot invoke Spatial.geomCollFromText without 2 arguments");
        }
        SQLExpression wktExpr = (SQLExpression) args.get(0);
        SQLExpression sridExpr = (SQLExpression) args.get(1);
        ArrayList funcArgs = new ArrayList();
        funcArgs.add(wktExpr);
        funcArgs.add(sridExpr);
        return new GeometryExpression(stmt, null, "SDO_GEOMETRY", funcArgs, null);
    }
