    public static void main(String[] args) {
        try {
            if (args.length < 2) {
                System.out.println("Usage: java weibo4j.examples.OAuthUpdateTwo token tokenSecret");
                System.exit(-1);
            }
            System.setProperty("weibo4j.oauth.consumerKey", Weibo.CONSUMER_KEY);
            System.setProperty("weibo4j.oauth.consumerSecret", Weibo.CONSUMER_SECRET);
            Weibo weibo = new Weibo();
            weibo.setToken("e42f35bd66fce37d7c6dfeb6110d8957", "a1943b8ea10eb708e67825d25675d246");
            Status status = weibo.updateStatus("你好吗？");
            System.out.println("Successfully updated the status to [" + status.getText() + "].");
            System.exit(0);
        } catch (WeiboException te) {
            System.out.println("Failed to get timeline: " + te.getMessage());
            System.exit(-1);
        } catch (Exception ioe) {
            System.out.println("Failed to read the system input.");
            System.exit(-1);
        }
    }
