    public static String getIndefiniteArticle(String text) {
        char ch = text.charAt(0);
        if (ch == 'a' || ch == 'e' || ch == 'o' || ch == 'i' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'O' || ch == 'I' || ch == 'U') {
            return ARTICLE_AN;
        } else {
            return ARTICLE_A;
        }
    }
