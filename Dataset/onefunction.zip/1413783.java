    public String wrap(Object paramsObj, Map parameterMap, JPQLCause cause, StringBuffer sb, Map<String, Object> loopParamMap, Set aliasSet, int indent) {
        sb.setLength(0);
        sb.append(cause.getName().toUpperCase());
        boolean hasValue = false;
        int num = 0;
        for (JPQLElement element : cause.getElementList()) {
            if (meetCondition(paramsObj, loopParamMap, element)) {
                if (num == 0) {
                    sb.append(" ").append(element.getQueryString());
                } else {
                    sb.append(", ").append(element.getQueryString());
                }
                num++;
                hasValue = true;
            }
        }
        return hasValue ? sb.toString() : "";
    }
