    public void testInvaidWsdl() {
        try {
            String wsdluri = "test-resources/Invalid.wsdl";
            String args[] = new String[] { "-uri", wsdluri, "-o", "target/invalidwsdloutlocation" };
            new WSDL2Code().main(args);
            fail("This must fail with the excetion :" + "No element reference found for the part in fault message " + "InvalidIsbnFault. Fault message part should always be refer " + "to an element.");
        } catch (Exception e) {
            assertTrue(e.getCause().getMessage().startsWith("Part 'message' of fault message '{http://www.Monson-Haefel.com/jwsbook/BookQuote}InvalidIsbnFault'"));
        }
    }
