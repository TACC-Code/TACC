    public static void main(String args[]) throws Exception {
        log.debug("Initialize dependencies.");
        Injector injector = Guice.createInjector(new MockModule());
        EventListener listener = injector.getInstance(EventListener.class);
        ProducerStatePoller poller = injector.getInstance(ProducerStatePoller.class);
        log.debug("Start the endless loop.");
        while (true) {
            log.debug("Check for messages.");
            listener.checkMessages(MAX_MESSAGES);
            log.debug("Check for state changes.");
            poller.poll();
            log.debug("Retrieve the asset mappings.");
            AssetMap assetMap = injector.getInstance(AssetMap.class);
            if (assetMap.size() > 0) {
                log.debug("Save the asset mappings.");
                assetMap.save();
            }
            log.debug("sleeping for " + SLEEP_INTERVAL + " seconds.");
            Thread.sleep(SLEEP_INTERVAL * 1000);
        }
    }
