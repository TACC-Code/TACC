    public void testSetOperations() {
        MethodDescriptor md1 = new MethodDescriptor(1, "name1", "desc1", "sig1", new String[0]);
        MethodDescriptor md1clone = new MethodDescriptor(1, "name1", "desc1", "sig1", new String[0]);
        MethodDescriptor md2 = new MethodDescriptor(1, "name2", "desc2", "sig2", new String[] { "e1" });
        MethodDescriptor md2clone = new MethodDescriptor(1, "name2", "desc2", "sig2", new String[] { "e1" });
        Set<MethodDescriptor> set1 = new HashSet<MethodDescriptor>();
        set1.add(md1);
        set1.add(md2);
        Set<MethodDescriptor> set2 = new HashSet<MethodDescriptor>();
        set2.add(md1clone);
        set2.add(md2clone);
        set1.removeAll(set2);
        assertTrue(set1.isEmpty());
    }
