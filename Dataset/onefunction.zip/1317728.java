    public void processPage() {
        BigDecimal ownerid = new BigDecimal(getContext().getSessionAttributeAsString("oid"));
        BookmarksCategoryRequest bcr = new BookmarksCategoryRequest(ownerid);
        String name = getParameter("name");
        BigDecimal pid;
        Link back;
        try {
            pid = new BigDecimal(getParameter("pid"));
            if (pid.equals(new BigDecimal(0))) {
                back = new Link("boCats");
            } else {
                back = new Link("bodetail");
                back.addParam("cid", "" + pid);
            }
        } catch (NumberFormatException e) {
            pid = new BigDecimal(0);
            back = new Link("boCats");
        }
        if (name != null && !name.trim().equals("")) {
            if (bcr.addNewCategory(pid, name, false) < 2) fireUserEvent("boSaveCategory"); else {
                if (getContext().getSessionAttribute("LimitExceededException") == null) {
                    getContext().setSessionAttribute("LimitExceededException", "");
                    fireUserEvent("boMaxCategory");
                }
            }
        }
        throwRedirect(back);
    }
