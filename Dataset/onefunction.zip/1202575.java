    public MenuBar() {
        menu = new JMenu("File");
        menu.setMnemonic(KeyEvent.VK_F);
        this.add(menu);
        menuItem = new JMenuItem("Exit", KeyEvent.VK_E);
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_4, ActionEvent.ALT_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription("Exit JYouTuber");
        menuItem.addActionListener(new MenuBarListener());
        menu.add(menuItem);
        menu = new JMenu("Help");
        menu.setMnemonic(KeyEvent.VK_H);
        menu.getAccessibleContext().setAccessibleDescription("This menu does nothing");
        menuItem = new JMenuItem("Report Bug", KeyEvent.VK_B);
        menuItem.addActionListener(new MenuBarListener());
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, ActionEvent.ALT_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription("Report a bug");
        menu.add(menuItem);
        menuItem = new JMenuItem("About", KeyEvent.VK_A);
        menuItem.addActionListener(new MenuBarListener());
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.ALT_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription("Exit JYouTuber");
        menu.add(menuItem);
        this.add(menu);
    }
