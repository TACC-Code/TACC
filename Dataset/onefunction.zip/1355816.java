    public final int doAfterBody() throws JspException {
        try {
            WikiContext context = (WikiContext) pageContext.getAttribute(WikiTagBase.ATTR_CONTEXT, PageContext.REQUEST_SCOPE);
            context = context.deepClone();
            BodyContent bc = getBodyContent();
            String wikiText = bc.getString();
            bc.clearBody();
            if (wikiText != null) {
                wikiText = wikiText.trim();
                String result = context.getEngine().textToHTML(context, wikiText);
                getPreviousOut().write(result);
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "Tag failed", e);
            throw new JspException("Tag failed, check logs: " + e.getMessage());
        }
        return SKIP_BODY;
    }
