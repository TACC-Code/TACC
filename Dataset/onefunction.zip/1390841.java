    public Part(List<TextPosition> priotyNos, List<TextPosition> purpose, List<TextPosition> acceptDate, List<TextPosition> because, List<TextPosition> right) {
        this.priotyNos = priotyNos;
        this.purpose = purpose;
        this.acceptDate = acceptDate;
        this.because = because;
        this.right = right;
    }
