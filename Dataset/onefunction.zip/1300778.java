    public TurtleJenaWriter() {
        super();
        if (writer.getPropValue("usePropertySymbols") == null) writer.useWellKnownPropertySymbols = false;
        writer.allowTripleQuotedStrings = false;
        writer.allowDoubles = false;
    }
