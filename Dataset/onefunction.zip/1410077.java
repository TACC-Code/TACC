    public static ArrayList<YahooItem> SearchNews(String artist, String language) {
        ArrayList<YahooItem> yahoonews = new ArrayList<YahooItem>();
        try {
            artist = java.net.URLEncoder.encode(artist, "UTF-8");
            XPath xpath = XPathFactory.newInstance().newXPath();
            System.out.println("Connect� : " + YAHOO_URL + KEY + "&query=" + artist + "&results=5&language=en");
            InputSource inputSource = new InputSource(YAHOO_URL + KEY + "&query=" + artist + "&results=5&language=fr");
            NodeList nodes = (NodeList) xpath.evaluate("//*[local-name() = 'Result']", inputSource, XPathConstants.NODESET);
            int length = nodes.getLength();
            for (int n = 0; n < length; n++) {
                Node node = nodes.item(n);
                yahoonews.add(new YahooItem(node));
            }
        } catch (XPathExpressionException xpe) {
        } catch (UnsupportedEncodingException upe) {
        }
        return (yahoonews);
    }
