    public void run(IAction action) {
        CreateEncryption encryption = new CreateEncryption();
        try {
            IFile file = null;
            WizardLauncher myWizard = new WizardLauncher();
            Document doc = null;
            if (selection instanceof IStructuredSelection) {
                file = (IFile) ((IStructuredSelection) selection).getFirstElement();
            }
            if (file != null && file.isAccessible() && !file.isReadOnly()) {
                IProject project = file.getProject();
                myWizard.init(workbench, project, file);
                WizardDialog dialog = new WizardDialog(shell, myWizard);
                dialog.create();
                dialog.open();
                if (dialog.getReturnCode() == 0 && myWizard.getSettings() != null) {
                    doc = encryption.encrypt(myWizard.getSettings(), null);
                    FileOutputStream fos = new FileOutputStream(file.getLocation().toString());
                    if (null != doc) {
                        XMLUtils.outputDOM(doc, fos);
                    }
                    fos.flush();
                    fos.close();
                }
                dialog.close();
                myWizard.dispose();
            } else if (file == null && editor.isEditable()) {
                if (editor.isDirty()) {
                    saveEditorContent(editor);
                }
                IEditorInput input = editor.getEditorInput();
                IProject project = null;
                file = (IFile) input.getAdapter(IFile.class);
                if (file != null && null != file.getProject()) {
                    project = file.getProject();
                }
                IDocument document = editor.getDocumentProvider().getDocument(input);
                ITextSelection textSelection = (ITextSelection) editor.getSelectionProvider().getSelection();
                boolean validSelection = parseSelection(textSelection.getText());
                if (validSelection && file != null && project != null) {
                    myWizard.init(workbench, project, file, textSelection);
                    WizardDialog dialog = new WizardDialog(shell, myWizard);
                    dialog.create();
                    dialog.open();
                    if (dialog.getReturnCode() == 0 && myWizard.getSettings() != null) {
                        doc = encryption.encrypt(myWizard.getSettings(), textSelection.getText());
                        if (doc != null) {
                            document.set(Utils.docToString(doc, true));
                        }
                    }
                    dialog.close();
                    myWizard.dispose();
                } else if (file != null && project != null) {
                    myWizard.init(workbench, project, file);
                    WizardDialog dialog = new WizardDialog(shell, myWizard);
                    dialog.create();
                    dialog.open();
                    if (dialog.getReturnCode() == 0 && myWizard.getSettings() != null) {
                        doc = encryption.encrypt(myWizard.getSettings(), null);
                        if (doc != null) {
                            document.set(Utils.docToString(doc, true));
                        }
                    }
                    dialog.close();
                    myWizard.dispose();
                } else {
                    showInfo(Messages.EncryptionImpossible, Messages.EncryptionProtectedDoc);
                }
            } else {
                showInfo(Messages.EncryptionImpossible, Messages.EncryptionProtectedDoc);
            }
        } catch (Exception e) {
            showError(Messages.Error, Messages.EncryptingError + e.getLocalizedMessage());
            log("An error occured during encryption", e);
        }
    }
