    public void initialize() {
        CDOTransaction transaction = ServerManager.INSTANCE.getMainTransaction();
        if (!transaction.hasResource(GlobalSettingsManager.GLOBAL_SETTINGS_RESOURCE)) {
            CDOResource resource = transaction.createResource(GlobalSettingsManager.GLOBAL_SETTINGS_RESOURCE);
            PubGlobalSettings globalSettings = PubSettingsFactory.eINSTANCE.createPubGlobalSettings();
            resource.getContents().add(globalSettings);
            try {
                ServerManager.INSTANCE.getMainTransaction().commit();
            } catch (CommitException e) {
                ErrorUtil.databaseError(e);
            }
        }
    }
