    public ActionForward render(ActionMapping mapping, ActionForm form, PortletConfig config, RenderRequest req, RenderResponse res) throws Exception {
        if (req.getWindowState().equals(WindowState.NORMAL)) {
            List<Entity> l = (List<Entity>) InodeFactory.getInodesOfClass(Entity.class);
            HashMap<Long, List<Category>> entityCategories = new HashMap<Long, List<Category>>();
            for (Entity entity : l) {
                List<Category> categories = EntityFactory.getEntityCategories(entity);
                long entityInode = entity.getInode();
                entityCategories.put(entityInode, categories);
            }
            req.setAttribute(WebKeys.ENTITY_VIEW, l);
            req.setAttribute(WebKeys.CATEGORY_VIEW, entityCategories);
            return mapping.findForward("portlet.ext.entities.view");
        } else {
            List<Entity> l = (List<Entity>) InodeFactory.getInodesOfClass(Entity.class, "lower(entity_name)");
            HashMap<Long, List<Category>> entityCategories = new HashMap<Long, List<Category>>();
            for (Entity entity : l) {
                List<Category> categories = EntityFactory.getEntityCategories(entity);
                long entityInode = entity.getInode();
                entityCategories.put(entityInode, categories);
            }
            req.setAttribute(WebKeys.ENTITY_VIEW, l);
            req.setAttribute(WebKeys.CATEGORY_VIEW, entityCategories);
            return mapping.findForward("portlet.ext.entities.view_entities");
        }
    }
