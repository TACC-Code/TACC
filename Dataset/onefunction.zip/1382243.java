    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        String strUid = request.getParameter("uid");
        String strUserName = (String) request.getSession().getAttribute("userName");
        if ((strUserName == null) || (!strUserName.equals("admin"))) {
            return mapping.findForward("login");
        }
        Log log = LogFactory.getLog("com.yhtl.designermanagement");
        try {
            Session session = HibernateSessionFactory.getCurrentSession();
            Transaction tx = session.beginTransaction();
            List loginList = session.createQuery("from TblLogin c where c.tblLoginId = \'" + strUid + "\'").list();
            List userinfoList = session.createQuery("from TblUserinfo c where c.tblUserinfoLoginid = \'" + strUid + "\'").list();
            if (loginList.isEmpty() || userinfoList.isEmpty()) {
                log.info("Failed to delete user '" + strUid + "'");
                request.setAttribute("info", "[ERROR]删除用户失败：找不到该用户");
                return mapping.findForward("failure");
            }
            TblLogin login = (TblLogin) loginList.get(0);
            TblUserinfo userinfo = (TblUserinfo) userinfoList.get(0);
            String strUser = login.getTblLoginLoginname();
            session.delete(login);
            session.delete(userinfo);
            tx.commit();
            request.setAttribute("info", "[INFO]成功删除用户 \"" + strUser + "\"");
            return mapping.findForward("success");
        } catch (HibernateException e) {
            log.info("Failed to delete user '" + strUid + "'");
            request.setAttribute("info", "[ERROR]删除用户失败：数据库错误");
            return mapping.findForward("failure");
        } finally {
            try {
                HibernateSessionFactory.closeCurrentSession();
            } catch (HibernateException e1) {
            }
        }
    }
