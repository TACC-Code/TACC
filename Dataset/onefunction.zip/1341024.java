    public static HandleDAO getInstance(Context context) throws HandleStorageException {
        String db = ConfigurationManager.getProperty("db.name");
        if (db != null) {
            if ("postgres".equals(db)) {
                return new HandleDAOPostgres(context);
            } else if ("oracle".equals(db)) {
                return new HandleDAOOracle(context);
            }
        }
        throw new HandleStorageException("Invalid or no configuration for db.name");
    }
