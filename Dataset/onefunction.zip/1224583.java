    public void cannotEnterMultipleLeadingZeros() {
        calculatorUI.displaysNumber("0");
        calculatorUI.clickDigitButton(0);
        calculatorUI.clickDigitButton(0);
        calculatorUI.clickDigitButton(0);
        calculatorUI.clickDigitButton(1);
        calculatorUI.displaysNumber("1");
    }
