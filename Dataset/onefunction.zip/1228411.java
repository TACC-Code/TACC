    public CommandPanel(Window window) {
        this.window = window;
        setLayout(new FlowLayout());
        buttonBox = new JPanel(new FlowLayout());
        button = new JButton("Button");
        button.addActionListener(new CommandPanelListener(this));
        buttonBox.add(button);
        this.add(buttonBox);
        SpinnerNumberModel numSectionsSpinnerModel = new SpinnerNumberModel(0, 0, 10, 1);
        spinner = new JSpinner(numSectionsSpinnerModel);
        spinner.addChangeListener(new CommandPanelListener(this));
        this.add(spinner);
        checkBox = new JCheckBox("Checkbox");
        checkBox.setSelected(false);
        checkBox.addItemListener(new CommandPanelListener(this));
        this.add(checkBox);
    }
