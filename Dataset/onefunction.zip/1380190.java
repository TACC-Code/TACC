    public void setAsText(String s) throws IllegalArgumentException {
        if ((s == null) || "".equals(s)) {
            setValue(null);
        } else {
            String[] tokens = StringUtils.commaDelimitedListToStringArray(s);
            ConfigAttributeDefinition configDefinition = new ConfigAttributeDefinition();
            for (int i = 0; i < tokens.length; i++) {
                configDefinition.addConfigAttribute(new SecurityConfig(tokens[i].trim()));
            }
            setValue(configDefinition);
        }
    }
