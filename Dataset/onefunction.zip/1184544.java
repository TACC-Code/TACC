    public FG60() {
        super();
        try {
            setID("FG60");
            setTitle("thiosemicarbazide");
            addSubstructure("FG60", "[$([NX3]([#6])[#6]),$([NX3H][#6]),$([NX3H2])]C(=S)[N;$([NX3]([#6])),$([NX3H1])][$([NX3]([#6])[#6]),$([NX3H][#6]),$([NX3H2])]");
        } catch (SMARTSException x) {
            logger.error(x);
        }
    }
