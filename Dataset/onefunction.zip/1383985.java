    public Song(String na, String ar, String la, int id, int len, String py, String tp, Date tm, int rw, int rm, int rs, String pa) {
        Name = na;
        ArtistList = ar;
        Language = la;
        ID = id;
        Length = len;
        PinYin = py;
        Type = tp;
        Time = tm;
        RankWeek = rw;
        RankMonth = rm;
        RankSeason = rs;
        Path = pa;
    }
