    public void testJarSize() throws Exception {
        String localJarName = "file:lib/apache/commons/commons-cli-1.1.jar";
        URL url = new URL(localJarName);
        JarClassLoader cl = new JarClassLoader(url);
        JarURLConnection jarConn = cl.getJarURLConnection();
        Assert.assertEquals(36174, jarConn.getContentLength());
        String clazz = cl.getMainClassName();
        Assert.assertNull(clazz);
    }
