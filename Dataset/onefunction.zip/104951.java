    public static void main(String[] args) {
        try {
            Smooks smooks = new Smooks();
            smooks.addConfigurations("smooks-resource", new URIResourceLocator().getResource("/de/objectcode/openk/soa/connectors/sugarcrm/smooks/partner-to-sugarcrm.xml"));
            smooks.addConfigurations("cdu-creators", new URIResourceLocator().getResource("/de/objectcode/openk/soa/connectors/sugarcrm/test/smooks-creators.xml"));
            StandaloneExecutionContext context = smooks.createExecutionContext();
            StringWriter out = new StringWriter();
            smooks.filter(new StreamSource(new URIResourceLocator().getResource("/de/objectcode/openk/soa/connectors/sugarcrm/test/event-partner.xml")), new StreamResult(out), context);
            System.out.println("'" + out.toString() + "'");
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) BeanAccessor.getBeans(context)).entrySet()) {
                System.out.println("\n>>> " + entry.getKey() + " " + entry.getValue());
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
