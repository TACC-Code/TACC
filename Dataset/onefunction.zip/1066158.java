    public int getColor(double value) {
        int index = (int) value;
        double remainder = value - Math.floor(value);
        int from = PALETTE[index % PALETTE.length];
        int to = PALETTE[(index + 1) % PALETTE.length];
        int r = ColorUtil.red(from) + (int) ((ColorUtil.red(to) - ColorUtil.red(from)) * remainder);
        int g = ColorUtil.green(from) + (int) ((ColorUtil.green(to) - ColorUtil.green(from)) * remainder);
        int b = ColorUtil.blue(from) + (int) ((ColorUtil.blue(to) - ColorUtil.blue(from)) * remainder);
        return ColorUtil.create(b, g, r);
    }
