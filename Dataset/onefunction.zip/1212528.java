    public String find(Map<String, Object> peaMap, Mappings mappings) throws UnableToDetermineTemplateException {
        String result;
        if (peaMap.get(EasyPeasConstants.EASYPEA_TEMPLATE) != null) {
            result = (String) peaMap.get(EasyPeasConstants.EASYPEA_TEMPLATE);
        } else if (peaMap.get(EasyPeasConstants.EASYPEA_FORWARD) != null) {
            result = (String) peaMap.get(EasyPeasConstants.EASYPEA_FORWARD);
        } else if (peaMap.get(EasyPeasConstants.EASYPEA_PEA) == null) {
            throw new UnableToDetermineTemplateException("No easypea stored in response map");
        } else if (peaMap.get(EasyPeasConstants.EASYPEA_METHOD) == null) {
            throw new UnableToDetermineTemplateException("No easypea method stored in response map");
        } else {
            String key = mappings.getName(peaMap.get(EasyPeasConstants.EASYPEA_PEA));
            if (key == null) {
                throw new UnableToDetermineTemplateException("Unable to find key for object:" + peaMap.get(EasyPeasConstants.EASYPEA_PEA));
            }
            result = "/" + key + "/" + peaMap.get(EasyPeasConstants.EASYPEA_METHOD) + ".vm";
        }
        return result;
    }
