    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        if (value.getClass() == SortedTreeNode.class) {
            value = ((SortedTreeNode) value).getValue();
        }
        if (RenderableTreeNode.class.isAssignableFrom(value.getClass())) {
            RenderableTreeNode node = (RenderableTreeNode) value;
            JComponent c = (JComponent) node.getRenderable();
            if (sel) {
                c.setBorder(BorderFactory.createLineBorder(UIManager.getColor("desktop")));
                c.setBackground(UIManager.getColor("textHighlight"));
            } else {
                c.setBackground(new Color(0, true));
                c.setBorder(BorderFactory.createEmptyBorder());
            }
            return c;
        } else if (TableRow.class.isAssignableFrom(value.getClass())) {
            TableRow tableRow = (TableRow) value;
            Table table = tableRow.getTable();
            TableHeader header = table.getHeader();
            String[] headers = { "", "" };
            Object[][] data = new Object[header.countVisible()][2];
            int j = 0;
            for (int i = 0; i < table.columns(); i++) {
                if (header.isVisible(i)) {
                    data[j][0] = header.getTitle(i);
                    data[j][1] = tableRow.get(i);
                    j++;
                }
            }
            JTable jTable = new JTable(data, headers);
            jTable.setShowGrid(false);
            jTable.setPreferredSize(new java.awt.Dimension(300, 170));
            return jTable;
        }
        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
        return this;
    }
