    public void testCreateExceptionDayWithDate() {
        LocalDate date = new LocalDate();
        CalendarExceptionType type = BaseCalendarTest.createCalendarExceptionType();
        CalendarException day = CalendarException.create(date, EffortDuration.hours(8), type);
        assertThat(day.getDate(), equalTo(new LocalDate(date)));
        assertThat(day.getDuration(), equalTo(EffortDuration.hours(8)));
        assertThat(day.getType(), equalTo(type));
    }
