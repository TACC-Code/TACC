    public void testVerticalSplit() {
        TPane mainPane = new TPane();
        mainPane.setSize(100, 200);
        TPane pane1 = new TPane();
        TPane pane2 = new TPane();
        TPane pane3 = new TPane();
        VerticalSplitLayout verticalSplitLayout = new VerticalSplitLayout(mainPane, new double[] { 0.2, 0.5, 0.3 });
        mainPane.setLayoutManager(verticalSplitLayout);
        mainPane.add(pane1);
        mainPane.add(pane2);
        mainPane.add(pane3);
        Assert.assertEquals(pane1.getX(), 0);
        Assert.assertEquals(pane1.getY(), 0);
        Assert.assertEquals(pane1.getWidth(), 100);
        Assert.assertEquals(pane1.getHeight(), 40);
        Assert.assertEquals(pane2.getX(), 0);
        Assert.assertEquals(pane2.getY(), 40);
        Assert.assertEquals(pane2.getWidth(), 100);
        Assert.assertEquals(pane2.getHeight(), 100);
        Assert.assertEquals(pane3.getX(), 0);
        Assert.assertEquals(pane3.getY(), 140);
        Assert.assertEquals(pane3.getWidth(), 100);
        Assert.assertEquals(pane3.getHeight(), 60);
    }
