    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        log("Continuar tramitac�");
        String token = request.getParameter("TOKEN");
        if (token == null) {
            log("Token �s null");
            return;
        }
        log("Rebut token: " + token);
        final String inicialKey = "org.ibit.rol.form.testst.inicial@" + token;
        final String finalKey = "org.ibit.rol.form.testst.final@" + token;
        String xmlInicial = (String) getServletContext().getAttribute(inicialKey);
        String xmlFinal = (String) getServletContext().getAttribute(finalKey);
        getServletContext().removeAttribute(inicialKey);
        getServletContext().removeAttribute(finalKey);
        if (xmlInicial == null) {
            log("XML Inicial �s null");
            return;
        }
        if (xmlFinal == null) {
            log("XML Final �s null");
            return;
        }
        request.setAttribute("xmlInicial", xmlInicial);
        request.setAttribute("xmlFinal", xmlFinal);
        log("Enviant tornada");
        RequestDispatcher rd = request.getRequestDispatcher("/tornada.jsp");
        rd.forward(request, response);
    }
