    public boolean doAction(HttpServletRequest req, HttpServletResponse res, VelocityContext context) throws Exception {
        StudentBillingModule billingModule = new StudentBillingModule();
        String template = billingModule.doRequest(req, context);
        System.out.println(template);
        return true;
    }
