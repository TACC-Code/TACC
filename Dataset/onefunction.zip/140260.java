    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            final String LOST_PASSWORD_PAGE = "/lostPassword.jsp";
            DatabaseLayer database = (DatabaseLayer) request.getSession(false).getAttribute("database");
            String email = request.getParameter("email");
            String username = request.getParameter("username");
            request.getSession(false).setAttribute("username", username);
            request.getSession(false).setAttribute("email", email);
            if ((username == null) || (username.equals(""))) {
                request.getSession(false).setAttribute("message", "O campo do nome de usu�rio est� vazio.");
                ServletUtility.sendRedirect(response, LOST_PASSWORD_PAGE);
            } else if ((email == null) || (email.equals(""))) {
                request.getSession(false).setAttribute("message", "O campo do email est� vazio.");
                ServletUtility.sendRedirect(response, LOST_PASSWORD_PAGE);
            } else {
                String userID = AbstractUser.exists(username, email, database);
                if (!userID.equals("")) {
                    email = email.trim();
                    username = username.trim();
                    User user = AbstractUser.getRealUser(userID, database);
                    String newPassword = Utility.getNewID();
                    user.setPassword(newPassword);
                    String message = "Ol� " + user.getFirstName() + ",\n\n";
                    message += "Aqui est� sua nova senha de acesso ao graW!\n\n";
                    message += "Nome de Usu�rio: " + user.getLogin();
                    message += "\nNova Senha: " + newPassword;
                    message += "\n\ngraW - Gradua��o na Web";
                    message += "\ngraw@tci.ufal.br";
                    Mail.send("graw@tci.ufal.br", "Administra��o graW", email, "Nova senha de acesso ao graW", message);
                    request.getSession(false).setAttribute("message", "Sua nova senha foi enviada para " + email + "!");
                    request.getSession(false).removeAttribute("username");
                    request.getSession(false).removeAttribute("email");
                    ServletUtility.sendRedirect(response, ServletUtility.MAIN);
                } else {
                    request.getSession(false).setAttribute("message", "Os dados passados est�o incorretos! N�o existe nenhum usu�rio " + username + " com email " + email + ".");
                    ServletUtility.sendRedirect(response, LOST_PASSWORD_PAGE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession(false).setAttribute("message", "Erro interno no servidor ao tentar mudar senha!");
            ServletUtility.sendRedirect(response, ServletUtility.MAIN);
        }
    }
