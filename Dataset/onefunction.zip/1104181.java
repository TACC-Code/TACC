    public RazFileNode(File f) {
        location = "?";
        name = f.getName();
        try {
            localPath = f.getCanonicalPath();
        } catch (IOException e) {
            throw new IllegalArgumentException(e);
        }
        try {
            localUrl = f.toURL();
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(e);
        }
    }
