    public ClientReady() {
        super(2);
        Snac snac = new Snac(0x01, 0x02, 0, 0, 0);
        snac.addRawDataToSnac(new RawData(0x00010003, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x00130002, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x00020001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0101047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x00030001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x00150001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x00040001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x00060001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x00090001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x000A0001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x000B0001, RawData.DWORD_LENGHT));
        snac.addRawDataToSnac(new RawData(0x0110047B, RawData.DWORD_LENGHT));
        this.addSnac(snac);
    }
