    public String Excute(ActionContent input, ActionContent output, MyDB mydb) {
        String pluginName = input.getParam("pluginName");
        String SourcePath = AppUtils.AppPath + "/plugins/" + pluginName.replaceAll(".zip", "") + "/";
        try {
            mydb.check();
            UnZip unzip = new UnZip();
            unzip.setMode(1);
            unzip.unZip(AppUtils.AppPath + "/plugins/" + pluginName, SourcePath);
            FileUtils.copyDir(SourcePath + "web/", AppUtils.WebPath);
            mydb.ExcuteFile(SourcePath + "install.sql");
        } catch (Exception e) {
            logger.error(e);
        }
        return input.getParam("fault");
    }
