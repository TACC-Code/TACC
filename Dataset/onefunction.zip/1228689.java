    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        loadMessageBeanFromSesssion(req);
        Manager mgr = getBiboManager(req);
        logger.info("BenutzerAnzeigenServlet hat sich einen Manager mittels getBiboManager(req) geholt.");
        req.setAttribute(JSP_KEY_BIBOMGR, mgr);
        TaintedChecker tc = new TaintedChecker(req);
        tc.add(new TaintedGanzeZahl("benutzer_id", "Unbekannter Benutzer"));
        if (tc.matches()) {
            try {
                long benutzer_id = Long.parseLong(req.getParameter("benutzer_id"));
                Benutzer benutzer = mgr.getBenutzerManager().getBenutzerById(benutzer_id);
                if (benutzer != null) {
                    StringBuffer name = new StringBuffer();
                    name.append(benutzer.getAnrede()).append(" ").append(benutzer.getTitel()).append(" ").append(benutzer.getNachname()).append(", ").append(benutzer.getVorname());
                    req.setAttribute(JSP_KEY_VOLLERNAME, name.toString());
                    req.setAttribute(JSP_KEY_BENUTZER, benutzer);
                    doForward(req, res, "_benutzer_anzeigen.jsp");
                } else {
                    MessageBean msg = createErrorMessageBean(req);
                    msg.addDetail("Kein Benutzer mit der ID " + benutzer_id + " vorhanden!");
                    putMessageBeanToSession(req, msg);
                    res.sendRedirect("./benutzer_suchen");
                }
            } catch (CannotSearchEntityException e) {
                doException(req, res, e);
            } catch (NumberFormatException e) {
            }
        } else {
            MessageBean msg = createErrorMessageBean(req);
            msg.addDetails(tc.getErrorMessages());
            doForward(req, res, "_benutzer_anzeigen.jsp");
        }
    }
