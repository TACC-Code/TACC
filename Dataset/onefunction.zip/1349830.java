    public void insertarPropietario() {
        PropietarioNegocio negocio = new PropietarioNegocio();
        Propietario pr = new Propietario();
        pr.setNombre("Katty");
        pr.setApePateno("VARGAS");
        pr.setApeMaterno("SALVATIERRA");
        pr.setNroDocumento("42095760");
        pr.setCorreo("kvargas@gmail.com");
        pr.setTelefono("215720");
        pr.setUsuario("kvargas");
        pr.setContrasenia("kvargas");
        pr.setTipoPersona(1);
        pr.setEdad(28);
        PropietarioDAO propietario = new PropietarioDAO();
        try {
            Assert.assertFalse(negocio.validarExistencia(2));
            propietario.insertar(pr);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
