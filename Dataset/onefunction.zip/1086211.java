    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        LoginForm sent = (LoginForm) form;
        String login = sent.getLogin();
        String password = sent.getPassword();
        Users user = new Users();
        try {
            user = DBInterface.getInstance().getUser(login);
        } catch (NoSuchElementException noUser) {
            return (mapping.findForward("failed"));
        }
        if (password.equals(user.getPassword())) {
            if (user.getLogin().equals("administrator")) {
                HttpSession session = request.getSession();
                session.setAttribute("admin", 1);
                session.setAttribute("user", user);
                return (mapping.findForward("admin"));
            } else {
                try {
                    user.getLocked();
                    if (user.getLocked() == true) return (mapping.findForward("locked"));
                } catch (NullPointerException unlocked) {
                }
                HttpSession session = request.getSession();
                session.setAttribute("registered", 1);
                session.setAttribute("user", user);
                return (mapping.findForward("success"));
            }
        } else {
            return (mapping.findForward("failed"));
        }
    }
