    public static void main(String[] args) throws Exception {
        World world;
        Node tm;
        world = new World();
        tm = world.node("timemachine:/media/timemachine!harald/Latest/Platte/Users/mhm/Pictures");
        tm.checkDirectory();
        for (Node item : tm.list()) {
            System.out.println(item.getName());
        }
    }
