    public boolean execute(PrintJudgesSheets fairView, FairContext context) {
        try {
            List<Division> divisions = this.divisionCRUD.getAll(context);
            fairView.getDivisionSearchResultsList().setModel(new DivisionListModel(divisions));
            fairView.getFairClassSearchResultsList().setModel(new FairClassListModel());
            fairView.getSectionSearchResultsList().setModel(new SectionListModel());
        } catch (SQLException sqle) {
            fairView.updateStatus(new ExceptionStatusLabel(sqle));
            return false;
        }
        return true;
    }
