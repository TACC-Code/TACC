    public String execute(HkRequest req, HkResponse resp) throws Exception {
        String w = req.getString("w");
        long uid = req.getLong("uid");
        SimplePage page = req.getSimplePage(20);
        List<CmpProduct> list = this.cmpProductService.getCmpProductListByUid(uid, w, page.getBegin(), page.getSize() + 1);
        this.processListForPage(page, list);
        req.setAttribute("list", list);
        req.setEncodeAttribute("w", w);
        return this.getUnionWapJsp("/search/productlist.jsp");
    }
