    public static Test suite() {
        TestSuite suite = new TestSuite(AllServiceTests.class.getName());
        suite.addTestSuite(DashboardServiceImplTest.class);
        suite.addTestSuite(DatasourceServiceImplTest.class);
        suite.addTestSuite(GroupServiceImplTest.class);
        suite.addTestSuite(ReportServiceImplTest.class);
        suite.addTestSuite(UserServiceImplTest.class);
        return suite;
    }
