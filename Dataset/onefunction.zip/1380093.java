    public static void main(String[] args) {
        System.out.println("Chapter 8: example StandardType1Fonts");
        System.out.println("-> Creates a PDF file with 16 standard type 1 fonts.");
        System.out.println("-> jars needed: iText.jar");
        System.out.println("-> file generated: standard_type1_fonts.pdf");
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("results/in_action/chapter08/standard_type1_fonts.pdf"));
            document.open();
            Font[] fonts = new Font[14];
            fonts[0] = new Font(Font.COURIER, Font.DEFAULTSIZE, Font.NORMAL);
            fonts[1] = new Font(Font.COURIER, Font.DEFAULTSIZE, Font.ITALIC);
            fonts[2] = new Font(Font.COURIER, Font.DEFAULTSIZE, Font.BOLD);
            fonts[3] = new Font(Font.COURIER, Font.DEFAULTSIZE, Font.BOLD | Font.ITALIC);
            fonts[4] = new Font(Font.HELVETICA, Font.DEFAULTSIZE, Font.NORMAL);
            fonts[5] = new Font(Font.HELVETICA, Font.DEFAULTSIZE, Font.ITALIC);
            fonts[6] = new Font(Font.HELVETICA, Font.DEFAULTSIZE, Font.BOLD);
            fonts[7] = new Font(Font.HELVETICA, Font.DEFAULTSIZE, Font.BOLDITALIC);
            fonts[8] = new Font(Font.TIMES_ROMAN, Font.DEFAULTSIZE, Font.NORMAL);
            fonts[9] = new Font(Font.TIMES_ROMAN, Font.DEFAULTSIZE, Font.ITALIC);
            fonts[10] = new Font(Font.TIMES_ROMAN, Font.DEFAULTSIZE, Font.BOLD);
            fonts[11] = new Font(Font.TIMES_ROMAN, Font.DEFAULTSIZE, Font.BOLDITALIC);
            fonts[12] = new Font(Font.SYMBOL, Font.DEFAULTSIZE);
            fonts[13] = new Font(Font.ZAPFDINGBATS, Font.DEFAULTSIZE, Font.UNDEFINED, new Color(0xFF, 0x00, 0x00));
            for (int i = 0; i < 14; i++) {
                document.add(new Paragraph("quick brown fox jumps over the lazy dog", fonts[i]));
            }
        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (IOException ioe) {
            System.err.println(ioe.getMessage());
        }
        document.close();
    }
