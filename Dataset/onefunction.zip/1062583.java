    public EditTechreportPage() {
        baseTypeId = BibliographicActivator.TECHREPORT_TYPE_ID;
        requiredFields = new ArrayList<String>();
        requiredFields.add(BibliographicActivator.NODE_NAME_AUTHOR);
        requiredFields.add(BibliographicActivator.NODE_NAME_INSTITUTION);
        requiredFields.add(BibliographicActivator.NODE_NAME_YEAR);
        optionalFields = new ArrayList<String>();
        optionalFields.add(BibliographicActivator.NODE_NAME_TYPE);
        optionalFields.add(BibliographicActivator.NODE_NAME_NUMBER);
        optionalFields.add(BibliographicActivator.NODE_NAME_ADDRESS);
        optionalFields.add(BibliographicActivator.NODE_NAME_MONTH);
        optionalFields.add(BibliographicActivator.NODE_NAME_NOTE);
    }
