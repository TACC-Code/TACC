    public T[] parse(Class<T> t, String x) {
        final String[] xx = x.split(",");
        ArrayList<T> al = new ArrayList<T>(xx.length);
        for (int i = 0; i < xx.length; i++) xx[i] = xx[i].trim();
        if (t == Integer.class) {
            for (int i = 0; i < xx.length; i++) al.add((T) new Integer(Integer.parseInt(xx[i])));
        } else if (t == Float.class) {
            for (int i = 0; i < xx.length; i++) {
                al.add((T) new Float(Float.parseFloat(xx[i])));
                if (USE_STRICT_FLOAT_CHECKING) if (((Float) al.get(i)).isNaN() || ((Float) al.get(i)).isInfinite()) throw new IllegalArgumentException("NaN and Infinity values not permitted");
            }
        } else {
            throw new IllegalArgumentException();
        }
        return al.toArray((T[]) Array.newInstance(t, 1));
    }
