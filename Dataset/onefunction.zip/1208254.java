    public int doStartTag() throws JspException {
        ITreeIteratorElement element = getElement();
        try {
            this.getJspWriter().print(element.getNode().getType());
        } catch (IOException e) {
            throw new JspException("Error writing to JspWriter", e);
        }
        return SKIP_BODY;
    }
