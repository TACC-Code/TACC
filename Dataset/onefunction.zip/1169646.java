    public void initializeDefaultPreferences() {
        IPreferenceStore store = Activator.getDefault().getPreferenceStore();
        store.setDefault(IMappingPreferences.OFFLINE_CACHE_USE_OFFLINE, false);
        store.setDefault(IMappingPreferences.OFFLINE_CACHE_USE_DEFAULT_LOCATION, true);
        store.setDefault(IMappingPreferences.OFFLINE_CACHE_PERIOD_OF_VALIDITY, 7);
        store.setDefault(IMappingPreferences.OFFLINE_CACHE_MAX_SIZE, 100);
    }
