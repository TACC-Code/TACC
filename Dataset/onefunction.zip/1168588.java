    public static String safeString(String value) {
        try {
            if (value == null) return null; else return URLEncoder.encode(value, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            return "-- Internal Error (" + ex.getClass().getName() + ": " + ex.getMessage() + ")";
        }
    }
