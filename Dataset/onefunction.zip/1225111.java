    public SplashScreen() {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        final URL url = getClass().getResource("splash.gif");
        final JLabel label = new JLabel(new ImageIcon(url, "MTAC Splash Screen"));
        label.setBorder(new MatteBorder(1, 1, 1, 1, Color.BLACK));
        setContentPane(label);
        pack();
        final Dimension screen = getToolkit().getScreenSize();
        setLocation((screen.width - getSize().width) / 2, (screen.height - getSize().height) / 2);
    }
