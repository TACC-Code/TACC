    public void validate(FacesContext facesContext, UIComponent component, Object object) throws ValidatorException {
        String enteredName = (String) object;
        Pattern p = Pattern.compile("^(_|.|[a-zA-Z]){1,}([0-9]|_|.|[a-zA-Z]){0,}$");
        Matcher m = p.matcher(enteredName);
        boolean matchFound = m.matches();
        if (!matchFound) {
            FacesMessage message = new FacesMessage();
            message.setDetail("Name not valid");
            message.setSummary("Name does not allow space or special characters");
            message.setSeverity(FacesMessage.SEVERITY_ERROR);
            throw new ValidatorException(message);
        }
    }
