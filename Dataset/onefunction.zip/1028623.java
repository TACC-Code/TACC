    public static int getMoveList(int[] board, int currentPosition, int myColor, int arrayLength, TiffanysMove[] moves) {
        int direction = +9;
        int counter = checkDirection(board, currentPosition, myColor, direction);
        for (int i = 0; i < counter; i++) {
            moves[arrayLength] = new TiffanysMove(currentPosition, currentPosition + ((i + 1) * direction), MY_PIECE_CODE);
            arrayLength++;
        }
        direction = -9;
        counter = checkDirection(board, currentPosition, myColor, direction);
        for (int i = 0; i < counter; i++) {
            moves[arrayLength] = new TiffanysMove(currentPosition, currentPosition + ((i + 1) * direction), MY_PIECE_CODE);
            arrayLength++;
        }
        direction = +11;
        counter = checkDirection(board, currentPosition, myColor, direction);
        for (int i = 0; i < counter; i++) {
            moves[arrayLength] = new TiffanysMove(currentPosition, currentPosition + ((i + 1) * direction), MY_PIECE_CODE);
            arrayLength++;
        }
        direction = -11;
        counter = checkDirection(board, currentPosition, myColor, direction);
        for (int i = 0; i < counter; i++) {
            moves[arrayLength] = new TiffanysMove(currentPosition, currentPosition + ((i + 1) * direction), MY_PIECE_CODE);
            arrayLength++;
        }
        return arrayLength;
    }
