    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("mainAppContext.xml", Chsec.class);
        AuthenMod login = (AuthenMod) ctx.getBean("authModule");
        User user = login.authenticate();
        if (user != null) {
            AppShell app = (AppShell) ctx.getBean("appShell");
            app.run(user);
        }
    }
