    public static void run() {
        DataSingleton ds = DataSingleton.getInstance();
        EList listComponent = ds.getMimodel().getComponent();
        EMFSortingHelper.sortListByName(listComponent);
        Iterator iterComponent = listComponent.iterator();
        while (iterComponent.hasNext()) {
            Component aComponent = (Component) iterComponent.next();
            EMFSortingHelper.sortListByName(aComponent.getDiagramUseCaseView());
            EMFSortingHelper.sortListByName(aComponent.getDiagramDataView());
            EMFSortingHelper.sortListByName(aComponent.getUcactor());
            EMFSortingHelper.sortListByName(aComponent.getUc());
            EMFSortingHelper.sortListByName(aComponent.getEntity());
            LOGGER.debug("Sorting UCControlFlow - start");
            EList listUC = aComponent.getUc();
            Iterator iterUC = listUC.iterator();
            while (iterUC.hasNext()) {
                UC aUC = (UC) iterUC.next();
                UCFlow aUCFlow = aUC.getUcflow();
                if (aUCFlow != null) {
                    EList listUCFunction = aUCFlow.getUcfunction();
                    Iterator iterUCFunction = listUCFunction.iterator();
                    while (iterUCFunction.hasNext()) {
                        UCFunction aUCFunction = (UCFunction) iterUCFunction.next();
                        if (aUCFunction.getOutgoingUCControlFlow().size() > 1) {
                            EMFSortingHelper.sortListBySortingNo(aUCFunction.getOutgoingUCControlFlow());
                        }
                    }
                }
            }
            LOGGER.debug("Sorting UCControlFlow - end");
        }
        SubprojectHelper.addMissingSummaryUseCases();
        if (ConfigurationHelper.REPORT_GLOSSARY) {
            DataDictionaryHelper.generate();
        }
    }
