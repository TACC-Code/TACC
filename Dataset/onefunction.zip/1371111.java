    public static List<TimeStampToken> verify(XAdESTimeStampType sigAndRefsTimeStamp, Element signatureElement) throws XAdESValidationException {
        LOG.debug("validate SigAndRefsTimeStamp...");
        List<TimeStampToken> timeStampTokens = XAdESUtils.getTimeStampTokens(sigAndRefsTimeStamp);
        if (timeStampTokens.isEmpty()) {
            LOG.error("No timestamp tokens present in SigAndRefsTimeStamp");
            throw new XAdESValidationException("No timestamp tokens present in SigAndRefsTimeStamp");
        }
        TimeStampDigestInput digestInput = new TimeStampDigestInput(sigAndRefsTimeStamp.getCanonicalizationMethod().getAlgorithm());
        NodeList signatureValueNodeList = signatureElement.getElementsByTagNameNS(XMLSignature.XMLNS, "SignatureValue");
        if (0 == signatureValueNodeList.getLength()) {
            LOG.error("no XML signature valuefound");
            throw new XAdESValidationException("no XML signature valuefound");
        }
        digestInput.addNode(signatureValueNodeList.item(0));
        NodeList unsignedSignaturePropertiesNodeList = signatureElement.getElementsByTagNameNS(XAdESUtils.XADES_132_NS_URI, "UnsignedSignatureProperties");
        if (unsignedSignaturePropertiesNodeList.getLength() == 0) {
            throw new XAdESValidationException("UnsignedSignatureProperties node not present");
        }
        Node unsignedSignaturePropertiesNode = unsignedSignaturePropertiesNodeList.item(0);
        NodeList childNodes = unsignedSignaturePropertiesNode.getChildNodes();
        int childNodesCount = childNodes.getLength();
        for (int idx = 0; idx < childNodesCount; idx++) {
            Node childNode = childNodes.item(idx);
            if (Node.ELEMENT_NODE != childNode.getNodeType()) {
                continue;
            }
            if (!XAdESUtils.XADES_132_NS_URI.equals(childNode.getNamespaceURI())) {
                continue;
            }
            String localName = childNode.getLocalName();
            if ("SignatureTimeStamp".equals(localName)) {
                digestInput.addNode(childNode);
                continue;
            }
            if ("CompleteCertificateRefs".equals(localName)) {
                digestInput.addNode(childNode);
                continue;
            }
            if ("CompleteRevocationRefs".equals(localName)) {
                digestInput.addNode(childNode);
                continue;
            }
            if ("AttributeCertificateRefs".equals(localName)) {
                digestInput.addNode(childNode);
                continue;
            }
            if ("AttributeRevocationRefs".equals(localName)) {
                digestInput.addNode(childNode);
                continue;
            }
        }
        for (TimeStampToken timeStampToken : timeStampTokens) {
            XAdESUtils.verifyTimeStampTokenSignature(timeStampToken);
            XAdESUtils.verifyTimeStampTokenDigest(timeStampToken, digestInput);
        }
        return timeStampTokens;
    }
