    public boolean visit(CompilationUnit unit) {
        ITypeBinding junit = resolveType("Ljunit/framework/TestCase;");
        if (null == junit) {
            return false;
        }
        NodeLookup nodes = getNodeLookup(unit);
        for (TypeDeclaration node : nodes.getNodes(TypeDeclaration.class)) {
            ITypeBinding check = node.resolveBinding();
            if ((null == check) || !check.isAssignmentCompatible(junit)) {
                continue;
            }
            for (IMethodBinding method : check.getDeclaredMethods()) {
                if (!RuleUtils.isSignatureEqual(method, "suite()Ljunit/framework/Test;")) {
                    continue;
                }
                if (!Modifier.isStatic(method.getModifiers())) {
                    addProblem(unit.findDeclaringNode(method));
                }
            }
        }
        return false;
    }
