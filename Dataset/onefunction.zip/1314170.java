    public Mask render(Layer.Content src, Layer.Content dest, Mask mask) {
        Layer srcLayer = (src != null ? src.getLayer() : null);
        Layer destLayer = dest.getLayer();
        Rectangle ir;
        ir = destLayer.getBounds();
        int top = ir.y;
        int bottom = top + ir.height;
        int left = ir.x;
        int right = left + ir.width;
        int destX = destLayer.getX();
        int destY = destLayer.getY();
        int destW = destLayer.getW();
        left += destX;
        top += destY;
        right += destX;
        bottom += destY;
        render(destLayer, dest, destW, left, top, right, bottom);
        return new RectMask(ir);
    }
