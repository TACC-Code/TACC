    public void testReader() {
        String filePath = DirectoryHelper.getAbsolutePath("xml" + File.separatorChar + "test.xml");
        XMLWrapper xmlwrapper = new XMLWrapper(filePath, new DirectoryPersistent(), false);
        ArrayList<Object> result = new ArrayList<Object>();
        while (xmlwrapper.hasNextElement()) {
            try {
                Object o = xmlwrapper.getNextElement();
                result.add(o);
                Map<?, ?> map = BeanUtils.describe(o);
                logger.debug(map);
            } catch (Exception e) {
                logger.error(e);
                fail();
            }
        }
        assertEquals(2, result.size());
    }
