    public Micro(final Vector3d pos) {
        super();
        final Transform3D t = new Transform3D();
        t.setTranslation(pos);
        this.setTransform(t);
        final Sphere sphere = new Sphere(0.1f, new Sphere().getPrimitiveFlags(), 210);
        sphere.getAppearance().getMaterial().setDiffuseColor(0, 0.1f, 0.5f);
        sphere.getAppearance().getMaterial().setAmbientColor(0f, 0.1f, 0.5f);
        sphere.getAppearance().getMaterial().setSpecularColor(0.3f, 0.8f, 0.4f);
        this.addChild(new AntiAliased<Sphere>(sphere));
    }
