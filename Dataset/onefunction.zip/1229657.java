    public String setupForm(@RequestParam(value = "optParam", required = false) final String optParam, final ModelMap model) {
        log.debug("optParam: {}", optParam);
        final Collection<Integer> numbers = new ArrayList<Integer>(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3) }));
        model.addAttribute("modelObject1", new ModelObject1("sample attr1", numbers));
        model.addAttribute("string1", "here is string One");
        return (viewName);
    }
