    public static File getFileByString(String filename) {
        if (filename.startsWith("file://")) {
            filename = filename.replace("file://", "");
        }
        File file = new File(filename);
        return file;
    }
