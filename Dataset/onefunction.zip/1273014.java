    public File getDirectory(JFrame frame) {
        chooser = new JFileChooser();
        chooser.setApproveButtonText(Main.getMessage("save"));
        chooser.setCurrentDirectory(new java.io.File(JFritzUtils.deconvertSpecialChars(Main.getProperty("backup.path"))));
        chooser.setDialogTitle(CHOOSER_TITLE);
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            Debug.debug("getCurrentDirectory(): " + chooser.getSelectedFile());
            Main.setProperty("backup.path", JFritzUtils.convertSpecialChars(chooser.getSelectedFile().toString()));
            return chooser.getSelectedFile();
        } else {
            return null;
        }
    }
