    public int compare(Object o1, Object o2) {
        try {
            Link u1 = (Link) o1;
            Link u2 = (Link) o2;
            return u1.getOrder() - u2.getOrder();
        } catch (Exception e) {
            throw new BlogunityRuntimeException(I18NStatusFactory.create(I18N.ERRORS.UNABLE_TO_COMPARE, new String[] { "links" }, e));
        }
    }
