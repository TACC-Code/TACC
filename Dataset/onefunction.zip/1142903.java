    public ServerFrame(ServerThread thread) {
        setContentPane(new ServerControlPanel(thread));
        setSize(600, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("KC Bomberman Server Kontrolle");
    }
