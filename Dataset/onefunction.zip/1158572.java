    public static String arrayToString(String str[], String splitStr) {
        String result = "";
        for (int i = 0; i < str.length; i++) {
            result += splitStr + str[i];
        }
        if (result.length() > 0) {
            result = result.substring(splitStr.length());
        }
        return result;
    }
