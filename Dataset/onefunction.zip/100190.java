    public Object localGetComponent(Resource r, ComponentManager componentManager, String id) {
        CompositeFacet cf = new CompositeFacet();
        configureCommonProperties(cf, r, id);
        String label = RDFUtil.getLabel(r);
        if (label == null) {
            label = cf.getId();
        }
        cf.setLabel(label);
        if (r.hasProperty(PORTAL.hasSource)) {
            Resource dsr = r.getProperty(PORTAL.hasSource).getResource();
            cf.setDataSource((SparqlDataSource) componentManager.getStaticComponent(dsr));
        } else {
            log.error("No data source for CompositeFacet");
            throw new PortalConfigurationException("No data source for CompositeFacet");
        }
        List<FacetState> facets = new ArrayList<FacetState>();
        if (r.hasProperty(PORTAL.hasFacets)) {
            Resource rTemp = r.getRequiredProperty(PORTAL.hasFacets).getResource();
            while (!rTemp.equals(RDF.nil)) {
                Resource rFacet = rTemp.getRequiredProperty(RDF.first).getResource();
                Facet facet = (Facet) componentManager.getStaticComponent(rFacet);
                FacetState fState = facet.createFacetState();
                fState.setParentFacet(cf);
                componentManager.registerComponentIfNew(fState);
                facets.add(fState);
                rTemp = rTemp.getRequiredProperty(RDF.rest).getResource();
            }
        }
        cf.setFacets(facets);
        cf.addObject("_facets", facets);
        return cf;
    }
