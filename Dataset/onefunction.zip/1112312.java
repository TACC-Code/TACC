    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        ActionForward forward = null;
        DataInterfaceProjekte dip = new DataInterfaceProjekte();
        DataInterfaceProjektgruppen dipg = new DataInterfaceProjektgruppen();
        DataInterfaceGruppenmitglieder digm = new DataInterfaceGruppenmitglieder();
        String action = request.getParameter("action");
        boolean isAdmin = request.isUserInRole("Administrator");
        boolean isProjectleader = false;
        boolean isUser = false;
        String username = request.getRemoteUser();
        if (!isAdmin) {
            isProjectleader = request.isUserInRole("Projektleiter");
        }
        if (!isAdmin && !isProjectleader) {
            isUser = request.isUserInRole("Benutzer");
        }
        Collection usernames = digm.sucheLogInName(username);
        Iterator iter = usernames.iterator();
        Gruppenmitglieder user = null;
        if (iter.hasNext()) {
            user = (Gruppenmitglieder) iter.next();
        }
        if (action == null) {
            action = "Liste";
        }
        Integer projektnummer = null;
        String prjnummer = request.getParameter("projektnummer");
        if (prjnummer != null) {
            projektnummer = new Integer(prjnummer);
        }
        if (isAdmin) {
            if (log.isDebugEnabled()) {
                log.debug(" User has Role: Administrator");
                log.debug(" Erzeuge Ausgabe fuer " + projektnummer);
            }
            Projekte projekt = (Projekte) dip.sucheProjektnummer(projektnummer);
            if (projekt == null) {
                if (log.isDebugEnabled()) {
                    log.debug(" No Project for projektnummer " + projektnummer);
                }
                return (mapping.findForward("failure"));
            }
            if (log.isDebugEnabled()) {
                log.debug(" Formatiere TEXT Ausgabe");
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            String projektdaten = "Projekt: " + projekt.getProjektname();
            baos.write(projektdaten.getBytes());
            baos.write('\n');
            Collection projektgruppen = dipg.sucheProjektnummer(projektnummer);
            iter = projektgruppen.iterator();
            Projektgruppen projektgruppe = null;
            while (iter.hasNext()) {
                projektgruppe = (Projektgruppen) iter.next();
                String projektgruppendaten = "Projektgruppe: " + projektgruppe.getGruppenname() + "\nPasswort: " + projektgruppe.getPasswort();
                baos.write("--------------------------------------------".getBytes());
                baos.write('\n');
                baos.write(projektgruppendaten.getBytes());
                baos.write("\n----------\n".getBytes());
                Collection gruppenmitglieder = digm.sucheGruppennummer(projektgruppe.getGruppennummer());
                Iterator iter2 = gruppenmitglieder.iterator();
                Gruppenmitglieder gruppenmitglied = null;
                while (iter2.hasNext()) {
                    gruppenmitglied = (Gruppenmitglieder) iter2.next();
                    String benutzer = gruppenmitglied.getMitgliedsname() + ", " + gruppenmitglied.getMitgliedsvorname();
                    String adresse = gruppenmitglied.getMitgliedsadresse1() + "\n" + gruppenmitglied.getMitgliedsadresse2() + "\n" + gruppenmitglied.getMitgliedsplz() + " " + gruppenmitglied.getMitgliedsort();
                    String daten = "Matrikelnummer: " + gruppenmitglied.getMitgliedskennzeichen() + "\n" + gruppenmitglied.getMitgliedsemailadresse();
                    baos.write(benutzer.getBytes());
                    baos.write('\n');
                    baos.write(adresse.getBytes());
                    baos.write('\n');
                    baos.write(daten.getBytes());
                    baos.write("\n----------\n".getBytes());
                }
            }
            response.setContentType("text");
            if (log.isDebugEnabled()) {
                log.debug(" Gebe TEXT zurueck");
            }
            response.setContentLength(baos.size());
            response.getOutputStream().write(baos.toByteArray());
            response.getOutputStream().flush();
        } else if (isProjectleader) {
            if (log.isDebugEnabled()) {
                log.debug(" User has Role: Projectleader");
                log.debug(" Erzeuge Ausgabe fuer " + user.getProjektgruppe().getProjekte().getProjektnummer());
            }
            Projekte projekt = user.getProjektgruppe().getProjekte();
            if (projekt == null) {
                if (log.isDebugEnabled()) {
                    log.debug(" No Project for Projectleader");
                }
                return (mapping.findForward("failure"));
            }
            if (log.isDebugEnabled()) {
                log.debug(" Formatiere TEXT Ausgabe");
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            String projektdaten = "Projekt: " + projekt.getProjektname();
            baos.write(projektdaten.getBytes());
            baos.write('\n');
            Collection projektgruppen = dipg.sucheProjektnummer(projekt.getProjektnummer());
            iter = projektgruppen.iterator();
            Projektgruppen projektgruppe = null;
            while (iter.hasNext()) {
                projektgruppe = (Projektgruppen) iter.next();
                String projektgruppendaten = "Projektgruppe: " + projektgruppe.getGruppenname() + "\nPasswort: " + projektgruppe.getPasswort();
                baos.write("--------------------------------------------".getBytes());
                baos.write('\n');
                baos.write(projektgruppendaten.getBytes());
                baos.write("\n----------\n".getBytes());
                Collection gruppenmitglieder = digm.sucheGruppennummer(projektgruppe.getGruppennummer());
                Iterator iter2 = gruppenmitglieder.iterator();
                Gruppenmitglieder gruppenmitglied = null;
                while (iter2.hasNext()) {
                    gruppenmitglied = (Gruppenmitglieder) iter2.next();
                    String benutzer = gruppenmitglied.getMitgliedsname() + ", " + gruppenmitglied.getMitgliedsvorname();
                    String adresse = gruppenmitglied.getMitgliedsadresse1() + "\n" + gruppenmitglied.getMitgliedsadresse2() + "\n" + gruppenmitglied.getMitgliedsplz() + " " + gruppenmitglied.getMitgliedsort();
                    String daten = "Matrikelnummer: " + gruppenmitglied.getMitgliedskennzeichen() + "\n" + gruppenmitglied.getMitgliedsemailadresse();
                    baos.write(benutzer.getBytes());
                    baos.write('\n');
                    baos.write(adresse.getBytes());
                    baos.write('\n');
                    baos.write(daten.getBytes());
                    baos.write("\n----------\n".getBytes());
                }
            }
            response.setContentType("text");
            if (log.isDebugEnabled()) {
                log.debug(" Gebe TEXT zurueck");
            }
            response.setContentLength(baos.size());
            response.getOutputStream().write(baos.toByteArray());
            response.getOutputStream().flush();
        }
        if (log.isDebugEnabled()) {
            log.debug(" Verarbeitung abgeschlossen");
        }
        return forward;
    }
