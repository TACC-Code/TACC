    public AlternateLocationHelper(AlternateLocationFactory alternateLocationFactory) {
        try {
            for (int i = 0; i < UNEQUAL_SHA1_LOCATIONS.length; i++) {
                UNEQUAL_SHA1_LOCATIONS[i] = alternateLocationFactory.create(SOME_IPS[i], UrnHelper.URNS[i]);
            }
            for (int i = 0; i < EQUAL_SHA1_LOCATIONS.length; i++) {
                EQUAL_SHA1_LOCATIONS[i] = alternateLocationFactory.create(SOME_IPS[i], UrnHelper.URNS[0]);
            }
        } catch (IOException iox) {
            throw new RuntimeException(iox);
        }
    }
