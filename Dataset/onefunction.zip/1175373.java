    public void testTimeZoneProperty() throws Exception {
        Properties properties = System.getProperties();
        Set<Map.Entry<Object, Object>> entries = properties.entrySet();
        for (Map.Entry<Object, Object> entry : entries) {
            System.out.println(" " + entry.getKey() + "=" + entry.getValue());
        }
        Calendar defCalendar = Calendar.getInstance();
        TimeZone timeZone = defCalendar.getTimeZone();
        System.out.println(" Default Time Zone:" + timeZone);
        String[] timeZones = TimeZone.getAvailableIDs();
        for (int i = 0; i < timeZones.length; i++) {
            String zone = timeZones[i];
            System.out.println(" Time Zone " + i + " = " + zone);
        }
        String londonId = "Europe/London";
        TimeZone.setDefault(TimeZone.getTimeZone(londonId));
        defCalendar = Calendar.getInstance();
        timeZone = defCalendar.getTimeZone();
        System.out.println(" Default Time Zone:" + timeZone);
        String mitId = "MIT";
        TimeZone.setDefault(TimeZone.getTimeZone(mitId));
        defCalendar = Calendar.getInstance();
        timeZone = defCalendar.getTimeZone();
        System.out.println(" Default Time Zone:" + timeZone);
    }
