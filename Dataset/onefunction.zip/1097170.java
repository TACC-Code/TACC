    public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (isCancelled(request)) {
            return mapping.findForward("home");
        }
        ActionErrors errors = new ActionErrors();
        LoginForm form = (LoginForm) actionForm;
        MailManager manager = new MailManager(Globals.getLdapHost(), Globals.getLdapPort(), Globals.getLdapSearchBase());
        boolean isRoot = false;
        String userDn;
        if (form.getUsername().equals(Globals.getRootLogin())) {
            userDn = Globals.getRootDn();
            isRoot = true;
        } else {
            userDn = manager.getDnFromMail(form.getUsername());
        }
        if (userDn == null) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("login.error.invalid_login"));
        } else {
            manager.setBindEntry(userDn, form.getPassword());
            if (!manager.authenticate()) {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("login.error.invalid_login"));
            }
        }
        if (!errors.isEmpty()) {
            saveErrors(request, errors);
            form.setPassword(null);
            return new ActionForward(mapping.getInput());
        }
        Set roles = new HashSet();
        if (isRoot) {
            roles.add(User.SITE_ADMIN_ROLE);
            roles.add(User.DOMAIN_ADMIN_ROLE);
        } else if (manager.isPostmaster(form.getUsername())) {
            roles.add(User.DOMAIN_ADMIN_ROLE);
        }
        User user = new User(form.getUsername(), userDn, form.getPassword(), roles);
        HttpSession session = request.getSession();
        session.setAttribute(AuthenticationFilter.AUTHENTICATION_KEY, "true");
        session.setAttribute("user", user);
        return new RedirectingActionForward(form.getDone());
    }
