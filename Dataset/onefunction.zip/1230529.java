    public void testSetPixelsIntIntIntIntColorModelIntArrayIntInt() {
        try {
            new AreaAveragingScaleFilter(143, -1).setPixels(1, 1, 1, 1, (ColorModel) null, new int[0], 2, 1);
            fail("IndexOutOfBoundsException expected");
        } catch (IndexOutOfBoundsException e) {
        }
    }
