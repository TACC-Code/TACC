    protected boolean build(Element element, com.sitescape.team.remoting.ws.model.DefinableEntity entityModel, Object val, String dataElemType, String dataElemName) {
        if (val instanceof Document) {
            if (element != null) element.add((Document) val);
            if (entityModel != null) entityModel.addCustomStringField(new CustomStringField(dataElemName, dataElemType, ((Document) val).getRootElement().asXML()));
        } else if (val != null) {
            if (element != null) element.setText(val.toString());
            if (entityModel != null) entityModel.addCustomStringField(new CustomStringField(dataElemName, dataElemType, val.toString()));
        }
        return true;
    }
