    public void testObjectOverrides() {
        Tag tag1 = new Tag("foo", "http://foo", "f");
        Tag tag2 = new Tag("foo", "http://foo", "f");
        Assert.assertNotSame("tags are same", tag1, tag2);
        Assert.assertFalse("tags are equal 1->2", tag1.equals(tag2));
        Assert.assertFalse("tags are equal 2->1", tag2.equals(tag1));
        Assert.assertFalse("tags are equally hashed", tag1.hashCode() == tag2.hashCode());
        Assert.assertEquals("tags are not equal toString()", tag1.toString(), tag2.toString());
    }
