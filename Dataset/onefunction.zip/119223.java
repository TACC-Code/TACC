    public void render(Listitem item, Object data) throws Exception {
        final MapLayer layer = (MapLayer) data;
        Listcell listcell = new Listcell();
        Checkbox checkbox = new Checkbox();
        checkbox.setChecked(layer.isDisplayed());
        checkbox.addEventListener("onCheck", new VisibilityToggleEventListener());
        checkbox.setParent(listcell);
        checkbox.setTooltiptext("Hide");
        Label label = new Label(LayerUtilities.chompLayerName(layer.getName()));
        label.setParent(listcell);
        listcell.setParent(item);
        item.addEventListener("onDrop", new ActiveLayerDNDEventListener());
        item.setDraggable("true");
        item.setDroppable("true");
        item.setValue(layer);
        label.setTooltiptext(LayerUtilities.getTooltip(layer.getName(), layer.getDescription()));
        label.setStyle("float:left;");
        checkbox.setStyle("float:left;");
        Image remove = new Image(Config.getLang("layer_remove_icon"));
        remove.addEventListener("onClick", new ActiveLayersRemoveEventListener());
        remove.setParent(listcell);
        remove.setStyle("float:right;");
        remove.setTooltiptext("remove layer");
        if (layer.isDefaultStyleLegendUriSet()) {
            Image legend;
            if (layer.isCurrentlyAnimated()) {
                legend = new Image(Config.getLang("map_legend_animated_icon"));
            } else if (layer.isSupportsAnimation()) {
                legend = new Image(Config.getLang("map_legend_animatable_icon"));
            } else {
                legend = new Image(Config.getLang("map_legend_icon"));
            }
            legend.setStyle("float:right;");
            legend.setParent(listcell);
            Popup popup = (Popup) Executions.createComponents("/WEB-INF/zul/LegendPopup.zul", legend.getRoot(), null);
            popup.addEventListener("onOpen", new LegendTooltipOpenEventListener(layer));
            legend.setTooltip(popup);
            legend.addEventListener("onClick", new LegendClickEventListener(layer));
        }
    }
