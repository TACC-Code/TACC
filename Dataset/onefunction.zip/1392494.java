    public Object arroundInvoke(InvocationContext ic) throws Exception {
        final long start = System.currentTimeMillis();
        try {
            return ic.proceed();
        } finally {
            final long end = System.currentTimeMillis();
            logger.info("{}:{}:{}", new Object[] { ic.getTarget(), ic.getMethod().getName(), end - start });
        }
    }
