    public static void main(String[] args) throws Exception {
        JavaSpace javaSpace = JavaSpacesUtil.lookupJavaSpace(Constants.JAVASPACESHOST, Constants.JAVASPACESPORT);
        RdOperationExternal rdOperationExternal = new RdOperationExternal();
        rdOperationExternal.operationID = 2L;
        javaSpace.write(rdOperationExternal, null, Lease.FOREVER);
        logger.debug("Wrote: " + rdOperationExternal);
    }
