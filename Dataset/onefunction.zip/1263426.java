    public static void main(String[] args) throws IOException {
        List<EthernetPort> ports = new ArrayList<EthernetPort>();
        EthernetPort rs = new EthernetPort(args[0]);
        ports.add(rs);
        rs = new EthernetPort(args[1]);
        ports.add(rs);
        Bridge bridge = new Bridge("MyBridge", ports);
        for (EthernetPort port : ports) {
            InetAddress address = InetAddress.getByName("10.1.0.2");
            IpToPacket ip2pak = new IpToPacket(bridge);
            IpPacketRepeater ipr = new IpPacketRepeater();
            IpLoggingHandler my = new IpLoggingHandler();
            ipr.add(ip2pak);
            ipr.add(my);
            Handler<IpPacket> ipf = new IpPacketFilter(address, ipr, ip2pak);
            Handler<Packet> ph = new PacketToIp(ipf);
            port.register(Ethertype.IP, ph);
            port.register(bridge);
        }
        for (EthernetPort ep : ports) {
            ep.start();
        }
        for (EthernetPort ep : ports) {
            try {
                ep.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
