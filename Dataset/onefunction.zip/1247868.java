    public static int find_min(int x, int y) {
        int min = 0;
        if (x < y) {
            min = x;
        } else {
            min = y;
        }
        return min;
    }
