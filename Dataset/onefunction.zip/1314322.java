    public static void main(String args[]) {
        if (args.length < 6 || !(args[5].equals("summary") || args[5].equals("detail"))) {
            System.out.println("Arguments: MYSQLHOST MYSQLSCHEMA MYSQLUSER MYSQLPASS [METHODNAME or CONTENTID] WHICH ");
            System.out.println("  METHODNAME The name of the method with which this run in associated");
            System.out.println("  CONTENTID An identifying ID");
            System.out.println("  WHICH Should be either 'summary' or 'detail', and specifies whether to retrieve a giant table or specific contents");
            System.exit(1);
        }
        CleverBrowser cb = new CleverBrowser(args[0], args[1], args[2], args[3], false);
        if (args[5].equals("summary")) {
            Getter g = new SimplePrintoutGetter();
            int methodID = cb.getMethodID(args[4]);
            HashMap<String, ArrayList<ResultRow>> result = cb.getResults(methodID);
            for (String URL : result.keySet()) {
                boolean isFirst = true;
                for (ResultRow row : result.get(URL)) {
                    g.handleResultElement(row.getContentid(), URL, row.getScraped(), cb.getContentByID(row.getContentid()), isFirst);
                    isFirst = false;
                }
            }
        } else {
            int contentID = Integer.parseInt(args[4]);
            System.out.println(cb.getContentByID(contentID));
        }
    }
