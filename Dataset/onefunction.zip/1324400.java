    public static Test suite() {
        TestSuite suite = new TestSuite("Test for sf.net.sinve.test");
        suite.addTestSuite(EngineTest.class);
        suite.addTestSuite(ClassesTest.class);
        suite.addTestSuite(ClassTest.class);
        return suite;
    }
