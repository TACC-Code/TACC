    public void should_be_valid() {
        assertTrue(new LevelOne() instanceof DoNothing);
        assertTrue(new LevelOne() instanceof LevelOne);
        assertTrue(new LevelTwo() instanceof DoNothing);
        assertTrue(new LevelTwo() instanceof LevelOne);
        assertTrue(new LevelTwo() instanceof LevelTwo);
        assertTrue(new LevelTwoAnother() instanceof DoNothing);
        assertTrue(new LevelTwoAnother() instanceof LevelOne);
    }
