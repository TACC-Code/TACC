    public int getNumChannels(Map<String, Node> roots) {
        Node root = roots.get(DEFAULT_FORMAT);
        try {
            return nw.at(root).e("Chroma").e("NumChannels").a("value").intValue();
        } catch (Exception e) {
            throw new ImageMetadataException("Failed to parse image bpp.", e);
        }
    }
