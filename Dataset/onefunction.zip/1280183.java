    public static void main(String[] args) throws Throwable {
        Session session = HibernateManager.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        Query query = session.createQuery("FROM Resume WHERE category_id=2 ORDER BY id DESC");
        List<Resume> lb = (List<Resume>) query.list();
        session.getTransaction().commit();
        for (Resume b : lb) {
            System.out.println(b.getTitle());
            System.out.println(b.getResume());
        }
    }
