    public LabeledDoubleLineConnectionUmFigure() {
        super();
        this.title = "Participa��o Obrigat�ria UM 0";
        this.setAttribute(AttributeKeys.STROKE_TYPE, AttributeKeys.StrokeType.DOUBLE);
        this.setAttribute(AttributeKeys.STROKE_INNER_WIDTH_FACTOR, 3.0);
        this.setLayouter(new LocatorLayouter());
        TextFigure tf = new TextFigure("1");
        tf.setAttribute(AttributeKeys.FONT_BOLD, Boolean.TRUE);
        tf.setFontSize(16);
        tf.setEditable(false);
        LocatorLayouter.LAYOUT_LOCATOR.set(tf, new BezierLabelLocator(0, -Math.PI / 4, 8));
        this.add(tf);
    }
