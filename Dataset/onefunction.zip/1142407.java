    public void testIterator() {
        DoubleLinkedList<String> list = new DoubleLinkedList<String>();
        list.insert("First");
        list.insert("Second");
        list.insert("Third");
        DoubleNode<String> n = list.first();
        DoubleNode<String> v = n.next();
        assertEquals("First", n.value());
        assertEquals("Second", v.value());
        Iterator<String> it = list.iterator();
        try {
            it.remove();
            fail("Iterator must fail-fast on multiple remove attempts");
        } catch (IllegalStateException ise) {
        }
        while (list.size() > 0) {
            it = list.iterator();
            int idx = list.size() - 1;
            if (idx > 0) {
                while (idx-- > 0) {
                    assertTrue(it.hasNext());
                    it.next();
                }
                it.remove();
            } else {
                assertTrue(it.hasNext());
                it.next();
                it.remove();
            }
        }
        try {
            it.remove();
            fail("Iterator must fail-fast on multiple remove attempts");
        } catch (IllegalStateException ise) {
        }
        assertEquals(0, list.size());
    }
