    public Boolean setSignupVerification(long loginId, Boolean enabled) throws GwtErrorCodeException {
        SetSignupVerification command = new SetSignupVerification(loginId, enabled);
        ICommandExecutorService service = getDependency(ICommandExecutorService.class);
        IExecutableCommandResponse<Boolean> response = service.execute(command);
        if (response.hasErrors()) {
            throw new GwtErrorCodeException(response);
        }
        return response.getReturnValue();
    }
