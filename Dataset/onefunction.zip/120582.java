    public Template doTemplate() throws Exception {
        HttpSession session = request.getSession();
        String template_name = "vtl/menu.vm";
        String errorMsg = "";
        Template template = engine.getTemplate(template_name);
        return template;
    }
