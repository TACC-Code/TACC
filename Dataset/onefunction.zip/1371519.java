    public void testUser() {
        IDao basicDao = super.getDaoFacade().getBasicDao();
        String[] param = null;
        Object[] value = null;
        param = new String[] { "min_id", "max_id" };
        value = new Object[] { (long) 1, (long) 1000 };
        List userdId = basicDao.getHibernateTemplate().findByNamedQueryAndNamedParam("user_GetUsedId", param, value);
        logger.info(userdId.size());
        Pagination pg;
        pg = new Pagination();
        pg.setPageSize(2);
        pg.setOrderBy("userId");
        pg.setDesc(true);
        pg = basicDao.findPageByNamedQueryAndParam("user_GetUsedId", param, value, pg);
        logger.info(pg);
        logger.info(pg.getItems().size());
        assertEquals(2, pg.getItems().size());
    }
