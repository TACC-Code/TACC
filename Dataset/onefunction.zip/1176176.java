    public static String axl2Mapserver(AXLFile axlFile, String templateFile) throws Exception {
        File templateF = new File(templateFile);
        Properties p = new Properties();
        p.setProperty("file.resource.loader.path", templateF.getParentFile().getAbsolutePath());
        Velocity.init(p);
        VelocityContext context = new VelocityContext();
        context.put("axl", axlFile);
        context.put("now", new Date());
        context.put("symbols", new ArrayList());
        Template template = null;
        template = Velocity.getTemplate(templateF.getName());
        StringWriter sw = new StringWriter();
        template.merge(context, sw);
        return MapServerFormatter.format(sw.toString());
    }
