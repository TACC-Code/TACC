    public void testDecodeEventsFromBeginning() throws Exception {
        InputStream in = this.getClass().getClassLoader().getResourceAsStream("./julxml/JulXmlStart.log");
        String document = IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("julxml/JulXmlStart.log"));
        UtilLoggingXmlLogImporter importer = new UtilLoggingXmlLogImporter();
        importer.init(new Properties());
        ParsingContext context = new ParsingContext();
        importer.initParsingContext(context);
        ProxyLogDataCollector collector = new ProxyLogDataCollector();
        importer.decodeEvents(document, collector, context);
        Assert.assertEquals(1, collector.getLogData().length);
    }
