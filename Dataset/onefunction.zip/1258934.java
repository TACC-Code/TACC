    public void createInitialLayout(IPageLayout layout) {
        String editorArea = layout.getEditorArea();
        layout.setEditorAreaVisible(true);
        layout.setFixed(false);
        boolean showTitle = true;
        layout.addView(ResourceView.ID, IPageLayout.LEFT, 1, editorArea);
        layout.addPerspectiveShortcut(TasksPerspective.ID);
        layout.addPerspectiveShortcut(TablePerspective.ID);
        layout.addPerspectiveShortcut(GanttPerspective.ID);
        layout.addPerspectiveShortcut(WorksheetPerspective.ID);
    }
