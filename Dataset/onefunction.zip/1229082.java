    public ActionForward execute(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Model model, SubTrackSession subTrackSession) {
        Integer id = null;
        String strId = httpServletRequest.getParameter("MarketId");
        if (strId == null) {
            id = subTrackSession.getCurrentMarketId();
        } else {
            id = new Integer(Integer.parseInt(strId));
        }
        _logger.debug("Market Id is:" + id);
        subTrackSession.setCurrentMarketId(id);
        Market market = model.getMarket(id);
        Collection<MarketSubDate> marketSubDates = model.getSubDatesForMarket(market);
        httpServletRequest.setAttribute("MarketSubDates", marketSubDates);
        return null;
    }
