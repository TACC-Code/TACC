    protected boolean build(Element element, Object obj, DefinableEntity entity, String dataElemType, String dataElemName) {
        if (obj instanceof Event) {
            Event event = (Event) obj;
            StringWriter writer = new StringWriter();
            IcalModule iCalModule = (IcalModule) SpringContextUtil.getBean("icalModule");
            Calendar cal = iCalModule.generate(entity, Arrays.asList(event), null);
            CalendarOutputter out = ICalUtils.getCalendarOutputter();
            try {
                out.output(cal, writer);
            } catch (IOException e) {
            } catch (ValidationException e) {
            }
            if (element != null) element.add(org.dom4j.DocumentHelper.createCDATA(writer.toString()));
        } else {
            if (element != null) element.setText(obj.toString());
        }
        return true;
    }
