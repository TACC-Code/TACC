    public InternalErrorException(String s) {
        FileWriter errorFile = null;
        try {
            errorFile = new FileWriter("error.log", true);
            Calendar calendar = new GregorianCalendar();
            errorFile.write(calendar.getTime() + ": " + s + "\n");
        } catch (IOException e) {
            System.err.println(e);
        } finally {
            try {
                if (errorFile != null) errorFile.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
