    public ActivityTable(long start, long stop, List<Activity> activities, List<Ticket> tickets) {
        this.start = start;
        this.stop = stop;
        this.activities = activities;
        this.tickets = tickets;
    }
