    public YNet reduceElement(YNet net, YExternalNetElement nextElement) {
        YNet reducedNet = net;
        boolean isReducible = false;
        if (nextElement instanceof YTask) {
            YTask task = (YTask) nextElement;
            Set postSet = task.getPostsetElements();
            Set preSet = task.getPresetElements();
            if (preSet.size() > 1 && postSet.size() > 1 && task.getSplitType() == YTask._AND && task.getJoinType() == YTask._AND && task.getRemoveSet().isEmpty()) {
                Map netElements = net.getNetElements();
                Iterator netElesIter = netElements.values().iterator();
                while (netElesIter.hasNext()) {
                    YExternalNetElement element = (YExternalNetElement) netElesIter.next();
                    if (element instanceof YTask) {
                        Set postSet2 = element.getPostsetElements();
                        Set preSet2 = element.getPresetElements();
                        YTask elementTask = (YTask) element;
                        if (postSet.equals(postSet2) && preSet.equals(preSet2) && elementTask.getRemoveSet().isEmpty() && task.getSplitType() == elementTask.getSplitType() && task.getJoinType() == elementTask.getJoinType() && task.getCancelledBySet().isEmpty() && element.getCancelledBySet().isEmpty() && elementTask.getRemoveSet().isEmpty() && !element.equals(task)) {
                            isReducible = true;
                            reducedNet.removeNetElement(element);
                            task.addToYawlMappings(element);
                            task.addToYawlMappings(element.getYawlMappings());
                        }
                    }
                }
                if (isReducible) {
                    return reducedNet;
                }
            }
        }
        return null;
    }
