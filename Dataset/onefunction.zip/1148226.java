    public void testGetData() {
        CompositeContext context = getTestContext1();
        DataPanelElementInfo element = getDPElement("test.xml", "2", "05");
        GeoMapGateway gateway = new GeoMapDBGateway();
        gateway.getRawData(context, element);
    }
