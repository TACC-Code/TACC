    public void testCreate() {
        Properties props = new Properties();
        props.setProperty("class.composite", "ca.huy.ximple.CompositeObject");
        props.setProperty("include.composite.1", "obtainValue");
        props.setProperty("exclude.composite.1", "getValueMap");
        try {
            Ximple ximple = XimpleBuilder.create(props);
            CompositeObject co = TestXimple.createComposite();
            StringWriter out = new StringWriter();
            ximple.writeXml(co, out);
            System.out.println(out.toString());
            assertTrue(!out.toString().contains("ValueMap"));
        } catch (Exception e) {
            fail(e.toString());
        }
    }
