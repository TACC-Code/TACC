    public static void update(Record from, Record to, RecordDef def) {
        to.beginEdit();
        for (final FieldDef fieldDef : def.getFields()) {
            try {
                if (fieldDef instanceof IntegerFieldDef) {
                    to.set(fieldDef.getName(), from.getAsInteger(fieldDef.getName()));
                } else if (fieldDef instanceof BooleanFieldDef) {
                    to.set(fieldDef.getName(), from.getAsBoolean(fieldDef.getName()));
                } else {
                    to.set(fieldDef.getName(), from.getAsObject(fieldDef.getName()));
                }
            } catch (final Exception ex) {
                GWT.log(fieldDef.getName() + " " + ex.getMessage(), ex);
            }
        }
        to.endEdit();
    }
