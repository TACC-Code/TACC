    public org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.OrderProductFromStoreTO[] getProductExchangeList(long storeId) throws java.rmi.RemoteException {
        storeImpl = new StoreImpl();
        Hashtable h = storeImpl.getProductsOrderListByLowStockItems(storeId);
        List<org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.OrderProductFromStoreTO> opWSList = new ArrayList();
        for (Iterator i = h.entrySet().iterator(); i.hasNext(); ) {
            Entry entry = (Entry) i.next();
            StoreTO s = (StoreTO) entry.getKey();
            org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.StoreTO sWS = new org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.StoreTO();
            sWS.setId(s.getId());
            sWS.setLocation(s.getLocation());
            sWS.setName(s.getName());
            org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.OrderProductFromStoreTO o = new org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.OrderProductFromStoreTO();
            o.setStoreTO(sWS);
            List<ProductAmountTO> pmList = (List<ProductAmountTO>) entry.getValue();
            List<org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.ProductAmountTO> pmWSList = new ArrayList<org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.ProductAmountTO>();
            for (Iterator j = pmList.iterator(); j.hasNext(); ) {
                ProductAmountTO pm = (ProductAmountTO) j.next();
                org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.ProductAmountTO pmWS = new org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.ProductAmountTO();
                pmWS.setAmount(pm.getAmount());
                org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.ProductTO pWS = new org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.ProductTO();
                pWS.setBarcode(pm.getProduct().getBarcode());
                pWS.setId(pm.getProduct().getId());
                pWS.setName(pm.getProduct().getName());
                pWS.setPurchasePrice(pm.getProduct().getPurchasePrice());
                pmWS.setProduct(pWS);
                pmWSList.add(pmWS);
            }
            o.setProductAmoutTOCollection(pmWSList.toArray(new Object[0]));
            opWSList.add(o);
        }
        return opWSList.toArray(new org.cocome.tradingsystem.webservices.axis.heavyWeightService.generated.OrderProductFromStoreTO[0]);
    }
