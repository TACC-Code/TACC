    public TestLevelViewDialog(TestLevelModel baseModel) {
        super(baseModel);
        setHeading("Просмотр уровня сложности \"" + baseModel.getName() + "\"");
        addText("<h1>Уровень сложности</h1><br/>");
        addText("<b>ИД:</b> " + baseModel.getId());
        addText("<b>Название уровня сложности: </b>" + baseModel.getName());
    }
