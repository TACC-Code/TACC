    public static void main(String[] args) throws IOException, DocumentException, SQLException {
        MovieLinks1.main(args);
        MovieHistory.main(args);
        Document document = new Document();
        PdfCopy copy = new PdfCopy(document, new FileOutputStream(RESULT));
        document.open();
        PdfReader reader1 = new PdfReader(MovieLinks1.RESULT);
        int n1 = reader1.getNumberOfPages();
        PdfReader reader2 = new PdfReader(MovieHistory.RESULT);
        int n2 = reader2.getNumberOfPages();
        PdfImportedPage page;
        PdfCopy.PageStamp stamp;
        for (int i = 0; i < n1; ) {
            page = copy.getImportedPage(reader1, ++i);
            stamp = copy.createPageStamp(page);
            ColumnText.showTextAligned(stamp.getUnderContent(), Element.ALIGN_CENTER, new Phrase(String.format("page %d of %d", i, n1 + n2)), 297.5f, 28, 0);
            stamp.alterContents();
            copy.addPage(page);
        }
        for (int i = 0; i < n2; ) {
            page = copy.getImportedPage(reader2, ++i);
            stamp = copy.createPageStamp(page);
            ColumnText.showTextAligned(stamp.getUnderContent(), Element.ALIGN_CENTER, new Phrase(String.format("page %d of %d", n1 + i, n1 + n2)), 297.5f, 28, 0);
            stamp.alterContents();
            copy.addPage(page);
        }
        document.close();
    }
