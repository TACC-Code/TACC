    public SCLBayWeapon() {
        super();
        this.techLevel = TechConstants.T_ALL;
        this.name = "Sub-Capital Laser Bay";
        this.setInternalName(this.name);
        this.heat = 0;
        this.damage = DAMAGE_VARIABLE;
        this.shortRange = 12;
        this.mediumRange = 24;
        this.longRange = 40;
        this.extremeRange = 50;
        this.tonnage = 0.0f;
        this.bv = 0;
        this.cost = 0;
        this.atClass = CLASS_CAPITAL_LASER;
        this.capital = true;
        this.subCapital = true;
    }
