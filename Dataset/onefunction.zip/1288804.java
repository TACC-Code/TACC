    public void run(double frac) {
        Visualization vis = null;
        vis = getVisualization();
        vis.run("filter");
        vis.run("animate");
    }
