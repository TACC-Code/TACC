    public void testGetImageForText() {
        try {
            TextToImage t = new TextToImage();
            byte[] ba = t.getImageForText(new String[] { "Line 1", "Line 2", "Line 3" }, Color.WHITE, Color.BLACK, new Font("Serif", Font.PLAIN, 12), 400, 100, 10, 20, ImageFileFormat.PNG);
            File file = new File("test.png");
            if (file.exists()) file.delete();
            OutputStream os = new FileOutputStream(file);
            os.write(ba);
            os.flush();
            os.close();
            System.out.println(file.getAbsolutePath());
            assertTrue(ba.length > 10);
        } catch (IOException e) {
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
