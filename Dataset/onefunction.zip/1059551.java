    public static String getMapping(String db) {
        if (dbmap == null) {
            dbmap = new HashMap<String, String>(20);
            dbmap.put("KAZUSA", "KAZUSA");
            dbmap.put("TAIR", CV_TAIR);
            dbmap.put("UNIPROT", CV_UNIPROT);
            dbmap.put("UPROT", CV_UNIPROT);
            dbmap.put("MIPS", "MIPS");
            dbmap.put("NCBI-GI", "NC_GI");
            dbmap.put("NCBI-GENEID", "UNIGENE");
            dbmap.put("TIGR", CV_TIGR);
            dbmap.put("NITE", "NITE");
            dbmap.put("CHEBI", CV_CHEBI);
            dbmap.put("3DMET", "3DMET");
            dbmap.put("CYORF", "CYORF");
            dbmap.put("UWASH", "UWASH");
            dbmap.put("PUBCHEM", "PUBCHEM");
            dbmap.put("JGI", "JGI");
            dbmap.put("ZFIN", "ZFIN");
            dbmap.put("NC_GI", CV_NCBI_GI);
            dbmap.put("NC_GE", CV_NCBI_GENEID);
            dbmap.put("CAS", CV_CAS);
            dbmap.put("GENEDB", "GENEDB");
            dbmap.put("KEGG", CV_KEGG);
            dbmap.put("EC", CV_EC);
            dbmap.put("GLYCOMEDB", CV_GLYCODB);
            dbmap.put("            GLYCOMEDB", CV_GLYCODB);
        }
        return dbmap.get(db.toUpperCase());
    }
