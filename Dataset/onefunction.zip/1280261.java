    public static void main(String[] args) {
        Injector injector = Guice.createInjector(new BillingModule());
        RealBillingService billingService = injector.getInstance(RealBillingService.class);
        PizzaOrder order = new PizzaOrder();
        CreditCard creditCard = new CreditCard();
        billingService.chargeOrder(order, creditCard);
    }
