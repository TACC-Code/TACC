    public Fabrica(int posX, int posY, int posZ, int ID) {
        super(posX, posY, posZ, 3, 3, 1, ID);
        setPessoas(30);
        setEsgoto(40);
        setLixo(300);
        setAgua(40);
        setAlimento(0);
        setEnergia(100);
        setNome("Fabrica");
    }
