    public void publish(String pathToWebInf) throws Exception {
        org.mortbay.jetty.Server server = new org.mortbay.jetty.Server();
        SelectChannelConnector connector = new SelectChannelConnector();
        connector.setPort(8586);
        server.setConnectors(new Connector[] { connector });
        WebAppContext webappcontext = new WebAppContext();
        webappcontext.setContextPath("/ssm-market");
        webappcontext.setWar(pathToWebInf);
        HandlerCollection handlers = new HandlerCollection();
        handlers.setHandlers(new Handler[] { webappcontext, new DefaultHandler() });
        server.setHandler(handlers);
        server.start();
        logger.info("Web Srervice Server ready...");
        server.join();
    }
