    public void execute(ComponentContext componentContext, HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException, IOException {
        try {
            SalidaForm pf = (SalidaForm) request.getSession().getAttribute("salidaForm");
            Formulario formulario = null;
            if (pf.getIdFormulario() != null) {
                formulario = DelegateUtil.getFormularioDelegate().obtenerFormulario(pf.getIdFormulario());
            }
            controlBloqueoFormulario(request, formulario);
        } catch (DelegateException e) {
            throw new ServletException(e);
        }
    }
