    public ComprobarPrestamo(HttpServletRequest request, BibliotecaDAO dao) {
        Libro libro = new Libro();
        libro.setReferencia(request.getParameter("referencia"));
        try {
            if (dao.isPrestado(libro) == true) {
                request.setAttribute("prestado", "prestado");
            } else {
                request.setAttribute("prestado", "libre");
            }
        } catch (BibliotecaDAOException e) {
            e.printStackTrace();
        }
        Usuario usuario = (Usuario) request.getSession().getAttribute(AtributosConstantes.usuario.toString());
        if (usuario != null) {
            if (usuario.getTipoUsuario() != 1) {
                request.setAttribute("prestamo", "sinPermiso");
            } else {
                request.setAttribute("prestamo", "conPermiso");
            }
        }
        Calendar fechaIni = Calendar.getInstance();
        ;
        Calendar fechaFin = Calendar.getInstance();
        ;
        fechaIni.set(Calendar.YEAR, 2009);
        fechaIni.set(Calendar.MONTH, 01);
        fechaIni.set(Calendar.DAY_OF_MONTH, 12);
        fechaFin.set(Calendar.YEAR, 2009);
        fechaFin.set(Calendar.MONTH, 01);
        fechaFin.set(Calendar.DAY_OF_MONTH, 22);
        Prestamo prestamo = new Prestamo(usuario, libro, fechaIni, fechaFin);
        request.setAttribute("prestamo", prestamo);
        request.setAttribute("pantalla", "prestamo");
        request.setAttribute("referencia", request.getParameter("referencia"));
    }
