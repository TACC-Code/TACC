    public static String makeFullURL(String url) {
        if (url.matches("^[a-zA-Z0-9]+:.+")) {
            return url;
        } else {
            return GWT.getHostPageBaseURL() + url;
        }
    }
