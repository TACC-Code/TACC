    public void test_mimeEncodingUtf8() throws Exception {
        IFacebookRestClient<Document> client = FacebookSessionTestUtils.getValidClient(FacebookXmlRestClient.class);
        String fileName = "FaceBook-128x128.png";
        InputStream fileStream = getClass().getClassLoader().getResourceAsStream(fileName);
        String caption = "test_caption ă";
        client.photos_upload(null, caption, null, fileName, fileStream);
    }
