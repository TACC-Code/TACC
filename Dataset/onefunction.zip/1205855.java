    public static void main(String[] argv) throws Exception {
        WadLoader W = new WadLoader();
        W.InitMultipleFiles(new String[] { "C:\\iwads\\doom1.wad" });
        System.out.println("Total lumps read: " + W.numlumps);
        System.out.println("Num for WALL00_1: " + W.GetNumForName("WALL00_1"));
        patch_t wall = W.CachePatchName("WALL00_1");
        lumpinfo_t lump = W.GetLumpinfoForName("WALL00_1");
        System.out.println(lump.name);
        System.out.println(lump.position);
        System.out.println(lump.size);
        System.out.println("Num for HELP1: " + W.GetNumForName("HELP1"));
        patch_t stbar = W.CachePatchName("HELP1");
        System.out.println(stbar.height);
        System.out.println(stbar.width);
        stbar = (patch_t) W.CacheLumpName("HELP1", 0, stbar.getClass());
    }
