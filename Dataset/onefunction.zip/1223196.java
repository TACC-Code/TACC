    public static double findOptimum(double eps, double rightPoint, IFunction1D function) {
        double a = 0.01;
        double b = rightPoint;
        double a1 = a + F1 * (b - a);
        double a2 = a + F2 * (b - a);
        double fa = function.value(a);
        double fa1 = function.value(a1);
        double fa2 = function.value(a2);
        double fb = function.value(b);
        while (Math.abs(b - a) > eps) {
            if (fa >= fa1 && fa1 >= fa2) {
                a = a1;
                fa = fa1;
                a1 = a2;
                fa1 = fa2;
                a2 = a + F2 * (b - a);
                fa2 = function.value(a2);
            } else if (fa1 <= fa2 && fa2 <= fb) {
                b = a2;
                fb = fa2;
                a2 = a1;
                fa2 = fa1;
                a1 = a + F1 * (b - a);
                fa1 = function.value(a1);
            } else {
                throw new RuntimeException("Seems function is not unimodal");
            }
        }
        return (a + b) * 0.5;
    }
