    public static void main(String[] args) {
        Spel spel = new Spel();
        try {
            spel.zetDecks(1);
        } catch (OngeldigeDeckException e) {
            System.out.println(e);
        }
        Speler sp1 = new Speler(spel);
        try {
            sp1.zetNaam("Piet");
        } catch (OngeldigeNaamException e) {
            System.out.println(e);
        }
        try {
            sp1.zetGeboorteDatum(new Date(93, 1, 20));
        } catch (OngeldigeDatumException e) {
            System.out.println(e);
        }
        try {
            sp1.zetBeginSaldo(20);
        } catch (OngeldigSaldoException e) {
            System.out.println(e);
        }
        sp1.bewaar();
        Bank bank = new Bank();
        while (sp1.geefHuidigSaldo() >= ConstanteWaarde.MIN_INZET && spel.geefAantalSpelRonden() < 41) {
            SpelRonde sr = new SpelRonde(spel);
            SpelerDeelname d = new SpelerDeelname(sr, sp1);
            try {
                d.zetInzet(1.0);
            } catch (OnvoldoendeSaldoException e) {
                System.out.println(e);
                System.exit(0);
            }
            BankDeelname bd = new BankDeelname(sr, bank);
            sr.bewaar();
            d.bewaar();
            bd.bewaar();
            d.voegKaartToe();
            d.voegKaartToe();
            bd.voegKaartToe();
            if ((bd.geefHand()).geefPuntenTotaal() > 10 && d.heeftBlackJack()) {
                bank.uitkeren(d, bd);
            } else {
                if (!d.heeftBlackJack()) {
                    while ((d.geefHand()).geefPuntenTotaal() < 19) {
                        d.koopKaart();
                    }
                    if ((d.geefHand()).geefPuntenTotaal() >= 18 && (d.geefHand()).geefPuntenTotaal() <= 21) {
                        d.passen();
                    }
                }
                if (!d.heeftDoodGekocht()) {
                    while ((bd.geefHand()).geefPuntenTotaal() < 17) {
                        bd.koopKaart();
                    }
                    if ((bd.geefHand()).geefPuntenTotaal() >= 17 && (bd.geefHand()).geefPuntenTotaal() <= 21) {
                        bd.passen();
                    }
                    bank.uitkeren(d, bd);
                }
            }
        }
        System.out.println(spel.geefSpelRonde(40));
    }
