    public static ScriptShell getScriptShell(ScriptLanguageEnum language) throws ScriptingException {
        ScriptShell shell = null;
        if (language == ScriptLanguageEnum.GROOVY) {
            shell = new GroovyScriptShell();
        } else {
            throw new ScriptingException("Unsupported language: " + language.text());
        }
        return shell;
    }
