    public ActionForward perform(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Document document = new Document(new Element("contactListExample"));
        Element contactList = new Element("contactList");
        Element contact = new Element("contact");
        contact.addContent(new Element("display").setText("Blow, Joe"));
        contact.addContent(new Element("email").setText("jblow@work.com"));
        contactList.addContent(contact);
        contact = new Element("contact");
        contact.addContent(new Element("display").setText("Doe, Jane"));
        contact.addContent(new Element("email").setText("jane_doe@hotmail.com"));
        contactList.addContent(contact);
        contact = new Element("contact");
        contact.addContent(new Element("display").setText("Mickey Mouse"));
        contact.addContent(new Element("email").setText("mm@mousehouse.ca"));
        contactList.addContent(contact);
        contact = new Element("contact");
        contact.addContent(new Element("display").setText("Gordie Johnson"));
        contact.addContent(new Element("email").setText("gj@bigsugar.ca"));
        contactList.addContent(contact);
        document.getRootElement().addContent(contactList);
        saveDocument(request, document);
        return mapping.findForward("success");
    }
