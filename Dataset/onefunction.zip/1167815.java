    public WindowMenu() {
        this.setTitle("Menu");
        this.setSize(maxHeight, maxWidth);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setContentPane(pan);
        this.setVisible(true);
    }
