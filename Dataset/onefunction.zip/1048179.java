    public boolean think() {
        if (mPlayer.getPlayMode() != PLAY_ON) {
            return false;
        }
        if (mPlayer.getWorldModel().getBall().getLastSeen() != mPlayer.getWorldModel().getCurrentFrame()) {
            turn(40);
            return true;
        }
        return false;
    }
