    public ActionForward execute(ActionMapping map, ActionForm frm, HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        HttpSession session = req.getSession(false);
        if ((session == null) || (session.getAttribute("UserId") == null) || (session.getAttribute("UserId").equals(new String("")))) {
            req.setAttribute("APP_ERROR", "Your Session Got Expired. Please Re-login.");
            try {
                res.setContentType("text/xml");
                PrintWriter out = res.getWriter();
                out.write("APP_ERROR");
                out.flush();
                out.close();
            } catch (IOException e) {
            }
            return null;
        }
        DataSource db = getDataSource(req);
        MailTemplateUtil tmpUtil = new MailTemplateUtil();
        boolean isNewClient = false;
        boolean isNewReq = false;
        String oftype = req.getParameter("oftype");
        String sClientEmail = req.getParameter("client_mail");
        String jobid = req.getParameter("jobid");
        String sOutput = "";
        try {
            if (oftype.equals("clientemail")) {
                if (sClientEmail == null || sClientEmail.equals(new String())) {
                    sOutput = "error";
                } else {
                    isNewClient = tmpUtil.isNewClient(db, sClientEmail);
                    client = tmpUtil.client;
                    if (isNewClient) {
                        sOutput = "NC";
                    } else {
                        sOutput = "EC" + "$$" + client;
                        logger.info("sOutput------" + sOutput);
                    }
                }
            } else if (oftype.equals("jobid")) {
                logger.info(">>>>>>>>>>>>>>>>>>." + jobid.length());
                if (jobid == null || jobid.equals(new String())) {
                } else if (jobid.length() < 5) {
                } else {
                    isNewReq = tmpUtil.IsNewRequirement(db, jobid);
                    if (isNewReq) {
                        sOutput = "NR" + "$$" + client;
                    } else {
                        sOutput = "ER";
                    }
                }
            }
            res.setContentType("text/xml");
            PrintWriter out = res.getWriter();
            out.write(sOutput);
            out.flush();
            out.close();
        } catch (Exception e) {
            logger.debug("com.rooster.action.hotlist.tmpt.ValidateClientEmailAction.execute - Error" + e.getMessage());
        }
        return null;
    }
