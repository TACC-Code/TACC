    public void test() {
        ComplexTypeDescriptor descriptor = createComplexType(PersonBean.class.getName());
        Entity entity = new Entity(descriptor, "name", "Alice", "age", 23);
        PersonBean bean = new PersonBean("Alice", 23);
        assertEquals(entity, new Bean2EntityConverter(descriptor).convert(bean));
        assertEquals(entity, new Bean2EntityConverter().convert(bean));
    }
