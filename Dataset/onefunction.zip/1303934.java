    public static void main(String[] args) {
        try {
            Context ctx = new InitialContext();
            MyStateless my = (MyStateless) ctx.lookup("MyStatelessBean/remote");
            my.foo();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
