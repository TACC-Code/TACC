    public void testListGrammar() throws ParserException, HasAmbiguityParserException, GrammarNodeVisitException, IOException, GeneratorException {
        final Parser parser = createParser("list.xml");
        resetParseStackId();
        final ParseResult result = parse(parser, false, false, "a");
        assertFalse("must have one result\n" + result, result.isInError());
        assertFalse("must not have alternative for ambiguity", parser.hasAlternativeForAmbiguity());
        final String expected = "begin CONCAT Start (SYNTAX)(65543) stack id=3\n" + " begin ALTERNATIVE List (SYNTAX)(65542) stack id=1\n" + "  begin CONCAT Elt (SYNTAX)(65540) stack id=1\n" + "   begin ALTERNATIVE ws (SYNTAX)(65538) stack id=1\n" + "    begin EMPTY Empty (SYNTAX)(65536) stack id=1\n" + "    end Empty (SYNTAX)\n" + "   end ws (SYNTAX)\n" + "   begin CHARACTER_TERMINAL ntA (SYNTAX)(65539) stack id=1 'a'\n" + "   end ntA (SYNTAX)\n" + "  end Elt (SYNTAX)\n" + " end List (SYNTAX)\n" + " begin ALTERNATIVE ws (SYNTAX)(65538) stack id=2\n" + "  begin EMPTY Empty (SYNTAX)(65536) stack id=2\n" + "  end Empty (SYNTAX)\n" + " end ws (SYNTAX)\n" + "end Start (SYNTAX)\n";
        assertExpected(expected, result);
    }
