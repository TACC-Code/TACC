    public String man() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNAME:\n");
        sb.append("  jobs - prints jobs runing in backrouund or suspended\n\n");
        sb.append("SYNTAX:\n");
        sb.append("  jobs [OPTION].. \n\n");
        sb.append("DESCRIPTION:\n");
        sb.append("  The command is not allowed to have IO redirection.\n\n");
        sb.append("  -? --help  Just prints this help.\n");
        return sb.toString();
    }
