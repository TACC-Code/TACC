    public void testCA_DeleteMessage() throws Exception {
        for (int second = 0; ; second++) {
            if (second >= 60) {
                fail("timeout");
            }
            try {
                if (selenium.isElementPresent("link=Permissions Test 1")) {
                    break;
                }
            } catch (Exception e) {
            }
            Thread.sleep(1000);
        }
        selenium.click(RuntimeVariables.replace("link=Permissions Test 1"));
        selenium.waitForPageToLoad("30000");
        assertTrue(selenium.isElementPresent("link=Test Thread 1"));
        for (int second = 0; ; second++) {
            if (second >= 60) {
                fail("timeout");
            }
            try {
                if (selenium.isElementPresent("//td[7]/ul/li/strong/span")) {
                    break;
                }
            } catch (Exception e) {
            }
            Thread.sleep(1000);
        }
        selenium.click("//td[7]/ul/li/strong/span");
        selenium.click("link=Delete");
        assertTrue(selenium.getConfirmation().matches("^Are you sure you want to delete this[\\s\\S]$"));
        for (int second = 0; ; second++) {
            if (second >= 60) {
                fail("timeout");
            }
            try {
                if (selenium.isTextPresent("Your request processed successfully.")) {
                    break;
                }
            } catch (Exception e) {
            }
            Thread.sleep(1000);
        }
        for (int second = 0; ; second++) {
            if (second >= 60) {
                fail("timeout");
            }
            try {
                if (!selenium.isElementPresent("link=Test Thread 1")) {
                    break;
                }
            } catch (Exception e) {
            }
            Thread.sleep(1000);
        }
        selenium.click(RuntimeVariables.replace("link=Categories"));
        selenium.waitForPageToLoad("30000");
    }
