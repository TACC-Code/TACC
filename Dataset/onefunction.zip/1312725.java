    public void editLoaded(final PageParameter pageParameter, final Map<String, Object> dataBinding, final List<String> visibleToggleSelector, final List<String> readonlySelector, final List<String> disabledSelector) {
        final String parentId = pageParameter.getRequestParameter("parentId");
        if (StringUtils.hasText(parentId)) {
            dataBinding.put("parentId", parentId);
        }
        final String itemId = pageParameter.getRequestParameter("itemId");
        if (StringUtils.hasText(itemId)) {
            dataBinding.put("itemId", itemId);
            final ComponentParameter nComponentParameter = RemarkUtils.getComponentParameter(pageParameter);
            final RemarkItem item = ((IRemarkHandle) nComponentParameter.getComponentHandle()).getEntityBeanById(nComponentParameter, itemId);
            if (item != null) {
                dataBinding.put("textareaRemarkHtmlEditor", item.getContent());
            }
        }
    }
