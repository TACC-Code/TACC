    public void testQuoting() throws Exception {
        Pattern QUOTE_TO_LDAP = Pattern.compile("[\\\\,=]");
        System.out.println(QUOTE_TO_LDAP.matcher("bla\\fasel").replaceAll(REPLACEMENT));
        System.out.println(QUOTE_TO_LDAP.matcher("bla,fasel").replaceAll(REPLACEMENT));
        System.out.println(QUOTE_TO_LDAP.matcher("bla=fasel").replaceAll(REPLACEMENT));
        System.out.println(QUOTE_TO_LDAP.matcher("bla\\fasel").replaceAll(REPLACEMENT));
    }
