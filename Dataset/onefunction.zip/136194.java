    public static void main(String[] args) {
        final Shell shell = new Shell();
        FileDialog SaveFileDialog = new FileDialog(shell, SWT.SAVE);
        SaveFileDialog.setText("�������ļ�ѡ��Ի���");
        SaveFileDialog.setFilterExtensions(new String[] { "*.*", "*.psd", "*.jpg", "*.txt", "*.doc", "*.exe" });
        SaveFileDialog.setFilterNames(new String[] { "��������(*.*)", "potoshop��ʽ(*.psd)", "�ı���ʽ(*.txt)" });
        SaveFileDialog.setFileName("book");
        SaveFileDialog.setFilterPath("D:\\");
        SaveFileDialog.open();
    }
