    public static void readPropeties(String path) {
        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream(path));
        } catch (Exception e) {
            throw new RuntimeException("Failed to load properties file");
        }
        INVERTED_INDEX_TYPE = properties.getProperty("inverted_index_type");
        MIN_GLOBAL_SUPPORT = Integer.parseInt(properties.getProperty("min_global_support"));
        MAX_DEPTH = Integer.parseInt(properties.getProperty("max_depth"));
        MAX_1_FREQUENT_TERMS = Integer.parseInt(properties.getProperty("max_1_frequent_terms"));
        MIN_CLUSTER_SUPPORT = Integer.parseInt(properties.getProperty("min_cluster_support"));
        MIN_SIZE_TO_PRUNE = Integer.parseInt(properties.getProperty("min_size_to_prune"));
        UNCLASSIFIED_LABEL = properties.getProperty("unclassified_label");
        TOP_CLASSIFICATIONS = Integer.parseInt(properties.getProperty("top_classifications"));
        TOP_RELEVANT = Integer.parseInt(properties.getProperty("top_relevant"));
    }
