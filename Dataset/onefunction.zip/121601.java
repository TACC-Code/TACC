    public void testGetServiceFailure() {
        SessionServer server = TrivialSetup.sessionServer();
        try {
            server.getService(ClassService.class);
            fail("Project.GetInstance() on un-added ClassService should throw");
        } catch (ClassNotPersistableRuntimeException cnpce) {
        }
    }
