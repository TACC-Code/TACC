    public static void main(String[] args) {
        int teamN = 0;
        Communication comm;
        try {
            comm = new Communication("localhost", 5466);
            PlayersSkillsWindow psw = new PlayersSkillsWindow(comm, teamN);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
