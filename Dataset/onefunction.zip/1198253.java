    public void testWithMockClient() {
        HttpActionClient client = mock(HttpActionClient.class);
        when(client.performAction(Mockito.any(GetVersion.class))).thenReturn("");
        bot = new MediaWikiBot(client);
        Version version = bot.getVersion();
        assertEquals(Version.UNKNOWN, version);
    }
